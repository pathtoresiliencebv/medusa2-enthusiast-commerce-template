"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Error = Error;
const jsx_runtime_1 = require("react/jsx-runtime");
function Error({ heading, content }) {
    return ((0, jsx_runtime_1.jsx)("div", { className: "flex min-h-screen items-center justify-center", children: (0, jsx_runtime_1.jsxs)("div", { className: "text-center space-y-2", children: [(0, jsx_runtime_1.jsx)("h2", { className: "text-lg font-medium", children: heading }), (0, jsx_runtime_1.jsx)("p", { className: "text-gray-600", children: content })] }) }));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXJyb3IuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvY29tcG9uZW50cy91aS9lcnJvci50c3giXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFLQSxzQkFTQzs7QUFURCxTQUFnQixLQUFLLENBQUMsRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFjO0lBQ3BELE9BQU8sQ0FDTCxnQ0FBSyxTQUFTLEVBQUMsK0NBQStDLFlBQzVELGlDQUFLLFNBQVMsRUFBQyx1QkFBdUIsYUFDcEMsK0JBQUksU0FBUyxFQUFDLHFCQUFxQixZQUFFLE9BQU8sR0FBTSxFQUNsRCw4QkFBRyxTQUFTLEVBQUMsZUFBZSxZQUFFLE9BQU8sR0FBSyxJQUN0QyxHQUNGLENBQ1AsQ0FBQztBQUNKLENBQUMifQ==