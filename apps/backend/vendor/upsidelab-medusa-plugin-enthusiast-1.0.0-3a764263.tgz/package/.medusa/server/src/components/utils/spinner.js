"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoadingSpinner = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
const icons_1 = require("@medusajs/icons");
const LoadingSpinner = () => {
    return ((0, jsx_runtime_1.jsx)("div", { className: "flex min-h-screen items-center justify-center", children: (0, jsx_runtime_1.jsx)(icons_1.Spinner, { className: "text-ui-fg-interactive animate-spin" }) }));
};
exports.LoadingSpinner = LoadingSpinner;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3Bpbm5lci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9jb21wb25lbnRzL3V0aWxzL3NwaW5uZXIudHN4Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7QUFBQSwyQ0FBMEM7QUFFbkMsTUFBTSxjQUFjLEdBQUcsR0FBRyxFQUFFO0lBQ2pDLE9BQU8sQ0FDTCxnQ0FBSyxTQUFTLEVBQUMsK0NBQStDLFlBQzVELHVCQUFDLGVBQU8sSUFBQyxTQUFTLEVBQUMscUNBQXFDLEdBQUcsR0FDdkQsQ0FDUCxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBTlcsUUFBQSxjQUFjLGtCQU16QiJ9