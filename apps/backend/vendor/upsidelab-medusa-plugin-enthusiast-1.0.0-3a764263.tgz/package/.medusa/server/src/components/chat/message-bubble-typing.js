"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageBubbleTyping = MessageBubbleTyping;
const jsx_runtime_1 = require("react/jsx-runtime");
const message_bubble_typing_module_css_1 = __importDefault(require("./message-bubble-typing.module.css"));
const utils_1 = require("../../admin/lib/utils");
function MessageBubbleTyping({ text }) {
    return ((0, jsx_runtime_1.jsxs)("div", { className: "flex flex-col", children: [(0, jsx_runtime_1.jsxs)("div", { className: (0, utils_1.cn)("items-centered rounded-lg px-3 py-4 text-sm", message_bubble_typing_module_css_1.default.typing), children: [(0, jsx_runtime_1.jsx)("div", { className: message_bubble_typing_module_css_1.default.typingDot }), (0, jsx_runtime_1.jsx)("div", { className: message_bubble_typing_module_css_1.default.typingDot }), (0, jsx_runtime_1.jsx)("div", { className: message_bubble_typing_module_css_1.default.typingDot })] }), text && (0, jsx_runtime_1.jsx)("p", { className: "text-sm ml-2 -mt-1 text-muted-foreground", children: text })] }));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVzc2FnZS1idWJibGUtdHlwaW5nLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL2NvbXBvbmVudHMvY2hhdC9tZXNzYWdlLWJ1YmJsZS10eXBpbmcudHN4Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBT0Esa0RBV0M7O0FBbEJELDBHQUF3RDtBQUN4RCxpREFBMkM7QUFNM0MsU0FBZ0IsbUJBQW1CLENBQUMsRUFBRSxJQUFJLEVBQTRCO0lBQ3BFLE9BQU8sQ0FDTCxpQ0FBSyxTQUFTLEVBQUMsZUFBZSxhQUM1QixpQ0FBSyxTQUFTLEVBQUUsSUFBQSxVQUFFLEVBQUMsNkNBQTZDLEVBQUUsMENBQU0sQ0FBQyxNQUFNLENBQUMsYUFDOUUsZ0NBQUssU0FBUyxFQUFFLDBDQUFNLENBQUMsU0FBUyxHQUFJLEVBQ3BDLGdDQUFLLFNBQVMsRUFBRSwwQ0FBTSxDQUFDLFNBQVMsR0FBSSxFQUNwQyxnQ0FBSyxTQUFTLEVBQUUsMENBQU0sQ0FBQyxTQUFTLEdBQUksSUFDaEMsRUFDTCxJQUFJLElBQUksOEJBQUcsU0FBUyxFQUFDLDBDQUEwQyxZQUFFLElBQUksR0FBSyxJQUN2RSxDQUNQLENBQUM7QUFDSixDQUFDIn0=