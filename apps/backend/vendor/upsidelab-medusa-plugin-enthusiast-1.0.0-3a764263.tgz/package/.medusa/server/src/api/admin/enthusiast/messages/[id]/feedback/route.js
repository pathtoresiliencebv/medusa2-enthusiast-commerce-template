"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PATCH = void 0;
const enthusiast_1 = require("../../../../../../modules/enthusiast");
const wrappers_1 = require("../../../../../../api/wrappers");
exports.PATCH = (0, wrappers_1.withErrorHandler)(async (req, res) => {
    const enthusiastService = req.scope.resolve(enthusiast_1.ENTHUSIAST_MODULE);
    const messageId = parseInt(req.params.id);
    const { rating, feedback } = req.body;
    await enthusiastService.messageFeedbackUpdate(messageId, {
        rating,
        feedback,
    });
    res.status(200).json({ success: true });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2VudGh1c2lhc3QvbWVzc2FnZXMvW2lkXS9mZWVkYmFjay9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSxxRUFBeUU7QUFFekUsNkRBQWtFO0FBRXJELFFBQUEsS0FBSyxHQUFHLElBQUEsMkJBQWdCLEVBQ25DLEtBQUssRUFBRSxHQUErRCxFQUFFLEdBQW1CLEVBQUUsRUFBRTtJQUM3RixNQUFNLGlCQUFpQixHQUFzQixHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyw4QkFBaUIsQ0FBQyxDQUFDO0lBQ2xGLE1BQU0sU0FBUyxHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQzFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQztJQUV0QyxNQUFNLGlCQUFpQixDQUFDLHFCQUFxQixDQUFDLFNBQVMsRUFBRTtRQUN2RCxNQUFNO1FBQ04sUUFBUTtLQUNULENBQUMsQ0FBQztJQUVILEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7QUFDMUMsQ0FBQyxDQUNGLENBQUMifQ==