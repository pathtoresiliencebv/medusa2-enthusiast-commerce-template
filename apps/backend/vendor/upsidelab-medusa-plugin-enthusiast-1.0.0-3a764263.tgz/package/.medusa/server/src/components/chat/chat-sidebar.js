"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatSidebar = ChatSidebar;
const jsx_runtime_1 = require("react/jsx-runtime");
const react_1 = require("react");
const react_router_dom_1 = require("react-router-dom");
const admin_client_1 = require("../../admin/lib/admin-client");
const use_active_dataset_1 = require("../../admin/hooks/use-active-dataset");
const agent_list_1 = require("./agent-list");
const conversation_history_1 = require("./conversation-history");
const spinner_1 = require("../../components/utils/spinner");
function ChatSidebar({ currentAgentId, currentConversationId }) {
    const { dataset, isLoading: isDatasetLoading } = (0, use_active_dataset_1.useActiveDataset)();
    const dataSetId = dataset?.external_id ?? null;
    const navigate = (0, react_router_dom_1.useNavigate)();
    const [agents, setAgents] = (0, react_1.useState)([]);
    const [conversations, setConversations] = (0, react_1.useState)([]);
    const [isAgentsLoading, setIsAgentsLoading] = (0, react_1.useState)(true);
    // Load agents only when the active dataset changes
    (0, react_1.useEffect)(() => {
        if (isDatasetLoading || !dataSetId)
            return;
        const loadAgents = async () => {
            try {
                setIsAgentsLoading(true);
                const agentsRes = await admin_client_1.adminApiClient.agents().getDatasetAgents(dataSetId);
                setAgents(agentsRes.filter((agent) => !agent.corrupted));
            }
            catch (error) {
                console.error("Failed to load agents:", error);
            }
            finally {
                setIsAgentsLoading(false);
            }
        };
        void loadAgents();
    }, [dataSetId, isDatasetLoading]);
    // Reload conversations when the agent or active conversation changes (background, no spinner)
    (0, react_1.useEffect)(() => {
        if (!dataSetId || !currentAgentId)
            return;
        const loadConversations = async () => {
            try {
                const conversationsRes = await admin_client_1.adminApiClient
                    .conversations()
                    .getConversations(dataSetId, currentAgentId, 1);
                setConversations(conversationsRes.results || []);
            }
            catch (error) {
                console.error("Failed to load conversations:", error);
            }
        };
        void loadConversations();
    }, [dataSetId, currentAgentId, currentConversationId]);
    const handleAgentClick = (agentId) => {
        navigate(`/enthusiast/chat/new?agent=${encodeURIComponent(agentId)}`);
    };
    const handleConversationClick = (conversationId) => {
        navigate(`/enthusiast/chat/${conversationId}`);
    };
    const handleNewChat = () => {
        navigate(`/enthusiast/chat/new?agent=${encodeURIComponent(currentAgentId)}`);
    };
    if (isAgentsLoading) {
        return (0, jsx_runtime_1.jsx)(spinner_1.LoadingSpinner, {});
    }
    return ((0, jsx_runtime_1.jsxs)("div", { className: "w-64 bg-background flex flex-col h-full overflow-hidden", children: [(0, jsx_runtime_1.jsx)("div", { className: "px-2 pt-2 h-[40%] min-h-0 pb-4", children: (0, jsx_runtime_1.jsx)(agent_list_1.AgentList, { agents: agents, currentAgentId: currentAgentId, onAgentClick: handleAgentClick }) }), (0, jsx_runtime_1.jsx)("div", { className: "px-2 pb-2 h-[60%] min-h-0", children: (0, jsx_runtime_1.jsx)(conversation_history_1.ConversationHistory, { conversations: conversations.slice(0, 10), currentConversationId: currentConversationId, onConversationClick: handleConversationClick, onNewChat: handleNewChat }) })] }));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hhdC1zaWRlYmFyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL2NvbXBvbmVudHMvY2hhdC9jaGF0LXNpZGViYXIudHN4Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBZUEsa0NBaUZDOztBQWhHRCxpQ0FBNEM7QUFDNUMsdURBQStDO0FBQy9DLCtEQUE4RDtBQUM5RCw2RUFBd0U7QUFHeEUsNkNBQXlDO0FBQ3pDLGlFQUE2RDtBQUM3RCw0REFBZ0U7QUFPaEUsU0FBZ0IsV0FBVyxDQUFDLEVBQUUsY0FBYyxFQUFFLHFCQUFxQixFQUFvQjtJQUNyRixNQUFNLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBRSxnQkFBZ0IsRUFBRSxHQUFHLElBQUEscUNBQWdCLEdBQUUsQ0FBQztJQUNwRSxNQUFNLFNBQVMsR0FBRyxPQUFPLEVBQUUsV0FBVyxJQUFJLElBQUksQ0FBQztJQUMvQyxNQUFNLFFBQVEsR0FBRyxJQUFBLDhCQUFXLEdBQUUsQ0FBQztJQUUvQixNQUFNLENBQUMsTUFBTSxFQUFFLFNBQVMsQ0FBQyxHQUFHLElBQUEsZ0JBQVEsRUFBVSxFQUFFLENBQUMsQ0FBQztJQUNsRCxNQUFNLENBQUMsYUFBYSxFQUFFLGdCQUFnQixDQUFDLEdBQUcsSUFBQSxnQkFBUSxFQUFpQixFQUFFLENBQUMsQ0FBQztJQUN2RSxNQUFNLENBQUMsZUFBZSxFQUFFLGtCQUFrQixDQUFDLEdBQUcsSUFBQSxnQkFBUSxFQUFDLElBQUksQ0FBQyxDQUFDO0lBRTdELG1EQUFtRDtJQUNuRCxJQUFBLGlCQUFTLEVBQUMsR0FBRyxFQUFFO1FBQ2IsSUFBSSxnQkFBZ0IsSUFBSSxDQUFDLFNBQVM7WUFBRSxPQUFPO1FBRTNDLE1BQU0sVUFBVSxHQUFHLEtBQUssSUFBSSxFQUFFO1lBQzVCLElBQUksQ0FBQztnQkFDSCxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDekIsTUFBTSxTQUFTLEdBQUcsTUFBTSw2QkFBYyxDQUFDLE1BQU0sRUFBRSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUM1RSxTQUFTLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztZQUMzRCxDQUFDO1lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztnQkFDZixPQUFPLENBQUMsS0FBSyxDQUFDLHdCQUF3QixFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ2pELENBQUM7b0JBQVMsQ0FBQztnQkFDVCxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUM1QixDQUFDO1FBQ0gsQ0FBQyxDQUFDO1FBRUYsS0FBSyxVQUFVLEVBQUUsQ0FBQztJQUNwQixDQUFDLEVBQUUsQ0FBQyxTQUFTLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO0lBRWxDLDhGQUE4RjtJQUM5RixJQUFBLGlCQUFTLEVBQUMsR0FBRyxFQUFFO1FBQ2IsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLGNBQWM7WUFBRSxPQUFPO1FBRTFDLE1BQU0saUJBQWlCLEdBQUcsS0FBSyxJQUFJLEVBQUU7WUFDbkMsSUFBSSxDQUFDO2dCQUNILE1BQU0sZ0JBQWdCLEdBQUcsTUFBTSw2QkFBYztxQkFDMUMsYUFBYSxFQUFFO3FCQUNmLGdCQUFnQixDQUFDLFNBQVMsRUFBRSxjQUFjLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQ2xELGdCQUFnQixDQUFDLGdCQUFnQixDQUFDLE9BQU8sSUFBSSxFQUFFLENBQUMsQ0FBQztZQUNuRCxDQUFDO1lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztnQkFDZixPQUFPLENBQUMsS0FBSyxDQUFDLCtCQUErQixFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ3hELENBQUM7UUFDSCxDQUFDLENBQUM7UUFFRixLQUFLLGlCQUFpQixFQUFFLENBQUM7SUFDM0IsQ0FBQyxFQUFFLENBQUMsU0FBUyxFQUFFLGNBQWMsRUFBRSxxQkFBcUIsQ0FBQyxDQUFDLENBQUM7SUFFdkQsTUFBTSxnQkFBZ0IsR0FBRyxDQUFDLE9BQWUsRUFBRSxFQUFFO1FBQzNDLFFBQVEsQ0FBQyw4QkFBOEIsa0JBQWtCLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ3hFLENBQUMsQ0FBQztJQUVGLE1BQU0sdUJBQXVCLEdBQUcsQ0FBQyxjQUFzQixFQUFFLEVBQUU7UUFDekQsUUFBUSxDQUFDLG9CQUFvQixjQUFjLEVBQUUsQ0FBQyxDQUFDO0lBQ2pELENBQUMsQ0FBQztJQUVGLE1BQU0sYUFBYSxHQUFHLEdBQUcsRUFBRTtRQUN6QixRQUFRLENBQUMsOEJBQThCLGtCQUFrQixDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUMvRSxDQUFDLENBQUM7SUFFRixJQUFJLGVBQWUsRUFBRSxDQUFDO1FBQ3BCLE9BQU8sdUJBQUMsd0JBQWMsS0FBRyxDQUFDO0lBQzVCLENBQUM7SUFFRCxPQUFPLENBQ0wsaUNBQUssU0FBUyxFQUFDLHlEQUF5RCxhQUN0RSxnQ0FBSyxTQUFTLEVBQUMsZ0NBQWdDLFlBQzdDLHVCQUFDLHNCQUFTLElBQ1IsTUFBTSxFQUFFLE1BQU0sRUFDZCxjQUFjLEVBQUUsY0FBYyxFQUM5QixZQUFZLEVBQUUsZ0JBQWdCLEdBQzlCLEdBQ0UsRUFDTixnQ0FBSyxTQUFTLEVBQUMsMkJBQTJCLFlBQ3hDLHVCQUFDLDBDQUFtQixJQUNsQixhQUFhLEVBQUUsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQ3pDLHFCQUFxQixFQUFFLHFCQUFxQixFQUM1QyxtQkFBbUIsRUFBRSx1QkFBdUIsRUFDNUMsU0FBUyxFQUFFLGFBQWEsR0FDeEIsR0FDRSxJQUNGLENBQ1AsQ0FBQztBQUNKLENBQUMifQ==