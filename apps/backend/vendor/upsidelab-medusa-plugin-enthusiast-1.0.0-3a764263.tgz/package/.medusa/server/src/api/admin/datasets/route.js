"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = void 0;
const enthusiast_1 = require("../../../modules/enthusiast");
const wrappers_1 = require("../../../api/wrappers");
exports.GET = (0, wrappers_1.withErrorHandler)(async (req, res) => {
    const enthusiastService = req.scope.resolve(enthusiast_1.ENTHUSIAST_MODULE);
    res.json(await enthusiastService.listInternalDatasets(req));
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2RhdGFzZXRzL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUVBLDREQUFnRTtBQUNoRSxvREFBeUQ7QUFFNUMsUUFBQSxHQUFHLEdBQUcsSUFBQSwyQkFBZ0IsRUFDakMsS0FBSyxFQUFFLEdBQStCLEVBQUUsR0FBbUIsRUFBRSxFQUFFO0lBQzdELE1BQU0saUJBQWlCLEdBQXNCLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLDhCQUFpQixDQUFDLENBQUM7SUFDbEYsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLGlCQUFpQixDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDOUQsQ0FBQyxDQUNGLENBQUMifQ==