"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PageMain = PageMain;
const jsx_runtime_1 = require("react/jsx-runtime");
const utils_1 = require("../../admin/lib/utils");
const ui_1 = require("@medusajs/ui");
function PageMain({ children, className }) {
    return ((0, jsx_runtime_1.jsx)(ui_1.Container, { className: (0, utils_1.cn)("flex flex-col divide-y p-0 pt-4 h-full overflow-hidden", className), children: children }));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZS1tYWluLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL2NvbXBvbmVudHMvdXRpbHMvcGFnZS1tYWluLnRzeCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQVNBLDRCQU1DOztBQWRELGlEQUEyQztBQUMzQyxxQ0FBeUM7QUFPekMsU0FBZ0IsUUFBUSxDQUFDLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBaUI7SUFDN0QsT0FBTyxDQUNMLHVCQUFDLGNBQVMsSUFBQyxTQUFTLEVBQUUsSUFBQSxVQUFFLEVBQUMsd0RBQXdELEVBQUUsU0FBUyxDQUFDLFlBQzFGLFFBQVEsR0FDQyxDQUNiLENBQUM7QUFDSixDQUFDIn0=