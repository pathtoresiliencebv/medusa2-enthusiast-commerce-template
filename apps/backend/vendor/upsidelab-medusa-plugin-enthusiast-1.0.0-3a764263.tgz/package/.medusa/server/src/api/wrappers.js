"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.withErrorHandler = withErrorHandler;
const utils_1 = require("@medusajs/utils");
const client_1 = require("../modules/enthusiast/api/client");
const service_1 = require("../modules/enthusiast/service");
const DEFAULT_ENTHUSIAST_ERROR_MESSAGE = "Unexpected Enthusiast error occurred.";
function withErrorHandler(handler) {
    return async (req, res) => {
        try {
            await handler(req, res);
        }
        catch (error) {
            const logger = req.scope.resolve("logger");
            if (error instanceof client_1.EnthusiastAPIError) {
                logger.error(`Enthusiast API error: ${error.message}, ${error.body}`);
                let errorType = utils_1.MedusaError.Types.UNEXPECTED_STATE;
                let errorMessage = DEFAULT_ENTHUSIAST_ERROR_MESSAGE;
                if (req.method === "POST" && error.status === 400) {
                    errorType = utils_1.MedusaError.Types.INVALID_DATA;
                }
                if (error.body) {
                    errorMessage = error.body;
                }
                throw new utils_1.MedusaError(errorType, errorMessage);
            }
            if (error instanceof service_1.EnthusiastServiceError) {
                throw new utils_1.MedusaError(utils_1.MedusaError.Types.UNEXPECTED_STATE, error.message);
            }
            throw error;
        }
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoid3JhcHBlcnMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvYXBpL3dyYXBwZXJzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBU0EsNENBMkJDO0FBbkNELDJDQUE4QztBQUM5Qyw2REFBc0U7QUFDdEUsMkRBQXVFO0FBSXZFLE1BQU0sZ0NBQWdDLEdBQUcsdUNBQXVDLENBQUM7QUFFakYsU0FBZ0IsZ0JBQWdCLENBQUMsT0FBc0I7SUFDckQsT0FBTyxLQUFLLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFO1FBQ3hCLElBQUksQ0FBQztZQUNILE1BQU0sT0FBTyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUMxQixDQUFDO1FBQUMsT0FBTyxLQUFVLEVBQUUsQ0FBQztZQUNwQixNQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUMzQyxJQUFJLEtBQUssWUFBWSwyQkFBa0IsRUFBRSxDQUFDO2dCQUN4QyxNQUFNLENBQUMsS0FBSyxDQUFDLHlCQUF5QixLQUFLLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDO2dCQUN0RSxJQUFJLFNBQVMsR0FBRyxtQkFBVyxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQztnQkFDbkQsSUFBSSxZQUFZLEdBQUcsZ0NBQWdDLENBQUM7Z0JBRXBELElBQUksR0FBRyxDQUFDLE1BQU0sS0FBSyxNQUFNLElBQUksS0FBSyxDQUFDLE1BQU0sS0FBSyxHQUFHLEVBQUUsQ0FBQztvQkFDbEQsU0FBUyxHQUFHLG1CQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQztnQkFDN0MsQ0FBQztnQkFFRCxJQUFJLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDZixZQUFZLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQztnQkFDNUIsQ0FBQztnQkFFRCxNQUFNLElBQUksbUJBQVcsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUM7WUFDakQsQ0FBQztZQUNELElBQUksS0FBSyxZQUFZLGdDQUFzQixFQUFFLENBQUM7Z0JBQzVDLE1BQU0sSUFBSSxtQkFBVyxDQUFDLG1CQUFXLENBQUMsS0FBSyxDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUMzRSxDQUFDO1lBQ0QsTUFBTSxLQUFLLENBQUM7UUFDZCxDQUFDO0lBQ0gsQ0FBQyxDQUFDO0FBQ0osQ0FBQyJ9