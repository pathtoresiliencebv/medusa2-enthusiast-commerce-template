"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = checkOptionsLoader;
const awilix_1 = require("@medusajs/framework/awilix");
async function checkOptionsLoader({ options, container }) {
    const configModule = container.resolve("configModule");
    const moduleOptions = options;
    const required = {
        enthusiastApiUrl: moduleOptions.enthusiastApiUrl,
        enthusiastServiceAccountToken: moduleOptions.enthusiastServiceAccountToken,
        enthusiastMedusaIntegrationName: moduleOptions.enthusiastMedusaIntegrationName,
    };
    const defaults = {
        medusaBackendUrl: configModule.admin.backendUrl !== "/"
            ? configModule.admin.backendUrl
            : "http://host.docker.internal:9000",
        medusaAdminUrl: "http://localhost:9000",
    };
    const errors = Object.entries(required)
        .filter(([_key, value]) => !value)
        .map(([key]) => `Missing required option: ${key}`);
    if (errors.length > 0) {
        throw new Error(`[enthusiast] Plugin configuration error:\n${errors.join("\n")}`);
    }
    const cleanedOptions = Object.fromEntries(Object.entries(moduleOptions).filter(([, v]) => v !== undefined));
    const finalOptions = {
        ...defaults,
        ...cleanedOptions,
    };
    container.register({
        options: (0, awilix_1.asValue)(finalOptions),
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hlY2stb3B0aW9ucy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL2VudGh1c2lhc3QvbG9hZGVycy9jaGVjay1vcHRpb25zLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBSUEscUNBa0NDO0FBcENELHVEQUFxRDtBQUV0QyxLQUFLLFVBQVUsa0JBQWtCLENBQUMsRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFpQjtJQUNwRixNQUFNLFlBQVksR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQ3ZELE1BQU0sYUFBYSxHQUFHLE9BQXdCLENBQUM7SUFDL0MsTUFBTSxRQUFRLEdBQUc7UUFDZixnQkFBZ0IsRUFBRSxhQUFhLENBQUMsZ0JBQWdCO1FBQ2hELDZCQUE2QixFQUFFLGFBQWEsQ0FBQyw2QkFBNkI7UUFDMUUsK0JBQStCLEVBQUUsYUFBYSxDQUFDLCtCQUErQjtLQUMvRSxDQUFDO0lBQ0YsTUFBTSxRQUFRLEdBQUc7UUFDZixnQkFBZ0IsRUFDZCxZQUFZLENBQUMsS0FBSyxDQUFDLFVBQVUsS0FBSyxHQUFHO1lBQ25DLENBQUMsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLFVBQVU7WUFDL0IsQ0FBQyxDQUFDLGtDQUFrQztRQUN4QyxjQUFjLEVBQUUsdUJBQXVCO0tBQ3hDLENBQUM7SUFFRixNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQztTQUNwQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUM7U0FDakMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLENBQUMsNEJBQTRCLEdBQUcsRUFBRSxDQUFDLENBQUM7SUFFckQsSUFBSSxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO1FBQ3RCLE1BQU0sSUFBSSxLQUFLLENBQUMsNkNBQTZDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ3BGLENBQUM7SUFDRCxNQUFNLGNBQWMsR0FBRyxNQUFNLENBQUMsV0FBVyxDQUN2QyxNQUFNLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUNqRSxDQUFDO0lBQ0YsTUFBTSxZQUFZLEdBQUc7UUFDbkIsR0FBRyxRQUFRO1FBQ1gsR0FBRyxjQUFjO0tBQ2xCLENBQUM7SUFFRixTQUFTLENBQUMsUUFBUSxDQUFDO1FBQ2pCLE9BQU8sRUFBRSxJQUFBLGdCQUFPLEVBQUMsWUFBWSxDQUFDO0tBQy9CLENBQUMsQ0FBQztBQUNMLENBQUMifQ==