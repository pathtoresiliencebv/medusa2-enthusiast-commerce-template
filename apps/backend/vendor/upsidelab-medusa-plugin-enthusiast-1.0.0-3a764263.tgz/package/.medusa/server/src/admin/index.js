"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
const jsxRuntime = require("react/jsx-runtime");
const adminSdk = require("@medusajs/admin-sdk");
const React = require("react");
const Medusa = require("@medusajs/js-sdk");
const ui = require("@medusajs/ui");
const reactRouterDom = require("react-router-dom");
const icons = require("@medusajs/icons");
require("react-dom");
const reactDropzone = require("react-dropzone");
const lucideReact = require("lucide-react");
const classVarianceAuthority = require("class-variance-authority");
const DOMPurify = require("dompurify");
const _interopDefault = (e) => e && e.__esModule ? e : { default: e };
function _interopNamespace(e) {
  if (e && e.__esModule) return e;
  const n = Object.create(null, { [Symbol.toStringTag]: { value: "Module" } });
  if (e) {
    for (const k in e) {
      if (k !== "default") {
        const d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: () => e[k]
        });
      }
    }
  }
  n.default = e;
  return Object.freeze(n);
}
const React__namespace = /* @__PURE__ */ _interopNamespace(React);
const Medusa__default = /* @__PURE__ */ _interopDefault(Medusa);
const DOMPurify__default = /* @__PURE__ */ _interopDefault(DOMPurify);
function r(e) {
  var t, f, n = "";
  if ("string" == typeof e || "number" == typeof e) n += e;
  else if ("object" == typeof e) if (Array.isArray(e)) for (t = 0; t < e.length; t++) e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
  else for (t in e) e[t] && (n && (n += " "), n += t);
  return n;
}
function clsx() {
  for (var e, t, f = 0, n = ""; f < arguments.length; ) (e = arguments[f++]) && (t = r(e)) && (n && (n += " "), n += t);
  return n;
}
const CLASS_PART_SEPARATOR = "-";
const createClassGroupUtils = (config2) => {
  const classMap = createClassMap(config2);
  const {
    conflictingClassGroups,
    conflictingClassGroupModifiers
  } = config2;
  const getClassGroupId = (className) => {
    const classParts = className.split(CLASS_PART_SEPARATOR);
    if (classParts[0] === "" && classParts.length !== 1) {
      classParts.shift();
    }
    return getGroupRecursive(classParts, classMap) || getGroupIdForArbitraryProperty(className);
  };
  const getConflictingClassGroupIds = (classGroupId, hasPostfixModifier) => {
    const conflicts = conflictingClassGroups[classGroupId] || [];
    if (hasPostfixModifier && conflictingClassGroupModifiers[classGroupId]) {
      return [...conflicts, ...conflictingClassGroupModifiers[classGroupId]];
    }
    return conflicts;
  };
  return {
    getClassGroupId,
    getConflictingClassGroupIds
  };
};
const getGroupRecursive = (classParts, classPartObject) => {
  var _a;
  if (classParts.length === 0) {
    return classPartObject.classGroupId;
  }
  const currentClassPart = classParts[0];
  const nextClassPartObject = classPartObject.nextPart.get(currentClassPart);
  const classGroupFromNextClassPart = nextClassPartObject ? getGroupRecursive(classParts.slice(1), nextClassPartObject) : void 0;
  if (classGroupFromNextClassPart) {
    return classGroupFromNextClassPart;
  }
  if (classPartObject.validators.length === 0) {
    return void 0;
  }
  const classRest = classParts.join(CLASS_PART_SEPARATOR);
  return (_a = classPartObject.validators.find(({
    validator
  }) => validator(classRest))) == null ? void 0 : _a.classGroupId;
};
const arbitraryPropertyRegex = /^\[(.+)\]$/;
const getGroupIdForArbitraryProperty = (className) => {
  if (arbitraryPropertyRegex.test(className)) {
    const arbitraryPropertyClassName = arbitraryPropertyRegex.exec(className)[1];
    const property = arbitraryPropertyClassName == null ? void 0 : arbitraryPropertyClassName.substring(0, arbitraryPropertyClassName.indexOf(":"));
    if (property) {
      return "arbitrary.." + property;
    }
  }
};
const createClassMap = (config2) => {
  const {
    theme,
    prefix
  } = config2;
  const classMap = {
    nextPart: /* @__PURE__ */ new Map(),
    validators: []
  };
  const prefixedClassGroupEntries = getPrefixedClassGroupEntries(Object.entries(config2.classGroups), prefix);
  prefixedClassGroupEntries.forEach(([classGroupId, classGroup]) => {
    processClassesRecursively(classGroup, classMap, classGroupId, theme);
  });
  return classMap;
};
const processClassesRecursively = (classGroup, classPartObject, classGroupId, theme) => {
  classGroup.forEach((classDefinition) => {
    if (typeof classDefinition === "string") {
      const classPartObjectToEdit = classDefinition === "" ? classPartObject : getPart(classPartObject, classDefinition);
      classPartObjectToEdit.classGroupId = classGroupId;
      return;
    }
    if (typeof classDefinition === "function") {
      if (isThemeGetter(classDefinition)) {
        processClassesRecursively(classDefinition(theme), classPartObject, classGroupId, theme);
        return;
      }
      classPartObject.validators.push({
        validator: classDefinition,
        classGroupId
      });
      return;
    }
    Object.entries(classDefinition).forEach(([key, classGroup2]) => {
      processClassesRecursively(classGroup2, getPart(classPartObject, key), classGroupId, theme);
    });
  });
};
const getPart = (classPartObject, path) => {
  let currentClassPartObject = classPartObject;
  path.split(CLASS_PART_SEPARATOR).forEach((pathPart) => {
    if (!currentClassPartObject.nextPart.has(pathPart)) {
      currentClassPartObject.nextPart.set(pathPart, {
        nextPart: /* @__PURE__ */ new Map(),
        validators: []
      });
    }
    currentClassPartObject = currentClassPartObject.nextPart.get(pathPart);
  });
  return currentClassPartObject;
};
const isThemeGetter = (func) => func.isThemeGetter;
const getPrefixedClassGroupEntries = (classGroupEntries, prefix) => {
  if (!prefix) {
    return classGroupEntries;
  }
  return classGroupEntries.map(([classGroupId, classGroup]) => {
    const prefixedClassGroup = classGroup.map((classDefinition) => {
      if (typeof classDefinition === "string") {
        return prefix + classDefinition;
      }
      if (typeof classDefinition === "object") {
        return Object.fromEntries(Object.entries(classDefinition).map(([key, value]) => [prefix + key, value]));
      }
      return classDefinition;
    });
    return [classGroupId, prefixedClassGroup];
  });
};
const createLruCache = (maxCacheSize) => {
  if (maxCacheSize < 1) {
    return {
      get: () => void 0,
      set: () => {
      }
    };
  }
  let cacheSize = 0;
  let cache = /* @__PURE__ */ new Map();
  let previousCache = /* @__PURE__ */ new Map();
  const update = (key, value) => {
    cache.set(key, value);
    cacheSize++;
    if (cacheSize > maxCacheSize) {
      cacheSize = 0;
      previousCache = cache;
      cache = /* @__PURE__ */ new Map();
    }
  };
  return {
    get(key) {
      let value = cache.get(key);
      if (value !== void 0) {
        return value;
      }
      if ((value = previousCache.get(key)) !== void 0) {
        update(key, value);
        return value;
      }
    },
    set(key, value) {
      if (cache.has(key)) {
        cache.set(key, value);
      } else {
        update(key, value);
      }
    }
  };
};
const IMPORTANT_MODIFIER = "!";
const createParseClassName = (config2) => {
  const {
    separator,
    experimentalParseClassName
  } = config2;
  const isSeparatorSingleCharacter = separator.length === 1;
  const firstSeparatorCharacter = separator[0];
  const separatorLength = separator.length;
  const parseClassName = (className) => {
    const modifiers = [];
    let bracketDepth = 0;
    let modifierStart = 0;
    let postfixModifierPosition;
    for (let index = 0; index < className.length; index++) {
      let currentCharacter = className[index];
      if (bracketDepth === 0) {
        if (currentCharacter === firstSeparatorCharacter && (isSeparatorSingleCharacter || className.slice(index, index + separatorLength) === separator)) {
          modifiers.push(className.slice(modifierStart, index));
          modifierStart = index + separatorLength;
          continue;
        }
        if (currentCharacter === "/") {
          postfixModifierPosition = index;
          continue;
        }
      }
      if (currentCharacter === "[") {
        bracketDepth++;
      } else if (currentCharacter === "]") {
        bracketDepth--;
      }
    }
    const baseClassNameWithImportantModifier = modifiers.length === 0 ? className : className.substring(modifierStart);
    const hasImportantModifier = baseClassNameWithImportantModifier.startsWith(IMPORTANT_MODIFIER);
    const baseClassName = hasImportantModifier ? baseClassNameWithImportantModifier.substring(1) : baseClassNameWithImportantModifier;
    const maybePostfixModifierPosition = postfixModifierPosition && postfixModifierPosition > modifierStart ? postfixModifierPosition - modifierStart : void 0;
    return {
      modifiers,
      hasImportantModifier,
      baseClassName,
      maybePostfixModifierPosition
    };
  };
  if (experimentalParseClassName) {
    return (className) => experimentalParseClassName({
      className,
      parseClassName
    });
  }
  return parseClassName;
};
const sortModifiers = (modifiers) => {
  if (modifiers.length <= 1) {
    return modifiers;
  }
  const sortedModifiers = [];
  let unsortedModifiers = [];
  modifiers.forEach((modifier) => {
    const isArbitraryVariant = modifier[0] === "[";
    if (isArbitraryVariant) {
      sortedModifiers.push(...unsortedModifiers.sort(), modifier);
      unsortedModifiers = [];
    } else {
      unsortedModifiers.push(modifier);
    }
  });
  sortedModifiers.push(...unsortedModifiers.sort());
  return sortedModifiers;
};
const createConfigUtils = (config2) => ({
  cache: createLruCache(config2.cacheSize),
  parseClassName: createParseClassName(config2),
  ...createClassGroupUtils(config2)
});
const SPLIT_CLASSES_REGEX = /\s+/;
const mergeClassList = (classList, configUtils) => {
  const {
    parseClassName,
    getClassGroupId,
    getConflictingClassGroupIds
  } = configUtils;
  const classGroupsInConflict = [];
  const classNames = classList.trim().split(SPLIT_CLASSES_REGEX);
  let result = "";
  for (let index = classNames.length - 1; index >= 0; index -= 1) {
    const originalClassName = classNames[index];
    const {
      modifiers,
      hasImportantModifier,
      baseClassName,
      maybePostfixModifierPosition
    } = parseClassName(originalClassName);
    let hasPostfixModifier = Boolean(maybePostfixModifierPosition);
    let classGroupId = getClassGroupId(hasPostfixModifier ? baseClassName.substring(0, maybePostfixModifierPosition) : baseClassName);
    if (!classGroupId) {
      if (!hasPostfixModifier) {
        result = originalClassName + (result.length > 0 ? " " + result : result);
        continue;
      }
      classGroupId = getClassGroupId(baseClassName);
      if (!classGroupId) {
        result = originalClassName + (result.length > 0 ? " " + result : result);
        continue;
      }
      hasPostfixModifier = false;
    }
    const variantModifier = sortModifiers(modifiers).join(":");
    const modifierId = hasImportantModifier ? variantModifier + IMPORTANT_MODIFIER : variantModifier;
    const classId = modifierId + classGroupId;
    if (classGroupsInConflict.includes(classId)) {
      continue;
    }
    classGroupsInConflict.push(classId);
    const conflictGroups = getConflictingClassGroupIds(classGroupId, hasPostfixModifier);
    for (let i = 0; i < conflictGroups.length; ++i) {
      const group = conflictGroups[i];
      classGroupsInConflict.push(modifierId + group);
    }
    result = originalClassName + (result.length > 0 ? " " + result : result);
  }
  return result;
};
function twJoin() {
  let index = 0;
  let argument;
  let resolvedValue;
  let string = "";
  while (index < arguments.length) {
    if (argument = arguments[index++]) {
      if (resolvedValue = toValue(argument)) {
        string && (string += " ");
        string += resolvedValue;
      }
    }
  }
  return string;
}
const toValue = (mix) => {
  if (typeof mix === "string") {
    return mix;
  }
  let resolvedValue;
  let string = "";
  for (let k = 0; k < mix.length; k++) {
    if (mix[k]) {
      if (resolvedValue = toValue(mix[k])) {
        string && (string += " ");
        string += resolvedValue;
      }
    }
  }
  return string;
};
function createTailwindMerge(createConfigFirst, ...createConfigRest) {
  let configUtils;
  let cacheGet;
  let cacheSet;
  let functionToCall = initTailwindMerge;
  function initTailwindMerge(classList) {
    const config2 = createConfigRest.reduce((previousConfig, createConfigCurrent) => createConfigCurrent(previousConfig), createConfigFirst());
    configUtils = createConfigUtils(config2);
    cacheGet = configUtils.cache.get;
    cacheSet = configUtils.cache.set;
    functionToCall = tailwindMerge;
    return tailwindMerge(classList);
  }
  function tailwindMerge(classList) {
    const cachedResult = cacheGet(classList);
    if (cachedResult) {
      return cachedResult;
    }
    const result = mergeClassList(classList, configUtils);
    cacheSet(classList, result);
    return result;
  }
  return function callTailwindMerge() {
    return functionToCall(twJoin.apply(null, arguments));
  };
}
const fromTheme = (key) => {
  const themeGetter = (theme) => theme[key] || [];
  themeGetter.isThemeGetter = true;
  return themeGetter;
};
const arbitraryValueRegex = /^\[(?:([a-z-]+):)?(.+)\]$/i;
const fractionRegex = /^\d+\/\d+$/;
const stringLengths = /* @__PURE__ */ new Set(["px", "full", "screen"]);
const tshirtUnitRegex = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/;
const lengthUnitRegex = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/;
const colorFunctionRegex = /^(rgba?|hsla?|hwb|(ok)?(lab|lch))\(.+\)$/;
const shadowRegex = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/;
const imageRegex = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/;
const isLength = (value) => isNumber(value) || stringLengths.has(value) || fractionRegex.test(value);
const isArbitraryLength = (value) => getIsArbitraryValue(value, "length", isLengthOnly);
const isNumber = (value) => Boolean(value) && !Number.isNaN(Number(value));
const isArbitraryNumber = (value) => getIsArbitraryValue(value, "number", isNumber);
const isInteger = (value) => Boolean(value) && Number.isInteger(Number(value));
const isPercent = (value) => value.endsWith("%") && isNumber(value.slice(0, -1));
const isArbitraryValue = (value) => arbitraryValueRegex.test(value);
const isTshirtSize = (value) => tshirtUnitRegex.test(value);
const sizeLabels = /* @__PURE__ */ new Set(["length", "size", "percentage"]);
const isArbitrarySize = (value) => getIsArbitraryValue(value, sizeLabels, isNever);
const isArbitraryPosition = (value) => getIsArbitraryValue(value, "position", isNever);
const imageLabels = /* @__PURE__ */ new Set(["image", "url"]);
const isArbitraryImage = (value) => getIsArbitraryValue(value, imageLabels, isImage);
const isArbitraryShadow = (value) => getIsArbitraryValue(value, "", isShadow);
const isAny = () => true;
const getIsArbitraryValue = (value, label, testValue) => {
  const result = arbitraryValueRegex.exec(value);
  if (result) {
    if (result[1]) {
      return typeof label === "string" ? result[1] === label : label.has(result[1]);
    }
    return testValue(result[2]);
  }
  return false;
};
const isLengthOnly = (value) => (
  // `colorFunctionRegex` check is necessary because color functions can have percentages in them which which would be incorrectly classified as lengths.
  // For example, `hsl(0 0% 0%)` would be classified as a length without this check.
  // I could also use lookbehind assertion in `lengthUnitRegex` but that isn't supported widely enough.
  lengthUnitRegex.test(value) && !colorFunctionRegex.test(value)
);
const isNever = () => false;
const isShadow = (value) => shadowRegex.test(value);
const isImage = (value) => imageRegex.test(value);
const getDefaultConfig = () => {
  const colors = fromTheme("colors");
  const spacing = fromTheme("spacing");
  const blur = fromTheme("blur");
  const brightness = fromTheme("brightness");
  const borderColor = fromTheme("borderColor");
  const borderRadius = fromTheme("borderRadius");
  const borderSpacing = fromTheme("borderSpacing");
  const borderWidth = fromTheme("borderWidth");
  const contrast = fromTheme("contrast");
  const grayscale = fromTheme("grayscale");
  const hueRotate = fromTheme("hueRotate");
  const invert = fromTheme("invert");
  const gap = fromTheme("gap");
  const gradientColorStops = fromTheme("gradientColorStops");
  const gradientColorStopPositions = fromTheme("gradientColorStopPositions");
  const inset = fromTheme("inset");
  const margin = fromTheme("margin");
  const opacity = fromTheme("opacity");
  const padding = fromTheme("padding");
  const saturate = fromTheme("saturate");
  const scale = fromTheme("scale");
  const sepia = fromTheme("sepia");
  const skew = fromTheme("skew");
  const space = fromTheme("space");
  const translate = fromTheme("translate");
  const getOverscroll = () => ["auto", "contain", "none"];
  const getOverflow = () => ["auto", "hidden", "clip", "visible", "scroll"];
  const getSpacingWithAutoAndArbitrary = () => ["auto", isArbitraryValue, spacing];
  const getSpacingWithArbitrary = () => [isArbitraryValue, spacing];
  const getLengthWithEmptyAndArbitrary = () => ["", isLength, isArbitraryLength];
  const getNumberWithAutoAndArbitrary = () => ["auto", isNumber, isArbitraryValue];
  const getPositions = () => ["bottom", "center", "left", "left-bottom", "left-top", "right", "right-bottom", "right-top", "top"];
  const getLineStyles = () => ["solid", "dashed", "dotted", "double", "none"];
  const getBlendModes = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"];
  const getAlign = () => ["start", "end", "center", "between", "around", "evenly", "stretch"];
  const getZeroAndEmpty = () => ["", "0", isArbitraryValue];
  const getBreaks = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"];
  const getNumberAndArbitrary = () => [isNumber, isArbitraryValue];
  return {
    cacheSize: 500,
    separator: ":",
    theme: {
      colors: [isAny],
      spacing: [isLength, isArbitraryLength],
      blur: ["none", "", isTshirtSize, isArbitraryValue],
      brightness: getNumberAndArbitrary(),
      borderColor: [colors],
      borderRadius: ["none", "", "full", isTshirtSize, isArbitraryValue],
      borderSpacing: getSpacingWithArbitrary(),
      borderWidth: getLengthWithEmptyAndArbitrary(),
      contrast: getNumberAndArbitrary(),
      grayscale: getZeroAndEmpty(),
      hueRotate: getNumberAndArbitrary(),
      invert: getZeroAndEmpty(),
      gap: getSpacingWithArbitrary(),
      gradientColorStops: [colors],
      gradientColorStopPositions: [isPercent, isArbitraryLength],
      inset: getSpacingWithAutoAndArbitrary(),
      margin: getSpacingWithAutoAndArbitrary(),
      opacity: getNumberAndArbitrary(),
      padding: getSpacingWithArbitrary(),
      saturate: getNumberAndArbitrary(),
      scale: getNumberAndArbitrary(),
      sepia: getZeroAndEmpty(),
      skew: getNumberAndArbitrary(),
      space: getSpacingWithArbitrary(),
      translate: getSpacingWithArbitrary()
    },
    classGroups: {
      // Layout
      /**
       * Aspect Ratio
       * @see https://tailwindcss.com/docs/aspect-ratio
       */
      aspect: [{
        aspect: ["auto", "square", "video", isArbitraryValue]
      }],
      /**
       * Container
       * @see https://tailwindcss.com/docs/container
       */
      container: ["container"],
      /**
       * Columns
       * @see https://tailwindcss.com/docs/columns
       */
      columns: [{
        columns: [isTshirtSize]
      }],
      /**
       * Break After
       * @see https://tailwindcss.com/docs/break-after
       */
      "break-after": [{
        "break-after": getBreaks()
      }],
      /**
       * Break Before
       * @see https://tailwindcss.com/docs/break-before
       */
      "break-before": [{
        "break-before": getBreaks()
      }],
      /**
       * Break Inside
       * @see https://tailwindcss.com/docs/break-inside
       */
      "break-inside": [{
        "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
      }],
      /**
       * Box Decoration Break
       * @see https://tailwindcss.com/docs/box-decoration-break
       */
      "box-decoration": [{
        "box-decoration": ["slice", "clone"]
      }],
      /**
       * Box Sizing
       * @see https://tailwindcss.com/docs/box-sizing
       */
      box: [{
        box: ["border", "content"]
      }],
      /**
       * Display
       * @see https://tailwindcss.com/docs/display
       */
      display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
      /**
       * Floats
       * @see https://tailwindcss.com/docs/float
       */
      float: [{
        float: ["right", "left", "none", "start", "end"]
      }],
      /**
       * Clear
       * @see https://tailwindcss.com/docs/clear
       */
      clear: [{
        clear: ["left", "right", "both", "none", "start", "end"]
      }],
      /**
       * Isolation
       * @see https://tailwindcss.com/docs/isolation
       */
      isolation: ["isolate", "isolation-auto"],
      /**
       * Object Fit
       * @see https://tailwindcss.com/docs/object-fit
       */
      "object-fit": [{
        object: ["contain", "cover", "fill", "none", "scale-down"]
      }],
      /**
       * Object Position
       * @see https://tailwindcss.com/docs/object-position
       */
      "object-position": [{
        object: [...getPositions(), isArbitraryValue]
      }],
      /**
       * Overflow
       * @see https://tailwindcss.com/docs/overflow
       */
      overflow: [{
        overflow: getOverflow()
      }],
      /**
       * Overflow X
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-x": [{
        "overflow-x": getOverflow()
      }],
      /**
       * Overflow Y
       * @see https://tailwindcss.com/docs/overflow
       */
      "overflow-y": [{
        "overflow-y": getOverflow()
      }],
      /**
       * Overscroll Behavior
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      overscroll: [{
        overscroll: getOverscroll()
      }],
      /**
       * Overscroll Behavior X
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-x": [{
        "overscroll-x": getOverscroll()
      }],
      /**
       * Overscroll Behavior Y
       * @see https://tailwindcss.com/docs/overscroll-behavior
       */
      "overscroll-y": [{
        "overscroll-y": getOverscroll()
      }],
      /**
       * Position
       * @see https://tailwindcss.com/docs/position
       */
      position: ["static", "fixed", "absolute", "relative", "sticky"],
      /**
       * Top / Right / Bottom / Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      inset: [{
        inset: [inset]
      }],
      /**
       * Right / Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-x": [{
        "inset-x": [inset]
      }],
      /**
       * Top / Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      "inset-y": [{
        "inset-y": [inset]
      }],
      /**
       * Start
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      start: [{
        start: [inset]
      }],
      /**
       * End
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      end: [{
        end: [inset]
      }],
      /**
       * Top
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      top: [{
        top: [inset]
      }],
      /**
       * Right
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      right: [{
        right: [inset]
      }],
      /**
       * Bottom
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      bottom: [{
        bottom: [inset]
      }],
      /**
       * Left
       * @see https://tailwindcss.com/docs/top-right-bottom-left
       */
      left: [{
        left: [inset]
      }],
      /**
       * Visibility
       * @see https://tailwindcss.com/docs/visibility
       */
      visibility: ["visible", "invisible", "collapse"],
      /**
       * Z-Index
       * @see https://tailwindcss.com/docs/z-index
       */
      z: [{
        z: ["auto", isInteger, isArbitraryValue]
      }],
      // Flexbox and Grid
      /**
       * Flex Basis
       * @see https://tailwindcss.com/docs/flex-basis
       */
      basis: [{
        basis: getSpacingWithAutoAndArbitrary()
      }],
      /**
       * Flex Direction
       * @see https://tailwindcss.com/docs/flex-direction
       */
      "flex-direction": [{
        flex: ["row", "row-reverse", "col", "col-reverse"]
      }],
      /**
       * Flex Wrap
       * @see https://tailwindcss.com/docs/flex-wrap
       */
      "flex-wrap": [{
        flex: ["wrap", "wrap-reverse", "nowrap"]
      }],
      /**
       * Flex
       * @see https://tailwindcss.com/docs/flex
       */
      flex: [{
        flex: ["1", "auto", "initial", "none", isArbitraryValue]
      }],
      /**
       * Flex Grow
       * @see https://tailwindcss.com/docs/flex-grow
       */
      grow: [{
        grow: getZeroAndEmpty()
      }],
      /**
       * Flex Shrink
       * @see https://tailwindcss.com/docs/flex-shrink
       */
      shrink: [{
        shrink: getZeroAndEmpty()
      }],
      /**
       * Order
       * @see https://tailwindcss.com/docs/order
       */
      order: [{
        order: ["first", "last", "none", isInteger, isArbitraryValue]
      }],
      /**
       * Grid Template Columns
       * @see https://tailwindcss.com/docs/grid-template-columns
       */
      "grid-cols": [{
        "grid-cols": [isAny]
      }],
      /**
       * Grid Column Start / End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start-end": [{
        col: ["auto", {
          span: ["full", isInteger, isArbitraryValue]
        }, isArbitraryValue]
      }],
      /**
       * Grid Column Start
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-start": [{
        "col-start": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Column End
       * @see https://tailwindcss.com/docs/grid-column
       */
      "col-end": [{
        "col-end": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Template Rows
       * @see https://tailwindcss.com/docs/grid-template-rows
       */
      "grid-rows": [{
        "grid-rows": [isAny]
      }],
      /**
       * Grid Row Start / End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start-end": [{
        row: ["auto", {
          span: [isInteger, isArbitraryValue]
        }, isArbitraryValue]
      }],
      /**
       * Grid Row Start
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-start": [{
        "row-start": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Row End
       * @see https://tailwindcss.com/docs/grid-row
       */
      "row-end": [{
        "row-end": getNumberWithAutoAndArbitrary()
      }],
      /**
       * Grid Auto Flow
       * @see https://tailwindcss.com/docs/grid-auto-flow
       */
      "grid-flow": [{
        "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
      }],
      /**
       * Grid Auto Columns
       * @see https://tailwindcss.com/docs/grid-auto-columns
       */
      "auto-cols": [{
        "auto-cols": ["auto", "min", "max", "fr", isArbitraryValue]
      }],
      /**
       * Grid Auto Rows
       * @see https://tailwindcss.com/docs/grid-auto-rows
       */
      "auto-rows": [{
        "auto-rows": ["auto", "min", "max", "fr", isArbitraryValue]
      }],
      /**
       * Gap
       * @see https://tailwindcss.com/docs/gap
       */
      gap: [{
        gap: [gap]
      }],
      /**
       * Gap X
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-x": [{
        "gap-x": [gap]
      }],
      /**
       * Gap Y
       * @see https://tailwindcss.com/docs/gap
       */
      "gap-y": [{
        "gap-y": [gap]
      }],
      /**
       * Justify Content
       * @see https://tailwindcss.com/docs/justify-content
       */
      "justify-content": [{
        justify: ["normal", ...getAlign()]
      }],
      /**
       * Justify Items
       * @see https://tailwindcss.com/docs/justify-items
       */
      "justify-items": [{
        "justify-items": ["start", "end", "center", "stretch"]
      }],
      /**
       * Justify Self
       * @see https://tailwindcss.com/docs/justify-self
       */
      "justify-self": [{
        "justify-self": ["auto", "start", "end", "center", "stretch"]
      }],
      /**
       * Align Content
       * @see https://tailwindcss.com/docs/align-content
       */
      "align-content": [{
        content: ["normal", ...getAlign(), "baseline"]
      }],
      /**
       * Align Items
       * @see https://tailwindcss.com/docs/align-items
       */
      "align-items": [{
        items: ["start", "end", "center", "baseline", "stretch"]
      }],
      /**
       * Align Self
       * @see https://tailwindcss.com/docs/align-self
       */
      "align-self": [{
        self: ["auto", "start", "end", "center", "stretch", "baseline"]
      }],
      /**
       * Place Content
       * @see https://tailwindcss.com/docs/place-content
       */
      "place-content": [{
        "place-content": [...getAlign(), "baseline"]
      }],
      /**
       * Place Items
       * @see https://tailwindcss.com/docs/place-items
       */
      "place-items": [{
        "place-items": ["start", "end", "center", "baseline", "stretch"]
      }],
      /**
       * Place Self
       * @see https://tailwindcss.com/docs/place-self
       */
      "place-self": [{
        "place-self": ["auto", "start", "end", "center", "stretch"]
      }],
      // Spacing
      /**
       * Padding
       * @see https://tailwindcss.com/docs/padding
       */
      p: [{
        p: [padding]
      }],
      /**
       * Padding X
       * @see https://tailwindcss.com/docs/padding
       */
      px: [{
        px: [padding]
      }],
      /**
       * Padding Y
       * @see https://tailwindcss.com/docs/padding
       */
      py: [{
        py: [padding]
      }],
      /**
       * Padding Start
       * @see https://tailwindcss.com/docs/padding
       */
      ps: [{
        ps: [padding]
      }],
      /**
       * Padding End
       * @see https://tailwindcss.com/docs/padding
       */
      pe: [{
        pe: [padding]
      }],
      /**
       * Padding Top
       * @see https://tailwindcss.com/docs/padding
       */
      pt: [{
        pt: [padding]
      }],
      /**
       * Padding Right
       * @see https://tailwindcss.com/docs/padding
       */
      pr: [{
        pr: [padding]
      }],
      /**
       * Padding Bottom
       * @see https://tailwindcss.com/docs/padding
       */
      pb: [{
        pb: [padding]
      }],
      /**
       * Padding Left
       * @see https://tailwindcss.com/docs/padding
       */
      pl: [{
        pl: [padding]
      }],
      /**
       * Margin
       * @see https://tailwindcss.com/docs/margin
       */
      m: [{
        m: [margin]
      }],
      /**
       * Margin X
       * @see https://tailwindcss.com/docs/margin
       */
      mx: [{
        mx: [margin]
      }],
      /**
       * Margin Y
       * @see https://tailwindcss.com/docs/margin
       */
      my: [{
        my: [margin]
      }],
      /**
       * Margin Start
       * @see https://tailwindcss.com/docs/margin
       */
      ms: [{
        ms: [margin]
      }],
      /**
       * Margin End
       * @see https://tailwindcss.com/docs/margin
       */
      me: [{
        me: [margin]
      }],
      /**
       * Margin Top
       * @see https://tailwindcss.com/docs/margin
       */
      mt: [{
        mt: [margin]
      }],
      /**
       * Margin Right
       * @see https://tailwindcss.com/docs/margin
       */
      mr: [{
        mr: [margin]
      }],
      /**
       * Margin Bottom
       * @see https://tailwindcss.com/docs/margin
       */
      mb: [{
        mb: [margin]
      }],
      /**
       * Margin Left
       * @see https://tailwindcss.com/docs/margin
       */
      ml: [{
        ml: [margin]
      }],
      /**
       * Space Between X
       * @see https://tailwindcss.com/docs/space
       */
      "space-x": [{
        "space-x": [space]
      }],
      /**
       * Space Between X Reverse
       * @see https://tailwindcss.com/docs/space
       */
      "space-x-reverse": ["space-x-reverse"],
      /**
       * Space Between Y
       * @see https://tailwindcss.com/docs/space
       */
      "space-y": [{
        "space-y": [space]
      }],
      /**
       * Space Between Y Reverse
       * @see https://tailwindcss.com/docs/space
       */
      "space-y-reverse": ["space-y-reverse"],
      // Sizing
      /**
       * Width
       * @see https://tailwindcss.com/docs/width
       */
      w: [{
        w: ["auto", "min", "max", "fit", "svw", "lvw", "dvw", isArbitraryValue, spacing]
      }],
      /**
       * Min-Width
       * @see https://tailwindcss.com/docs/min-width
       */
      "min-w": [{
        "min-w": [isArbitraryValue, spacing, "min", "max", "fit"]
      }],
      /**
       * Max-Width
       * @see https://tailwindcss.com/docs/max-width
       */
      "max-w": [{
        "max-w": [isArbitraryValue, spacing, "none", "full", "min", "max", "fit", "prose", {
          screen: [isTshirtSize]
        }, isTshirtSize]
      }],
      /**
       * Height
       * @see https://tailwindcss.com/docs/height
       */
      h: [{
        h: [isArbitraryValue, spacing, "auto", "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Min-Height
       * @see https://tailwindcss.com/docs/min-height
       */
      "min-h": [{
        "min-h": [isArbitraryValue, spacing, "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Max-Height
       * @see https://tailwindcss.com/docs/max-height
       */
      "max-h": [{
        "max-h": [isArbitraryValue, spacing, "min", "max", "fit", "svh", "lvh", "dvh"]
      }],
      /**
       * Size
       * @see https://tailwindcss.com/docs/size
       */
      size: [{
        size: [isArbitraryValue, spacing, "auto", "min", "max", "fit"]
      }],
      // Typography
      /**
       * Font Size
       * @see https://tailwindcss.com/docs/font-size
       */
      "font-size": [{
        text: ["base", isTshirtSize, isArbitraryLength]
      }],
      /**
       * Font Smoothing
       * @see https://tailwindcss.com/docs/font-smoothing
       */
      "font-smoothing": ["antialiased", "subpixel-antialiased"],
      /**
       * Font Style
       * @see https://tailwindcss.com/docs/font-style
       */
      "font-style": ["italic", "not-italic"],
      /**
       * Font Weight
       * @see https://tailwindcss.com/docs/font-weight
       */
      "font-weight": [{
        font: ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black", isArbitraryNumber]
      }],
      /**
       * Font Family
       * @see https://tailwindcss.com/docs/font-family
       */
      "font-family": [{
        font: [isAny]
      }],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-normal": ["normal-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-ordinal": ["ordinal"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-slashed-zero": ["slashed-zero"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-figure": ["lining-nums", "oldstyle-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-spacing": ["proportional-nums", "tabular-nums"],
      /**
       * Font Variant Numeric
       * @see https://tailwindcss.com/docs/font-variant-numeric
       */
      "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
      /**
       * Letter Spacing
       * @see https://tailwindcss.com/docs/letter-spacing
       */
      tracking: [{
        tracking: ["tighter", "tight", "normal", "wide", "wider", "widest", isArbitraryValue]
      }],
      /**
       * Line Clamp
       * @see https://tailwindcss.com/docs/line-clamp
       */
      "line-clamp": [{
        "line-clamp": ["none", isNumber, isArbitraryNumber]
      }],
      /**
       * Line Height
       * @see https://tailwindcss.com/docs/line-height
       */
      leading: [{
        leading: ["none", "tight", "snug", "normal", "relaxed", "loose", isLength, isArbitraryValue]
      }],
      /**
       * List Style Image
       * @see https://tailwindcss.com/docs/list-style-image
       */
      "list-image": [{
        "list-image": ["none", isArbitraryValue]
      }],
      /**
       * List Style Type
       * @see https://tailwindcss.com/docs/list-style-type
       */
      "list-style-type": [{
        list: ["none", "disc", "decimal", isArbitraryValue]
      }],
      /**
       * List Style Position
       * @see https://tailwindcss.com/docs/list-style-position
       */
      "list-style-position": [{
        list: ["inside", "outside"]
      }],
      /**
       * Placeholder Color
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/placeholder-color
       */
      "placeholder-color": [{
        placeholder: [colors]
      }],
      /**
       * Placeholder Opacity
       * @see https://tailwindcss.com/docs/placeholder-opacity
       */
      "placeholder-opacity": [{
        "placeholder-opacity": [opacity]
      }],
      /**
       * Text Alignment
       * @see https://tailwindcss.com/docs/text-align
       */
      "text-alignment": [{
        text: ["left", "center", "right", "justify", "start", "end"]
      }],
      /**
       * Text Color
       * @see https://tailwindcss.com/docs/text-color
       */
      "text-color": [{
        text: [colors]
      }],
      /**
       * Text Opacity
       * @see https://tailwindcss.com/docs/text-opacity
       */
      "text-opacity": [{
        "text-opacity": [opacity]
      }],
      /**
       * Text Decoration
       * @see https://tailwindcss.com/docs/text-decoration
       */
      "text-decoration": ["underline", "overline", "line-through", "no-underline"],
      /**
       * Text Decoration Style
       * @see https://tailwindcss.com/docs/text-decoration-style
       */
      "text-decoration-style": [{
        decoration: [...getLineStyles(), "wavy"]
      }],
      /**
       * Text Decoration Thickness
       * @see https://tailwindcss.com/docs/text-decoration-thickness
       */
      "text-decoration-thickness": [{
        decoration: ["auto", "from-font", isLength, isArbitraryLength]
      }],
      /**
       * Text Underline Offset
       * @see https://tailwindcss.com/docs/text-underline-offset
       */
      "underline-offset": [{
        "underline-offset": ["auto", isLength, isArbitraryValue]
      }],
      /**
       * Text Decoration Color
       * @see https://tailwindcss.com/docs/text-decoration-color
       */
      "text-decoration-color": [{
        decoration: [colors]
      }],
      /**
       * Text Transform
       * @see https://tailwindcss.com/docs/text-transform
       */
      "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
      /**
       * Text Overflow
       * @see https://tailwindcss.com/docs/text-overflow
       */
      "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
      /**
       * Text Wrap
       * @see https://tailwindcss.com/docs/text-wrap
       */
      "text-wrap": [{
        text: ["wrap", "nowrap", "balance", "pretty"]
      }],
      /**
       * Text Indent
       * @see https://tailwindcss.com/docs/text-indent
       */
      indent: [{
        indent: getSpacingWithArbitrary()
      }],
      /**
       * Vertical Alignment
       * @see https://tailwindcss.com/docs/vertical-align
       */
      "vertical-align": [{
        align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", isArbitraryValue]
      }],
      /**
       * Whitespace
       * @see https://tailwindcss.com/docs/whitespace
       */
      whitespace: [{
        whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
      }],
      /**
       * Word Break
       * @see https://tailwindcss.com/docs/word-break
       */
      break: [{
        break: ["normal", "words", "all", "keep"]
      }],
      /**
       * Hyphens
       * @see https://tailwindcss.com/docs/hyphens
       */
      hyphens: [{
        hyphens: ["none", "manual", "auto"]
      }],
      /**
       * Content
       * @see https://tailwindcss.com/docs/content
       */
      content: [{
        content: ["none", isArbitraryValue]
      }],
      // Backgrounds
      /**
       * Background Attachment
       * @see https://tailwindcss.com/docs/background-attachment
       */
      "bg-attachment": [{
        bg: ["fixed", "local", "scroll"]
      }],
      /**
       * Background Clip
       * @see https://tailwindcss.com/docs/background-clip
       */
      "bg-clip": [{
        "bg-clip": ["border", "padding", "content", "text"]
      }],
      /**
       * Background Opacity
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/background-opacity
       */
      "bg-opacity": [{
        "bg-opacity": [opacity]
      }],
      /**
       * Background Origin
       * @see https://tailwindcss.com/docs/background-origin
       */
      "bg-origin": [{
        "bg-origin": ["border", "padding", "content"]
      }],
      /**
       * Background Position
       * @see https://tailwindcss.com/docs/background-position
       */
      "bg-position": [{
        bg: [...getPositions(), isArbitraryPosition]
      }],
      /**
       * Background Repeat
       * @see https://tailwindcss.com/docs/background-repeat
       */
      "bg-repeat": [{
        bg: ["no-repeat", {
          repeat: ["", "x", "y", "round", "space"]
        }]
      }],
      /**
       * Background Size
       * @see https://tailwindcss.com/docs/background-size
       */
      "bg-size": [{
        bg: ["auto", "cover", "contain", isArbitrarySize]
      }],
      /**
       * Background Image
       * @see https://tailwindcss.com/docs/background-image
       */
      "bg-image": [{
        bg: ["none", {
          "gradient-to": ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
        }, isArbitraryImage]
      }],
      /**
       * Background Color
       * @see https://tailwindcss.com/docs/background-color
       */
      "bg-color": [{
        bg: [colors]
      }],
      /**
       * Gradient Color Stops From Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from-pos": [{
        from: [gradientColorStopPositions]
      }],
      /**
       * Gradient Color Stops Via Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via-pos": [{
        via: [gradientColorStopPositions]
      }],
      /**
       * Gradient Color Stops To Position
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to-pos": [{
        to: [gradientColorStopPositions]
      }],
      /**
       * Gradient Color Stops From
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-from": [{
        from: [gradientColorStops]
      }],
      /**
       * Gradient Color Stops Via
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-via": [{
        via: [gradientColorStops]
      }],
      /**
       * Gradient Color Stops To
       * @see https://tailwindcss.com/docs/gradient-color-stops
       */
      "gradient-to": [{
        to: [gradientColorStops]
      }],
      // Borders
      /**
       * Border Radius
       * @see https://tailwindcss.com/docs/border-radius
       */
      rounded: [{
        rounded: [borderRadius]
      }],
      /**
       * Border Radius Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-s": [{
        "rounded-s": [borderRadius]
      }],
      /**
       * Border Radius End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-e": [{
        "rounded-e": [borderRadius]
      }],
      /**
       * Border Radius Top
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-t": [{
        "rounded-t": [borderRadius]
      }],
      /**
       * Border Radius Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-r": [{
        "rounded-r": [borderRadius]
      }],
      /**
       * Border Radius Bottom
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-b": [{
        "rounded-b": [borderRadius]
      }],
      /**
       * Border Radius Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-l": [{
        "rounded-l": [borderRadius]
      }],
      /**
       * Border Radius Start Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ss": [{
        "rounded-ss": [borderRadius]
      }],
      /**
       * Border Radius Start End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-se": [{
        "rounded-se": [borderRadius]
      }],
      /**
       * Border Radius End End
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-ee": [{
        "rounded-ee": [borderRadius]
      }],
      /**
       * Border Radius End Start
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-es": [{
        "rounded-es": [borderRadius]
      }],
      /**
       * Border Radius Top Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tl": [{
        "rounded-tl": [borderRadius]
      }],
      /**
       * Border Radius Top Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-tr": [{
        "rounded-tr": [borderRadius]
      }],
      /**
       * Border Radius Bottom Right
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-br": [{
        "rounded-br": [borderRadius]
      }],
      /**
       * Border Radius Bottom Left
       * @see https://tailwindcss.com/docs/border-radius
       */
      "rounded-bl": [{
        "rounded-bl": [borderRadius]
      }],
      /**
       * Border Width
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w": [{
        border: [borderWidth]
      }],
      /**
       * Border Width X
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-x": [{
        "border-x": [borderWidth]
      }],
      /**
       * Border Width Y
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-y": [{
        "border-y": [borderWidth]
      }],
      /**
       * Border Width Start
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-s": [{
        "border-s": [borderWidth]
      }],
      /**
       * Border Width End
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-e": [{
        "border-e": [borderWidth]
      }],
      /**
       * Border Width Top
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-t": [{
        "border-t": [borderWidth]
      }],
      /**
       * Border Width Right
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-r": [{
        "border-r": [borderWidth]
      }],
      /**
       * Border Width Bottom
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-b": [{
        "border-b": [borderWidth]
      }],
      /**
       * Border Width Left
       * @see https://tailwindcss.com/docs/border-width
       */
      "border-w-l": [{
        "border-l": [borderWidth]
      }],
      /**
       * Border Opacity
       * @see https://tailwindcss.com/docs/border-opacity
       */
      "border-opacity": [{
        "border-opacity": [opacity]
      }],
      /**
       * Border Style
       * @see https://tailwindcss.com/docs/border-style
       */
      "border-style": [{
        border: [...getLineStyles(), "hidden"]
      }],
      /**
       * Divide Width X
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-x": [{
        "divide-x": [borderWidth]
      }],
      /**
       * Divide Width X Reverse
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-x-reverse": ["divide-x-reverse"],
      /**
       * Divide Width Y
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-y": [{
        "divide-y": [borderWidth]
      }],
      /**
       * Divide Width Y Reverse
       * @see https://tailwindcss.com/docs/divide-width
       */
      "divide-y-reverse": ["divide-y-reverse"],
      /**
       * Divide Opacity
       * @see https://tailwindcss.com/docs/divide-opacity
       */
      "divide-opacity": [{
        "divide-opacity": [opacity]
      }],
      /**
       * Divide Style
       * @see https://tailwindcss.com/docs/divide-style
       */
      "divide-style": [{
        divide: getLineStyles()
      }],
      /**
       * Border Color
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color": [{
        border: [borderColor]
      }],
      /**
       * Border Color X
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-x": [{
        "border-x": [borderColor]
      }],
      /**
       * Border Color Y
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-y": [{
        "border-y": [borderColor]
      }],
      /**
       * Border Color S
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-s": [{
        "border-s": [borderColor]
      }],
      /**
       * Border Color E
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-e": [{
        "border-e": [borderColor]
      }],
      /**
       * Border Color Top
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-t": [{
        "border-t": [borderColor]
      }],
      /**
       * Border Color Right
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-r": [{
        "border-r": [borderColor]
      }],
      /**
       * Border Color Bottom
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-b": [{
        "border-b": [borderColor]
      }],
      /**
       * Border Color Left
       * @see https://tailwindcss.com/docs/border-color
       */
      "border-color-l": [{
        "border-l": [borderColor]
      }],
      /**
       * Divide Color
       * @see https://tailwindcss.com/docs/divide-color
       */
      "divide-color": [{
        divide: [borderColor]
      }],
      /**
       * Outline Style
       * @see https://tailwindcss.com/docs/outline-style
       */
      "outline-style": [{
        outline: ["", ...getLineStyles()]
      }],
      /**
       * Outline Offset
       * @see https://tailwindcss.com/docs/outline-offset
       */
      "outline-offset": [{
        "outline-offset": [isLength, isArbitraryValue]
      }],
      /**
       * Outline Width
       * @see https://tailwindcss.com/docs/outline-width
       */
      "outline-w": [{
        outline: [isLength, isArbitraryLength]
      }],
      /**
       * Outline Color
       * @see https://tailwindcss.com/docs/outline-color
       */
      "outline-color": [{
        outline: [colors]
      }],
      /**
       * Ring Width
       * @see https://tailwindcss.com/docs/ring-width
       */
      "ring-w": [{
        ring: getLengthWithEmptyAndArbitrary()
      }],
      /**
       * Ring Width Inset
       * @see https://tailwindcss.com/docs/ring-width
       */
      "ring-w-inset": ["ring-inset"],
      /**
       * Ring Color
       * @see https://tailwindcss.com/docs/ring-color
       */
      "ring-color": [{
        ring: [colors]
      }],
      /**
       * Ring Opacity
       * @see https://tailwindcss.com/docs/ring-opacity
       */
      "ring-opacity": [{
        "ring-opacity": [opacity]
      }],
      /**
       * Ring Offset Width
       * @see https://tailwindcss.com/docs/ring-offset-width
       */
      "ring-offset-w": [{
        "ring-offset": [isLength, isArbitraryLength]
      }],
      /**
       * Ring Offset Color
       * @see https://tailwindcss.com/docs/ring-offset-color
       */
      "ring-offset-color": [{
        "ring-offset": [colors]
      }],
      // Effects
      /**
       * Box Shadow
       * @see https://tailwindcss.com/docs/box-shadow
       */
      shadow: [{
        shadow: ["", "inner", "none", isTshirtSize, isArbitraryShadow]
      }],
      /**
       * Box Shadow Color
       * @see https://tailwindcss.com/docs/box-shadow-color
       */
      "shadow-color": [{
        shadow: [isAny]
      }],
      /**
       * Opacity
       * @see https://tailwindcss.com/docs/opacity
       */
      opacity: [{
        opacity: [opacity]
      }],
      /**
       * Mix Blend Mode
       * @see https://tailwindcss.com/docs/mix-blend-mode
       */
      "mix-blend": [{
        "mix-blend": [...getBlendModes(), "plus-lighter", "plus-darker"]
      }],
      /**
       * Background Blend Mode
       * @see https://tailwindcss.com/docs/background-blend-mode
       */
      "bg-blend": [{
        "bg-blend": getBlendModes()
      }],
      // Filters
      /**
       * Filter
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/filter
       */
      filter: [{
        filter: ["", "none"]
      }],
      /**
       * Blur
       * @see https://tailwindcss.com/docs/blur
       */
      blur: [{
        blur: [blur]
      }],
      /**
       * Brightness
       * @see https://tailwindcss.com/docs/brightness
       */
      brightness: [{
        brightness: [brightness]
      }],
      /**
       * Contrast
       * @see https://tailwindcss.com/docs/contrast
       */
      contrast: [{
        contrast: [contrast]
      }],
      /**
       * Drop Shadow
       * @see https://tailwindcss.com/docs/drop-shadow
       */
      "drop-shadow": [{
        "drop-shadow": ["", "none", isTshirtSize, isArbitraryValue]
      }],
      /**
       * Grayscale
       * @see https://tailwindcss.com/docs/grayscale
       */
      grayscale: [{
        grayscale: [grayscale]
      }],
      /**
       * Hue Rotate
       * @see https://tailwindcss.com/docs/hue-rotate
       */
      "hue-rotate": [{
        "hue-rotate": [hueRotate]
      }],
      /**
       * Invert
       * @see https://tailwindcss.com/docs/invert
       */
      invert: [{
        invert: [invert]
      }],
      /**
       * Saturate
       * @see https://tailwindcss.com/docs/saturate
       */
      saturate: [{
        saturate: [saturate]
      }],
      /**
       * Sepia
       * @see https://tailwindcss.com/docs/sepia
       */
      sepia: [{
        sepia: [sepia]
      }],
      /**
       * Backdrop Filter
       * @deprecated since Tailwind CSS v3.0.0
       * @see https://tailwindcss.com/docs/backdrop-filter
       */
      "backdrop-filter": [{
        "backdrop-filter": ["", "none"]
      }],
      /**
       * Backdrop Blur
       * @see https://tailwindcss.com/docs/backdrop-blur
       */
      "backdrop-blur": [{
        "backdrop-blur": [blur]
      }],
      /**
       * Backdrop Brightness
       * @see https://tailwindcss.com/docs/backdrop-brightness
       */
      "backdrop-brightness": [{
        "backdrop-brightness": [brightness]
      }],
      /**
       * Backdrop Contrast
       * @see https://tailwindcss.com/docs/backdrop-contrast
       */
      "backdrop-contrast": [{
        "backdrop-contrast": [contrast]
      }],
      /**
       * Backdrop Grayscale
       * @see https://tailwindcss.com/docs/backdrop-grayscale
       */
      "backdrop-grayscale": [{
        "backdrop-grayscale": [grayscale]
      }],
      /**
       * Backdrop Hue Rotate
       * @see https://tailwindcss.com/docs/backdrop-hue-rotate
       */
      "backdrop-hue-rotate": [{
        "backdrop-hue-rotate": [hueRotate]
      }],
      /**
       * Backdrop Invert
       * @see https://tailwindcss.com/docs/backdrop-invert
       */
      "backdrop-invert": [{
        "backdrop-invert": [invert]
      }],
      /**
       * Backdrop Opacity
       * @see https://tailwindcss.com/docs/backdrop-opacity
       */
      "backdrop-opacity": [{
        "backdrop-opacity": [opacity]
      }],
      /**
       * Backdrop Saturate
       * @see https://tailwindcss.com/docs/backdrop-saturate
       */
      "backdrop-saturate": [{
        "backdrop-saturate": [saturate]
      }],
      /**
       * Backdrop Sepia
       * @see https://tailwindcss.com/docs/backdrop-sepia
       */
      "backdrop-sepia": [{
        "backdrop-sepia": [sepia]
      }],
      // Tables
      /**
       * Border Collapse
       * @see https://tailwindcss.com/docs/border-collapse
       */
      "border-collapse": [{
        border: ["collapse", "separate"]
      }],
      /**
       * Border Spacing
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing": [{
        "border-spacing": [borderSpacing]
      }],
      /**
       * Border Spacing X
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-x": [{
        "border-spacing-x": [borderSpacing]
      }],
      /**
       * Border Spacing Y
       * @see https://tailwindcss.com/docs/border-spacing
       */
      "border-spacing-y": [{
        "border-spacing-y": [borderSpacing]
      }],
      /**
       * Table Layout
       * @see https://tailwindcss.com/docs/table-layout
       */
      "table-layout": [{
        table: ["auto", "fixed"]
      }],
      /**
       * Caption Side
       * @see https://tailwindcss.com/docs/caption-side
       */
      caption: [{
        caption: ["top", "bottom"]
      }],
      // Transitions and Animation
      /**
       * Tranisition Property
       * @see https://tailwindcss.com/docs/transition-property
       */
      transition: [{
        transition: ["none", "all", "", "colors", "opacity", "shadow", "transform", isArbitraryValue]
      }],
      /**
       * Transition Duration
       * @see https://tailwindcss.com/docs/transition-duration
       */
      duration: [{
        duration: getNumberAndArbitrary()
      }],
      /**
       * Transition Timing Function
       * @see https://tailwindcss.com/docs/transition-timing-function
       */
      ease: [{
        ease: ["linear", "in", "out", "in-out", isArbitraryValue]
      }],
      /**
       * Transition Delay
       * @see https://tailwindcss.com/docs/transition-delay
       */
      delay: [{
        delay: getNumberAndArbitrary()
      }],
      /**
       * Animation
       * @see https://tailwindcss.com/docs/animation
       */
      animate: [{
        animate: ["none", "spin", "ping", "pulse", "bounce", isArbitraryValue]
      }],
      // Transforms
      /**
       * Transform
       * @see https://tailwindcss.com/docs/transform
       */
      transform: [{
        transform: ["", "gpu", "none"]
      }],
      /**
       * Scale
       * @see https://tailwindcss.com/docs/scale
       */
      scale: [{
        scale: [scale]
      }],
      /**
       * Scale X
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-x": [{
        "scale-x": [scale]
      }],
      /**
       * Scale Y
       * @see https://tailwindcss.com/docs/scale
       */
      "scale-y": [{
        "scale-y": [scale]
      }],
      /**
       * Rotate
       * @see https://tailwindcss.com/docs/rotate
       */
      rotate: [{
        rotate: [isInteger, isArbitraryValue]
      }],
      /**
       * Translate X
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-x": [{
        "translate-x": [translate]
      }],
      /**
       * Translate Y
       * @see https://tailwindcss.com/docs/translate
       */
      "translate-y": [{
        "translate-y": [translate]
      }],
      /**
       * Skew X
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-x": [{
        "skew-x": [skew]
      }],
      /**
       * Skew Y
       * @see https://tailwindcss.com/docs/skew
       */
      "skew-y": [{
        "skew-y": [skew]
      }],
      /**
       * Transform Origin
       * @see https://tailwindcss.com/docs/transform-origin
       */
      "transform-origin": [{
        origin: ["center", "top", "top-right", "right", "bottom-right", "bottom", "bottom-left", "left", "top-left", isArbitraryValue]
      }],
      // Interactivity
      /**
       * Accent Color
       * @see https://tailwindcss.com/docs/accent-color
       */
      accent: [{
        accent: ["auto", colors]
      }],
      /**
       * Appearance
       * @see https://tailwindcss.com/docs/appearance
       */
      appearance: [{
        appearance: ["none", "auto"]
      }],
      /**
       * Cursor
       * @see https://tailwindcss.com/docs/cursor
       */
      cursor: [{
        cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", isArbitraryValue]
      }],
      /**
       * Caret Color
       * @see https://tailwindcss.com/docs/just-in-time-mode#caret-color-utilities
       */
      "caret-color": [{
        caret: [colors]
      }],
      /**
       * Pointer Events
       * @see https://tailwindcss.com/docs/pointer-events
       */
      "pointer-events": [{
        "pointer-events": ["none", "auto"]
      }],
      /**
       * Resize
       * @see https://tailwindcss.com/docs/resize
       */
      resize: [{
        resize: ["none", "y", "x", ""]
      }],
      /**
       * Scroll Behavior
       * @see https://tailwindcss.com/docs/scroll-behavior
       */
      "scroll-behavior": [{
        scroll: ["auto", "smooth"]
      }],
      /**
       * Scroll Margin
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-m": [{
        "scroll-m": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin X
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mx": [{
        "scroll-mx": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Y
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-my": [{
        "scroll-my": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Start
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ms": [{
        "scroll-ms": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin End
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-me": [{
        "scroll-me": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Top
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mt": [{
        "scroll-mt": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Right
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mr": [{
        "scroll-mr": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Bottom
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-mb": [{
        "scroll-mb": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Margin Left
       * @see https://tailwindcss.com/docs/scroll-margin
       */
      "scroll-ml": [{
        "scroll-ml": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-p": [{
        "scroll-p": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding X
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-px": [{
        "scroll-px": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Y
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-py": [{
        "scroll-py": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Start
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-ps": [{
        "scroll-ps": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding End
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pe": [{
        "scroll-pe": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Top
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pt": [{
        "scroll-pt": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Right
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pr": [{
        "scroll-pr": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Bottom
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pb": [{
        "scroll-pb": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Padding Left
       * @see https://tailwindcss.com/docs/scroll-padding
       */
      "scroll-pl": [{
        "scroll-pl": getSpacingWithArbitrary()
      }],
      /**
       * Scroll Snap Align
       * @see https://tailwindcss.com/docs/scroll-snap-align
       */
      "snap-align": [{
        snap: ["start", "end", "center", "align-none"]
      }],
      /**
       * Scroll Snap Stop
       * @see https://tailwindcss.com/docs/scroll-snap-stop
       */
      "snap-stop": [{
        snap: ["normal", "always"]
      }],
      /**
       * Scroll Snap Type
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-type": [{
        snap: ["none", "x", "y", "both"]
      }],
      /**
       * Scroll Snap Type Strictness
       * @see https://tailwindcss.com/docs/scroll-snap-type
       */
      "snap-strictness": [{
        snap: ["mandatory", "proximity"]
      }],
      /**
       * Touch Action
       * @see https://tailwindcss.com/docs/touch-action
       */
      touch: [{
        touch: ["auto", "none", "manipulation"]
      }],
      /**
       * Touch Action X
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-x": [{
        "touch-pan": ["x", "left", "right"]
      }],
      /**
       * Touch Action Y
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-y": [{
        "touch-pan": ["y", "up", "down"]
      }],
      /**
       * Touch Action Pinch Zoom
       * @see https://tailwindcss.com/docs/touch-action
       */
      "touch-pz": ["touch-pinch-zoom"],
      /**
       * User Select
       * @see https://tailwindcss.com/docs/user-select
       */
      select: [{
        select: ["none", "text", "all", "auto"]
      }],
      /**
       * Will Change
       * @see https://tailwindcss.com/docs/will-change
       */
      "will-change": [{
        "will-change": ["auto", "scroll", "contents", "transform", isArbitraryValue]
      }],
      // SVG
      /**
       * Fill
       * @see https://tailwindcss.com/docs/fill
       */
      fill: [{
        fill: [colors, "none"]
      }],
      /**
       * Stroke Width
       * @see https://tailwindcss.com/docs/stroke-width
       */
      "stroke-w": [{
        stroke: [isLength, isArbitraryLength, isArbitraryNumber]
      }],
      /**
       * Stroke
       * @see https://tailwindcss.com/docs/stroke
       */
      stroke: [{
        stroke: [colors, "none"]
      }],
      // Accessibility
      /**
       * Screen Readers
       * @see https://tailwindcss.com/docs/screen-readers
       */
      sr: ["sr-only", "not-sr-only"],
      /**
       * Forced Color Adjust
       * @see https://tailwindcss.com/docs/forced-color-adjust
       */
      "forced-color-adjust": [{
        "forced-color-adjust": ["auto", "none"]
      }]
    },
    conflictingClassGroups: {
      overflow: ["overflow-x", "overflow-y"],
      overscroll: ["overscroll-x", "overscroll-y"],
      inset: ["inset-x", "inset-y", "start", "end", "top", "right", "bottom", "left"],
      "inset-x": ["right", "left"],
      "inset-y": ["top", "bottom"],
      flex: ["basis", "grow", "shrink"],
      gap: ["gap-x", "gap-y"],
      p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"],
      px: ["pr", "pl"],
      py: ["pt", "pb"],
      m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"],
      mx: ["mr", "ml"],
      my: ["mt", "mb"],
      size: ["w", "h"],
      "font-size": ["leading"],
      "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
      "fvn-ordinal": ["fvn-normal"],
      "fvn-slashed-zero": ["fvn-normal"],
      "fvn-figure": ["fvn-normal"],
      "fvn-spacing": ["fvn-normal"],
      "fvn-fraction": ["fvn-normal"],
      "line-clamp": ["display", "overflow"],
      rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
      "rounded-s": ["rounded-ss", "rounded-es"],
      "rounded-e": ["rounded-se", "rounded-ee"],
      "rounded-t": ["rounded-tl", "rounded-tr"],
      "rounded-r": ["rounded-tr", "rounded-br"],
      "rounded-b": ["rounded-br", "rounded-bl"],
      "rounded-l": ["rounded-tl", "rounded-bl"],
      "border-spacing": ["border-spacing-x", "border-spacing-y"],
      "border-w": ["border-w-s", "border-w-e", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
      "border-w-x": ["border-w-r", "border-w-l"],
      "border-w-y": ["border-w-t", "border-w-b"],
      "border-color": ["border-color-s", "border-color-e", "border-color-t", "border-color-r", "border-color-b", "border-color-l"],
      "border-color-x": ["border-color-r", "border-color-l"],
      "border-color-y": ["border-color-t", "border-color-b"],
      "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
      "scroll-mx": ["scroll-mr", "scroll-ml"],
      "scroll-my": ["scroll-mt", "scroll-mb"],
      "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
      "scroll-px": ["scroll-pr", "scroll-pl"],
      "scroll-py": ["scroll-pt", "scroll-pb"],
      touch: ["touch-x", "touch-y", "touch-pz"],
      "touch-x": ["touch"],
      "touch-y": ["touch"],
      "touch-pz": ["touch"]
    },
    conflictingClassGroupModifiers: {
      "font-size": ["leading"]
    }
  };
};
const twMerge = /* @__PURE__ */ createTailwindMerge(getDefaultConfig);
function toDate(argument) {
  const argStr = Object.prototype.toString.call(argument);
  if (argument instanceof Date || typeof argument === "object" && argStr === "[object Date]") {
    return new argument.constructor(+argument);
  } else if (typeof argument === "number" || argStr === "[object Number]" || typeof argument === "string" || argStr === "[object String]") {
    return new Date(argument);
  } else {
    return /* @__PURE__ */ new Date(NaN);
  }
}
function constructFrom(date, value) {
  if (date instanceof Date) {
    return new date.constructor(value);
  } else {
    return new Date(value);
  }
}
const millisecondsInWeek = 6048e5;
const millisecondsInDay = 864e5;
let defaultOptions$1 = {};
function getDefaultOptions() {
  return defaultOptions$1;
}
function startOfWeek(date, options) {
  var _a, _b, _c, _d;
  const defaultOptions2 = getDefaultOptions();
  const weekStartsOn = (options == null ? void 0 : options.weekStartsOn) ?? ((_b = (_a = options == null ? void 0 : options.locale) == null ? void 0 : _a.options) == null ? void 0 : _b.weekStartsOn) ?? defaultOptions2.weekStartsOn ?? ((_d = (_c = defaultOptions2.locale) == null ? void 0 : _c.options) == null ? void 0 : _d.weekStartsOn) ?? 0;
  const _date = toDate(date);
  const day = _date.getDay();
  const diff = (day < weekStartsOn ? 7 : 0) + day - weekStartsOn;
  _date.setDate(_date.getDate() - diff);
  _date.setHours(0, 0, 0, 0);
  return _date;
}
function startOfISOWeek(date) {
  return startOfWeek(date, { weekStartsOn: 1 });
}
function getISOWeekYear(date) {
  const _date = toDate(date);
  const year = _date.getFullYear();
  const fourthOfJanuaryOfNextYear = constructFrom(date, 0);
  fourthOfJanuaryOfNextYear.setFullYear(year + 1, 0, 4);
  fourthOfJanuaryOfNextYear.setHours(0, 0, 0, 0);
  const startOfNextYear = startOfISOWeek(fourthOfJanuaryOfNextYear);
  const fourthOfJanuaryOfThisYear = constructFrom(date, 0);
  fourthOfJanuaryOfThisYear.setFullYear(year, 0, 4);
  fourthOfJanuaryOfThisYear.setHours(0, 0, 0, 0);
  const startOfThisYear = startOfISOWeek(fourthOfJanuaryOfThisYear);
  if (_date.getTime() >= startOfNextYear.getTime()) {
    return year + 1;
  } else if (_date.getTime() >= startOfThisYear.getTime()) {
    return year;
  } else {
    return year - 1;
  }
}
function startOfDay(date) {
  const _date = toDate(date);
  _date.setHours(0, 0, 0, 0);
  return _date;
}
function getTimezoneOffsetInMilliseconds(date) {
  const _date = toDate(date);
  const utcDate = new Date(
    Date.UTC(
      _date.getFullYear(),
      _date.getMonth(),
      _date.getDate(),
      _date.getHours(),
      _date.getMinutes(),
      _date.getSeconds(),
      _date.getMilliseconds()
    )
  );
  utcDate.setUTCFullYear(_date.getFullYear());
  return +date - +utcDate;
}
function differenceInCalendarDays(dateLeft, dateRight) {
  const startOfDayLeft = startOfDay(dateLeft);
  const startOfDayRight = startOfDay(dateRight);
  const timestampLeft = +startOfDayLeft - getTimezoneOffsetInMilliseconds(startOfDayLeft);
  const timestampRight = +startOfDayRight - getTimezoneOffsetInMilliseconds(startOfDayRight);
  return Math.round((timestampLeft - timestampRight) / millisecondsInDay);
}
function startOfISOWeekYear(date) {
  const year = getISOWeekYear(date);
  const fourthOfJanuary = constructFrom(date, 0);
  fourthOfJanuary.setFullYear(year, 0, 4);
  fourthOfJanuary.setHours(0, 0, 0, 0);
  return startOfISOWeek(fourthOfJanuary);
}
function isDate(value) {
  return value instanceof Date || typeof value === "object" && Object.prototype.toString.call(value) === "[object Date]";
}
function isValid(date) {
  if (!isDate(date) && typeof date !== "number") {
    return false;
  }
  const _date = toDate(date);
  return !isNaN(Number(_date));
}
function startOfYear(date) {
  const cleanDate = toDate(date);
  const _date = constructFrom(date, 0);
  _date.setFullYear(cleanDate.getFullYear(), 0, 1);
  _date.setHours(0, 0, 0, 0);
  return _date;
}
const formatDistanceLocale = {
  lessThanXSeconds: {
    one: "less than a second",
    other: "less than {{count}} seconds"
  },
  xSeconds: {
    one: "1 second",
    other: "{{count}} seconds"
  },
  halfAMinute: "half a minute",
  lessThanXMinutes: {
    one: "less than a minute",
    other: "less than {{count}} minutes"
  },
  xMinutes: {
    one: "1 minute",
    other: "{{count}} minutes"
  },
  aboutXHours: {
    one: "about 1 hour",
    other: "about {{count}} hours"
  },
  xHours: {
    one: "1 hour",
    other: "{{count}} hours"
  },
  xDays: {
    one: "1 day",
    other: "{{count}} days"
  },
  aboutXWeeks: {
    one: "about 1 week",
    other: "about {{count}} weeks"
  },
  xWeeks: {
    one: "1 week",
    other: "{{count}} weeks"
  },
  aboutXMonths: {
    one: "about 1 month",
    other: "about {{count}} months"
  },
  xMonths: {
    one: "1 month",
    other: "{{count}} months"
  },
  aboutXYears: {
    one: "about 1 year",
    other: "about {{count}} years"
  },
  xYears: {
    one: "1 year",
    other: "{{count}} years"
  },
  overXYears: {
    one: "over 1 year",
    other: "over {{count}} years"
  },
  almostXYears: {
    one: "almost 1 year",
    other: "almost {{count}} years"
  }
};
const formatDistance = (token, count2, options) => {
  let result;
  const tokenValue = formatDistanceLocale[token];
  if (typeof tokenValue === "string") {
    result = tokenValue;
  } else if (count2 === 1) {
    result = tokenValue.one;
  } else {
    result = tokenValue.other.replace("{{count}}", count2.toString());
  }
  if (options == null ? void 0 : options.addSuffix) {
    if (options.comparison && options.comparison > 0) {
      return "in " + result;
    } else {
      return result + " ago";
    }
  }
  return result;
};
function buildFormatLongFn(args) {
  return (options = {}) => {
    const width = options.width ? String(options.width) : args.defaultWidth;
    const format2 = args.formats[width] || args.formats[args.defaultWidth];
    return format2;
  };
}
const dateFormats = {
  full: "EEEE, MMMM do, y",
  long: "MMMM do, y",
  medium: "MMM d, y",
  short: "MM/dd/yyyy"
};
const timeFormats = {
  full: "h:mm:ss a zzzz",
  long: "h:mm:ss a z",
  medium: "h:mm:ss a",
  short: "h:mm a"
};
const dateTimeFormats = {
  full: "{{date}} 'at' {{time}}",
  long: "{{date}} 'at' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
};
const formatLong = {
  date: buildFormatLongFn({
    formats: dateFormats,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats,
    defaultWidth: "full"
  })
};
const formatRelativeLocale = {
  lastWeek: "'last' eeee 'at' p",
  yesterday: "'yesterday at' p",
  today: "'today at' p",
  tomorrow: "'tomorrow at' p",
  nextWeek: "eeee 'at' p",
  other: "P"
};
const formatRelative = (token, _date, _baseDate, _options) => formatRelativeLocale[token];
function buildLocalizeFn(args) {
  return (value, options) => {
    const context = (options == null ? void 0 : options.context) ? String(options.context) : "standalone";
    let valuesArray;
    if (context === "formatting" && args.formattingValues) {
      const defaultWidth = args.defaultFormattingWidth || args.defaultWidth;
      const width = (options == null ? void 0 : options.width) ? String(options.width) : defaultWidth;
      valuesArray = args.formattingValues[width] || args.formattingValues[defaultWidth];
    } else {
      const defaultWidth = args.defaultWidth;
      const width = (options == null ? void 0 : options.width) ? String(options.width) : args.defaultWidth;
      valuesArray = args.values[width] || args.values[defaultWidth];
    }
    const index = args.argumentCallback ? args.argumentCallback(value) : value;
    return valuesArray[index];
  };
}
const eraValues = {
  narrow: ["B", "A"],
  abbreviated: ["BC", "AD"],
  wide: ["Before Christ", "Anno Domini"]
};
const quarterValues = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["Q1", "Q2", "Q3", "Q4"],
  wide: ["1st quarter", "2nd quarter", "3rd quarter", "4th quarter"]
};
const monthValues = {
  narrow: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
  abbreviated: [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
  ],
  wide: [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ]
};
const dayValues = {
  narrow: ["S", "M", "T", "W", "T", "F", "S"],
  short: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
  abbreviated: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
  wide: [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday"
  ]
};
const dayPeriodValues = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "mi",
    noon: "n",
    morning: "morning",
    afternoon: "afternoon",
    evening: "evening",
    night: "night"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "midnight",
    noon: "noon",
    morning: "morning",
    afternoon: "afternoon",
    evening: "evening",
    night: "night"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "midnight",
    noon: "noon",
    morning: "morning",
    afternoon: "afternoon",
    evening: "evening",
    night: "night"
  }
};
const formattingDayPeriodValues = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "mi",
    noon: "n",
    morning: "in the morning",
    afternoon: "in the afternoon",
    evening: "in the evening",
    night: "at night"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "midnight",
    noon: "noon",
    morning: "in the morning",
    afternoon: "in the afternoon",
    evening: "in the evening",
    night: "at night"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "midnight",
    noon: "noon",
    morning: "in the morning",
    afternoon: "in the afternoon",
    evening: "in the evening",
    night: "at night"
  }
};
const ordinalNumber = (dirtyNumber, _options) => {
  const number = Number(dirtyNumber);
  const rem100 = number % 100;
  if (rem100 > 20 || rem100 < 10) {
    switch (rem100 % 10) {
      case 1:
        return number + "st";
      case 2:
        return number + "nd";
      case 3:
        return number + "rd";
    }
  }
  return number + "th";
};
const localize = {
  ordinalNumber,
  era: buildLocalizeFn({
    values: eraValues,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues,
    defaultWidth: "wide",
    argumentCallback: (quarter) => quarter - 1
  }),
  month: buildLocalizeFn({
    values: monthValues,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues,
    defaultFormattingWidth: "wide"
  })
};
function buildMatchFn(args) {
  return (string, options = {}) => {
    const width = options.width;
    const matchPattern = width && args.matchPatterns[width] || args.matchPatterns[args.defaultMatchWidth];
    const matchResult = string.match(matchPattern);
    if (!matchResult) {
      return null;
    }
    const matchedString = matchResult[0];
    const parsePatterns = width && args.parsePatterns[width] || args.parsePatterns[args.defaultParseWidth];
    const key = Array.isArray(parsePatterns) ? findIndex(parsePatterns, (pattern) => pattern.test(matchedString)) : (
      // eslint-disable-next-line @typescript-eslint/no-explicit-any -- I challange you to fix the type
      findKey(parsePatterns, (pattern) => pattern.test(matchedString))
    );
    let value;
    value = args.valueCallback ? args.valueCallback(key) : key;
    value = options.valueCallback ? (
      // eslint-disable-next-line @typescript-eslint/no-explicit-any -- I challange you to fix the type
      options.valueCallback(value)
    ) : value;
    const rest = string.slice(matchedString.length);
    return { value, rest };
  };
}
function findKey(object, predicate) {
  for (const key in object) {
    if (Object.prototype.hasOwnProperty.call(object, key) && predicate(object[key])) {
      return key;
    }
  }
  return void 0;
}
function findIndex(array, predicate) {
  for (let key = 0; key < array.length; key++) {
    if (predicate(array[key])) {
      return key;
    }
  }
  return void 0;
}
function buildMatchPatternFn(args) {
  return (string, options = {}) => {
    const matchResult = string.match(args.matchPattern);
    if (!matchResult) return null;
    const matchedString = matchResult[0];
    const parseResult = string.match(args.parsePattern);
    if (!parseResult) return null;
    let value = args.valueCallback ? args.valueCallback(parseResult[0]) : parseResult[0];
    value = options.valueCallback ? options.valueCallback(value) : value;
    const rest = string.slice(matchedString.length);
    return { value, rest };
  };
}
const matchOrdinalNumberPattern = /^(\d+)(th|st|nd|rd)?/i;
const parseOrdinalNumberPattern = /\d+/i;
const matchEraPatterns = {
  narrow: /^(b|a)/i,
  abbreviated: /^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i,
  wide: /^(before christ|before common era|anno domini|common era)/i
};
const parseEraPatterns = {
  any: [/^b/i, /^(a|c)/i]
};
const matchQuarterPatterns = {
  narrow: /^[1234]/i,
  abbreviated: /^q[1234]/i,
  wide: /^[1234](th|st|nd|rd)? quarter/i
};
const parseQuarterPatterns = {
  any: [/1/i, /2/i, /3/i, /4/i]
};
const matchMonthPatterns = {
  narrow: /^[jfmasond]/i,
  abbreviated: /^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,
  wide: /^(january|february|march|april|may|june|july|august|september|october|november|december)/i
};
const parseMonthPatterns = {
  narrow: [
    /^j/i,
    /^f/i,
    /^m/i,
    /^a/i,
    /^m/i,
    /^j/i,
    /^j/i,
    /^a/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ],
  any: [
    /^ja/i,
    /^f/i,
    /^mar/i,
    /^ap/i,
    /^may/i,
    /^jun/i,
    /^jul/i,
    /^au/i,
    /^s/i,
    /^o/i,
    /^n/i,
    /^d/i
  ]
};
const matchDayPatterns = {
  narrow: /^[smtwf]/i,
  short: /^(su|mo|tu|we|th|fr|sa)/i,
  abbreviated: /^(sun|mon|tue|wed|thu|fri|sat)/i,
  wide: /^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i
};
const parseDayPatterns = {
  narrow: [/^s/i, /^m/i, /^t/i, /^w/i, /^t/i, /^f/i, /^s/i],
  any: [/^su/i, /^m/i, /^tu/i, /^w/i, /^th/i, /^f/i, /^sa/i]
};
const matchDayPeriodPatterns = {
  narrow: /^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,
  any: /^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i
};
const parseDayPeriodPatterns = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^mi/i,
    noon: /^no/i,
    morning: /morning/i,
    afternoon: /afternoon/i,
    evening: /evening/i,
    night: /night/i
  }
};
const match = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern,
    parsePattern: parseOrdinalNumberPattern,
    valueCallback: (value) => parseInt(value, 10)
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns,
    defaultParseWidth: "any",
    valueCallback: (index) => index + 1
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns,
    defaultParseWidth: "any"
  })
};
const enUS = {
  code: "en-US",
  formatDistance,
  formatLong,
  formatRelative,
  localize,
  match,
  options: {
    weekStartsOn: 0,
    firstWeekContainsDate: 1
  }
};
function getDayOfYear(date) {
  const _date = toDate(date);
  const diff = differenceInCalendarDays(_date, startOfYear(_date));
  const dayOfYear = diff + 1;
  return dayOfYear;
}
function getISOWeek(date) {
  const _date = toDate(date);
  const diff = +startOfISOWeek(_date) - +startOfISOWeekYear(_date);
  return Math.round(diff / millisecondsInWeek) + 1;
}
function getWeekYear(date, options) {
  var _a, _b, _c, _d;
  const _date = toDate(date);
  const year = _date.getFullYear();
  const defaultOptions2 = getDefaultOptions();
  const firstWeekContainsDate = (options == null ? void 0 : options.firstWeekContainsDate) ?? ((_b = (_a = options == null ? void 0 : options.locale) == null ? void 0 : _a.options) == null ? void 0 : _b.firstWeekContainsDate) ?? defaultOptions2.firstWeekContainsDate ?? ((_d = (_c = defaultOptions2.locale) == null ? void 0 : _c.options) == null ? void 0 : _d.firstWeekContainsDate) ?? 1;
  const firstWeekOfNextYear = constructFrom(date, 0);
  firstWeekOfNextYear.setFullYear(year + 1, 0, firstWeekContainsDate);
  firstWeekOfNextYear.setHours(0, 0, 0, 0);
  const startOfNextYear = startOfWeek(firstWeekOfNextYear, options);
  const firstWeekOfThisYear = constructFrom(date, 0);
  firstWeekOfThisYear.setFullYear(year, 0, firstWeekContainsDate);
  firstWeekOfThisYear.setHours(0, 0, 0, 0);
  const startOfThisYear = startOfWeek(firstWeekOfThisYear, options);
  if (_date.getTime() >= startOfNextYear.getTime()) {
    return year + 1;
  } else if (_date.getTime() >= startOfThisYear.getTime()) {
    return year;
  } else {
    return year - 1;
  }
}
function startOfWeekYear(date, options) {
  var _a, _b, _c, _d;
  const defaultOptions2 = getDefaultOptions();
  const firstWeekContainsDate = (options == null ? void 0 : options.firstWeekContainsDate) ?? ((_b = (_a = options == null ? void 0 : options.locale) == null ? void 0 : _a.options) == null ? void 0 : _b.firstWeekContainsDate) ?? defaultOptions2.firstWeekContainsDate ?? ((_d = (_c = defaultOptions2.locale) == null ? void 0 : _c.options) == null ? void 0 : _d.firstWeekContainsDate) ?? 1;
  const year = getWeekYear(date, options);
  const firstWeek = constructFrom(date, 0);
  firstWeek.setFullYear(year, 0, firstWeekContainsDate);
  firstWeek.setHours(0, 0, 0, 0);
  const _date = startOfWeek(firstWeek, options);
  return _date;
}
function getWeek(date, options) {
  const _date = toDate(date);
  const diff = +startOfWeek(_date, options) - +startOfWeekYear(_date, options);
  return Math.round(diff / millisecondsInWeek) + 1;
}
function addLeadingZeros(number, targetLength) {
  const sign = number < 0 ? "-" : "";
  const output = Math.abs(number).toString().padStart(targetLength, "0");
  return sign + output;
}
const lightFormatters = {
  // Year
  y(date, token) {
    const signedYear = date.getFullYear();
    const year = signedYear > 0 ? signedYear : 1 - signedYear;
    return addLeadingZeros(token === "yy" ? year % 100 : year, token.length);
  },
  // Month
  M(date, token) {
    const month = date.getMonth();
    return token === "M" ? String(month + 1) : addLeadingZeros(month + 1, 2);
  },
  // Day of the month
  d(date, token) {
    return addLeadingZeros(date.getDate(), token.length);
  },
  // AM or PM
  a(date, token) {
    const dayPeriodEnumValue = date.getHours() / 12 >= 1 ? "pm" : "am";
    switch (token) {
      case "a":
      case "aa":
        return dayPeriodEnumValue.toUpperCase();
      case "aaa":
        return dayPeriodEnumValue;
      case "aaaaa":
        return dayPeriodEnumValue[0];
      case "aaaa":
      default:
        return dayPeriodEnumValue === "am" ? "a.m." : "p.m.";
    }
  },
  // Hour [1-12]
  h(date, token) {
    return addLeadingZeros(date.getHours() % 12 || 12, token.length);
  },
  // Hour [0-23]
  H(date, token) {
    return addLeadingZeros(date.getHours(), token.length);
  },
  // Minute
  m(date, token) {
    return addLeadingZeros(date.getMinutes(), token.length);
  },
  // Second
  s(date, token) {
    return addLeadingZeros(date.getSeconds(), token.length);
  },
  // Fraction of second
  S(date, token) {
    const numberOfDigits = token.length;
    const milliseconds = date.getMilliseconds();
    const fractionalSeconds = Math.trunc(
      milliseconds * Math.pow(10, numberOfDigits - 3)
    );
    return addLeadingZeros(fractionalSeconds, token.length);
  }
};
const dayPeriodEnum = {
  midnight: "midnight",
  noon: "noon",
  morning: "morning",
  afternoon: "afternoon",
  evening: "evening",
  night: "night"
};
const formatters = {
  // Era
  G: function(date, token, localize2) {
    const era = date.getFullYear() > 0 ? 1 : 0;
    switch (token) {
      case "G":
      case "GG":
      case "GGG":
        return localize2.era(era, { width: "abbreviated" });
      case "GGGGG":
        return localize2.era(era, { width: "narrow" });
      case "GGGG":
      default:
        return localize2.era(era, { width: "wide" });
    }
  },
  // Year
  y: function(date, token, localize2) {
    if (token === "yo") {
      const signedYear = date.getFullYear();
      const year = signedYear > 0 ? signedYear : 1 - signedYear;
      return localize2.ordinalNumber(year, { unit: "year" });
    }
    return lightFormatters.y(date, token);
  },
  // Local week-numbering year
  Y: function(date, token, localize2, options) {
    const signedWeekYear = getWeekYear(date, options);
    const weekYear = signedWeekYear > 0 ? signedWeekYear : 1 - signedWeekYear;
    if (token === "YY") {
      const twoDigitYear = weekYear % 100;
      return addLeadingZeros(twoDigitYear, 2);
    }
    if (token === "Yo") {
      return localize2.ordinalNumber(weekYear, { unit: "year" });
    }
    return addLeadingZeros(weekYear, token.length);
  },
  // ISO week-numbering year
  R: function(date, token) {
    const isoWeekYear = getISOWeekYear(date);
    return addLeadingZeros(isoWeekYear, token.length);
  },
  // Extended year. This is a single number designating the year of this calendar system.
  // The main difference between `y` and `u` localizers are B.C. years:
  // | Year | `y` | `u` |
  // |------|-----|-----|
  // | AC 1 |   1 |   1 |
  // | BC 1 |   1 |   0 |
  // | BC 2 |   2 |  -1 |
  // Also `yy` always returns the last two digits of a year,
  // while `uu` pads single digit years to 2 characters and returns other years unchanged.
  u: function(date, token) {
    const year = date.getFullYear();
    return addLeadingZeros(year, token.length);
  },
  // Quarter
  Q: function(date, token, localize2) {
    const quarter = Math.ceil((date.getMonth() + 1) / 3);
    switch (token) {
      case "Q":
        return String(quarter);
      case "QQ":
        return addLeadingZeros(quarter, 2);
      case "Qo":
        return localize2.ordinalNumber(quarter, { unit: "quarter" });
      case "QQQ":
        return localize2.quarter(quarter, {
          width: "abbreviated",
          context: "formatting"
        });
      case "QQQQQ":
        return localize2.quarter(quarter, {
          width: "narrow",
          context: "formatting"
        });
      case "QQQQ":
      default:
        return localize2.quarter(quarter, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  // Stand-alone quarter
  q: function(date, token, localize2) {
    const quarter = Math.ceil((date.getMonth() + 1) / 3);
    switch (token) {
      case "q":
        return String(quarter);
      case "qq":
        return addLeadingZeros(quarter, 2);
      case "qo":
        return localize2.ordinalNumber(quarter, { unit: "quarter" });
      case "qqq":
        return localize2.quarter(quarter, {
          width: "abbreviated",
          context: "standalone"
        });
      case "qqqqq":
        return localize2.quarter(quarter, {
          width: "narrow",
          context: "standalone"
        });
      case "qqqq":
      default:
        return localize2.quarter(quarter, {
          width: "wide",
          context: "standalone"
        });
    }
  },
  // Month
  M: function(date, token, localize2) {
    const month = date.getMonth();
    switch (token) {
      case "M":
      case "MM":
        return lightFormatters.M(date, token);
      case "Mo":
        return localize2.ordinalNumber(month + 1, { unit: "month" });
      case "MMM":
        return localize2.month(month, {
          width: "abbreviated",
          context: "formatting"
        });
      case "MMMMM":
        return localize2.month(month, {
          width: "narrow",
          context: "formatting"
        });
      case "MMMM":
      default:
        return localize2.month(month, { width: "wide", context: "formatting" });
    }
  },
  // Stand-alone month
  L: function(date, token, localize2) {
    const month = date.getMonth();
    switch (token) {
      case "L":
        return String(month + 1);
      case "LL":
        return addLeadingZeros(month + 1, 2);
      case "Lo":
        return localize2.ordinalNumber(month + 1, { unit: "month" });
      case "LLL":
        return localize2.month(month, {
          width: "abbreviated",
          context: "standalone"
        });
      case "LLLLL":
        return localize2.month(month, {
          width: "narrow",
          context: "standalone"
        });
      case "LLLL":
      default:
        return localize2.month(month, { width: "wide", context: "standalone" });
    }
  },
  // Local week of year
  w: function(date, token, localize2, options) {
    const week = getWeek(date, options);
    if (token === "wo") {
      return localize2.ordinalNumber(week, { unit: "week" });
    }
    return addLeadingZeros(week, token.length);
  },
  // ISO week of year
  I: function(date, token, localize2) {
    const isoWeek = getISOWeek(date);
    if (token === "Io") {
      return localize2.ordinalNumber(isoWeek, { unit: "week" });
    }
    return addLeadingZeros(isoWeek, token.length);
  },
  // Day of the month
  d: function(date, token, localize2) {
    if (token === "do") {
      return localize2.ordinalNumber(date.getDate(), { unit: "date" });
    }
    return lightFormatters.d(date, token);
  },
  // Day of year
  D: function(date, token, localize2) {
    const dayOfYear = getDayOfYear(date);
    if (token === "Do") {
      return localize2.ordinalNumber(dayOfYear, { unit: "dayOfYear" });
    }
    return addLeadingZeros(dayOfYear, token.length);
  },
  // Day of week
  E: function(date, token, localize2) {
    const dayOfWeek = date.getDay();
    switch (token) {
      case "E":
      case "EE":
      case "EEE":
        return localize2.day(dayOfWeek, {
          width: "abbreviated",
          context: "formatting"
        });
      case "EEEEE":
        return localize2.day(dayOfWeek, {
          width: "narrow",
          context: "formatting"
        });
      case "EEEEEE":
        return localize2.day(dayOfWeek, {
          width: "short",
          context: "formatting"
        });
      case "EEEE":
      default:
        return localize2.day(dayOfWeek, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  // Local day of week
  e: function(date, token, localize2, options) {
    const dayOfWeek = date.getDay();
    const localDayOfWeek = (dayOfWeek - options.weekStartsOn + 8) % 7 || 7;
    switch (token) {
      case "e":
        return String(localDayOfWeek);
      case "ee":
        return addLeadingZeros(localDayOfWeek, 2);
      case "eo":
        return localize2.ordinalNumber(localDayOfWeek, { unit: "day" });
      case "eee":
        return localize2.day(dayOfWeek, {
          width: "abbreviated",
          context: "formatting"
        });
      case "eeeee":
        return localize2.day(dayOfWeek, {
          width: "narrow",
          context: "formatting"
        });
      case "eeeeee":
        return localize2.day(dayOfWeek, {
          width: "short",
          context: "formatting"
        });
      case "eeee":
      default:
        return localize2.day(dayOfWeek, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  // Stand-alone local day of week
  c: function(date, token, localize2, options) {
    const dayOfWeek = date.getDay();
    const localDayOfWeek = (dayOfWeek - options.weekStartsOn + 8) % 7 || 7;
    switch (token) {
      case "c":
        return String(localDayOfWeek);
      case "cc":
        return addLeadingZeros(localDayOfWeek, token.length);
      case "co":
        return localize2.ordinalNumber(localDayOfWeek, { unit: "day" });
      case "ccc":
        return localize2.day(dayOfWeek, {
          width: "abbreviated",
          context: "standalone"
        });
      case "ccccc":
        return localize2.day(dayOfWeek, {
          width: "narrow",
          context: "standalone"
        });
      case "cccccc":
        return localize2.day(dayOfWeek, {
          width: "short",
          context: "standalone"
        });
      case "cccc":
      default:
        return localize2.day(dayOfWeek, {
          width: "wide",
          context: "standalone"
        });
    }
  },
  // ISO day of week
  i: function(date, token, localize2) {
    const dayOfWeek = date.getDay();
    const isoDayOfWeek = dayOfWeek === 0 ? 7 : dayOfWeek;
    switch (token) {
      case "i":
        return String(isoDayOfWeek);
      case "ii":
        return addLeadingZeros(isoDayOfWeek, token.length);
      case "io":
        return localize2.ordinalNumber(isoDayOfWeek, { unit: "day" });
      case "iii":
        return localize2.day(dayOfWeek, {
          width: "abbreviated",
          context: "formatting"
        });
      case "iiiii":
        return localize2.day(dayOfWeek, {
          width: "narrow",
          context: "formatting"
        });
      case "iiiiii":
        return localize2.day(dayOfWeek, {
          width: "short",
          context: "formatting"
        });
      case "iiii":
      default:
        return localize2.day(dayOfWeek, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  // AM or PM
  a: function(date, token, localize2) {
    const hours = date.getHours();
    const dayPeriodEnumValue = hours / 12 >= 1 ? "pm" : "am";
    switch (token) {
      case "a":
      case "aa":
        return localize2.dayPeriod(dayPeriodEnumValue, {
          width: "abbreviated",
          context: "formatting"
        });
      case "aaa":
        return localize2.dayPeriod(dayPeriodEnumValue, {
          width: "abbreviated",
          context: "formatting"
        }).toLowerCase();
      case "aaaaa":
        return localize2.dayPeriod(dayPeriodEnumValue, {
          width: "narrow",
          context: "formatting"
        });
      case "aaaa":
      default:
        return localize2.dayPeriod(dayPeriodEnumValue, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  // AM, PM, midnight, noon
  b: function(date, token, localize2) {
    const hours = date.getHours();
    let dayPeriodEnumValue;
    if (hours === 12) {
      dayPeriodEnumValue = dayPeriodEnum.noon;
    } else if (hours === 0) {
      dayPeriodEnumValue = dayPeriodEnum.midnight;
    } else {
      dayPeriodEnumValue = hours / 12 >= 1 ? "pm" : "am";
    }
    switch (token) {
      case "b":
      case "bb":
        return localize2.dayPeriod(dayPeriodEnumValue, {
          width: "abbreviated",
          context: "formatting"
        });
      case "bbb":
        return localize2.dayPeriod(dayPeriodEnumValue, {
          width: "abbreviated",
          context: "formatting"
        }).toLowerCase();
      case "bbbbb":
        return localize2.dayPeriod(dayPeriodEnumValue, {
          width: "narrow",
          context: "formatting"
        });
      case "bbbb":
      default:
        return localize2.dayPeriod(dayPeriodEnumValue, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  // in the morning, in the afternoon, in the evening, at night
  B: function(date, token, localize2) {
    const hours = date.getHours();
    let dayPeriodEnumValue;
    if (hours >= 17) {
      dayPeriodEnumValue = dayPeriodEnum.evening;
    } else if (hours >= 12) {
      dayPeriodEnumValue = dayPeriodEnum.afternoon;
    } else if (hours >= 4) {
      dayPeriodEnumValue = dayPeriodEnum.morning;
    } else {
      dayPeriodEnumValue = dayPeriodEnum.night;
    }
    switch (token) {
      case "B":
      case "BB":
      case "BBB":
        return localize2.dayPeriod(dayPeriodEnumValue, {
          width: "abbreviated",
          context: "formatting"
        });
      case "BBBBB":
        return localize2.dayPeriod(dayPeriodEnumValue, {
          width: "narrow",
          context: "formatting"
        });
      case "BBBB":
      default:
        return localize2.dayPeriod(dayPeriodEnumValue, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  // Hour [1-12]
  h: function(date, token, localize2) {
    if (token === "ho") {
      let hours = date.getHours() % 12;
      if (hours === 0) hours = 12;
      return localize2.ordinalNumber(hours, { unit: "hour" });
    }
    return lightFormatters.h(date, token);
  },
  // Hour [0-23]
  H: function(date, token, localize2) {
    if (token === "Ho") {
      return localize2.ordinalNumber(date.getHours(), { unit: "hour" });
    }
    return lightFormatters.H(date, token);
  },
  // Hour [0-11]
  K: function(date, token, localize2) {
    const hours = date.getHours() % 12;
    if (token === "Ko") {
      return localize2.ordinalNumber(hours, { unit: "hour" });
    }
    return addLeadingZeros(hours, token.length);
  },
  // Hour [1-24]
  k: function(date, token, localize2) {
    let hours = date.getHours();
    if (hours === 0) hours = 24;
    if (token === "ko") {
      return localize2.ordinalNumber(hours, { unit: "hour" });
    }
    return addLeadingZeros(hours, token.length);
  },
  // Minute
  m: function(date, token, localize2) {
    if (token === "mo") {
      return localize2.ordinalNumber(date.getMinutes(), { unit: "minute" });
    }
    return lightFormatters.m(date, token);
  },
  // Second
  s: function(date, token, localize2) {
    if (token === "so") {
      return localize2.ordinalNumber(date.getSeconds(), { unit: "second" });
    }
    return lightFormatters.s(date, token);
  },
  // Fraction of second
  S: function(date, token) {
    return lightFormatters.S(date, token);
  },
  // Timezone (ISO-8601. If offset is 0, output is always `'Z'`)
  X: function(date, token, _localize) {
    const timezoneOffset = date.getTimezoneOffset();
    if (timezoneOffset === 0) {
      return "Z";
    }
    switch (token) {
      case "X":
        return formatTimezoneWithOptionalMinutes(timezoneOffset);
      case "XXXX":
      case "XX":
        return formatTimezone(timezoneOffset);
      case "XXXXX":
      case "XXX":
      default:
        return formatTimezone(timezoneOffset, ":");
    }
  },
  // Timezone (ISO-8601. If offset is 0, output is `'+00:00'` or equivalent)
  x: function(date, token, _localize) {
    const timezoneOffset = date.getTimezoneOffset();
    switch (token) {
      case "x":
        return formatTimezoneWithOptionalMinutes(timezoneOffset);
      case "xxxx":
      case "xx":
        return formatTimezone(timezoneOffset);
      case "xxxxx":
      case "xxx":
      default:
        return formatTimezone(timezoneOffset, ":");
    }
  },
  // Timezone (GMT)
  O: function(date, token, _localize) {
    const timezoneOffset = date.getTimezoneOffset();
    switch (token) {
      case "O":
      case "OO":
      case "OOO":
        return "GMT" + formatTimezoneShort(timezoneOffset, ":");
      case "OOOO":
      default:
        return "GMT" + formatTimezone(timezoneOffset, ":");
    }
  },
  // Timezone (specific non-location)
  z: function(date, token, _localize) {
    const timezoneOffset = date.getTimezoneOffset();
    switch (token) {
      case "z":
      case "zz":
      case "zzz":
        return "GMT" + formatTimezoneShort(timezoneOffset, ":");
      case "zzzz":
      default:
        return "GMT" + formatTimezone(timezoneOffset, ":");
    }
  },
  // Seconds timestamp
  t: function(date, token, _localize) {
    const timestamp = Math.trunc(date.getTime() / 1e3);
    return addLeadingZeros(timestamp, token.length);
  },
  // Milliseconds timestamp
  T: function(date, token, _localize) {
    const timestamp = date.getTime();
    return addLeadingZeros(timestamp, token.length);
  }
};
function formatTimezoneShort(offset, delimiter = "") {
  const sign = offset > 0 ? "-" : "+";
  const absOffset = Math.abs(offset);
  const hours = Math.trunc(absOffset / 60);
  const minutes = absOffset % 60;
  if (minutes === 0) {
    return sign + String(hours);
  }
  return sign + String(hours) + delimiter + addLeadingZeros(minutes, 2);
}
function formatTimezoneWithOptionalMinutes(offset, delimiter) {
  if (offset % 60 === 0) {
    const sign = offset > 0 ? "-" : "+";
    return sign + addLeadingZeros(Math.abs(offset) / 60, 2);
  }
  return formatTimezone(offset, delimiter);
}
function formatTimezone(offset, delimiter = "") {
  const sign = offset > 0 ? "-" : "+";
  const absOffset = Math.abs(offset);
  const hours = addLeadingZeros(Math.trunc(absOffset / 60), 2);
  const minutes = addLeadingZeros(absOffset % 60, 2);
  return sign + hours + delimiter + minutes;
}
const dateLongFormatter = (pattern, formatLong2) => {
  switch (pattern) {
    case "P":
      return formatLong2.date({ width: "short" });
    case "PP":
      return formatLong2.date({ width: "medium" });
    case "PPP":
      return formatLong2.date({ width: "long" });
    case "PPPP":
    default:
      return formatLong2.date({ width: "full" });
  }
};
const timeLongFormatter = (pattern, formatLong2) => {
  switch (pattern) {
    case "p":
      return formatLong2.time({ width: "short" });
    case "pp":
      return formatLong2.time({ width: "medium" });
    case "ppp":
      return formatLong2.time({ width: "long" });
    case "pppp":
    default:
      return formatLong2.time({ width: "full" });
  }
};
const dateTimeLongFormatter = (pattern, formatLong2) => {
  const matchResult = pattern.match(/(P+)(p+)?/) || [];
  const datePattern = matchResult[1];
  const timePattern = matchResult[2];
  if (!timePattern) {
    return dateLongFormatter(pattern, formatLong2);
  }
  let dateTimeFormat;
  switch (datePattern) {
    case "P":
      dateTimeFormat = formatLong2.dateTime({ width: "short" });
      break;
    case "PP":
      dateTimeFormat = formatLong2.dateTime({ width: "medium" });
      break;
    case "PPP":
      dateTimeFormat = formatLong2.dateTime({ width: "long" });
      break;
    case "PPPP":
    default:
      dateTimeFormat = formatLong2.dateTime({ width: "full" });
      break;
  }
  return dateTimeFormat.replace("{{date}}", dateLongFormatter(datePattern, formatLong2)).replace("{{time}}", timeLongFormatter(timePattern, formatLong2));
};
const longFormatters = {
  p: timeLongFormatter,
  P: dateTimeLongFormatter
};
const dayOfYearTokenRE = /^D+$/;
const weekYearTokenRE = /^Y+$/;
const throwTokens = ["D", "DD", "YY", "YYYY"];
function isProtectedDayOfYearToken(token) {
  return dayOfYearTokenRE.test(token);
}
function isProtectedWeekYearToken(token) {
  return weekYearTokenRE.test(token);
}
function warnOrThrowProtectedError(token, format2, input) {
  const _message = message(token, format2, input);
  console.warn(_message);
  if (throwTokens.includes(token)) throw new RangeError(_message);
}
function message(token, format2, input) {
  const subject = token[0] === "Y" ? "years" : "days of the month";
  return `Use \`${token.toLowerCase()}\` instead of \`${token}\` (in \`${format2}\`) for formatting ${subject} to the input \`${input}\`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md`;
}
const formattingTokensRegExp = /[yYQqMLwIdDecihHKkms]o|(\w)\1*|''|'(''|[^'])+('|$)|./g;
const longFormattingTokensRegExp = /P+p+|P+|p+|''|'(''|[^'])+('|$)|./g;
const escapedStringRegExp = /^'([^]*?)'?$/;
const doubleQuoteRegExp = /''/g;
const unescapedLatinCharacterRegExp = /[a-zA-Z]/;
function format(date, formatStr, options) {
  var _a, _b, _c, _d, _e, _f, _g, _h;
  const defaultOptions2 = getDefaultOptions();
  const locale = (options == null ? void 0 : options.locale) ?? defaultOptions2.locale ?? enUS;
  const firstWeekContainsDate = (options == null ? void 0 : options.firstWeekContainsDate) ?? ((_b = (_a = options == null ? void 0 : options.locale) == null ? void 0 : _a.options) == null ? void 0 : _b.firstWeekContainsDate) ?? defaultOptions2.firstWeekContainsDate ?? ((_d = (_c = defaultOptions2.locale) == null ? void 0 : _c.options) == null ? void 0 : _d.firstWeekContainsDate) ?? 1;
  const weekStartsOn = (options == null ? void 0 : options.weekStartsOn) ?? ((_f = (_e = options == null ? void 0 : options.locale) == null ? void 0 : _e.options) == null ? void 0 : _f.weekStartsOn) ?? defaultOptions2.weekStartsOn ?? ((_h = (_g = defaultOptions2.locale) == null ? void 0 : _g.options) == null ? void 0 : _h.weekStartsOn) ?? 0;
  const originalDate = toDate(date);
  if (!isValid(originalDate)) {
    throw new RangeError("Invalid time value");
  }
  let parts = formatStr.match(longFormattingTokensRegExp).map((substring) => {
    const firstCharacter = substring[0];
    if (firstCharacter === "p" || firstCharacter === "P") {
      const longFormatter = longFormatters[firstCharacter];
      return longFormatter(substring, locale.formatLong);
    }
    return substring;
  }).join("").match(formattingTokensRegExp).map((substring) => {
    if (substring === "''") {
      return { isToken: false, value: "'" };
    }
    const firstCharacter = substring[0];
    if (firstCharacter === "'") {
      return { isToken: false, value: cleanEscapedString(substring) };
    }
    if (formatters[firstCharacter]) {
      return { isToken: true, value: substring };
    }
    if (firstCharacter.match(unescapedLatinCharacterRegExp)) {
      throw new RangeError(
        "Format string contains an unescaped latin alphabet character `" + firstCharacter + "`"
      );
    }
    return { isToken: false, value: substring };
  });
  if (locale.localize.preprocessor) {
    parts = locale.localize.preprocessor(originalDate, parts);
  }
  const formatterOptions = {
    firstWeekContainsDate,
    weekStartsOn,
    locale
  };
  return parts.map((part) => {
    if (!part.isToken) return part.value;
    const token = part.value;
    if (!(options == null ? void 0 : options.useAdditionalWeekYearTokens) && isProtectedWeekYearToken(token) || !(options == null ? void 0 : options.useAdditionalDayOfYearTokens) && isProtectedDayOfYearToken(token)) {
      warnOrThrowProtectedError(token, formatStr, String(date));
    }
    const formatter = formatters[token[0]];
    return formatter(originalDate, token, locale.localize, formatterOptions);
  }).join("");
}
function cleanEscapedString(input) {
  const matched = input.match(escapedStringRegExp);
  if (!matched) {
    return input;
  }
  return matched[1].replace(doubleQuoteRegExp, "'");
}
function cn(...inputs) {
  return twMerge(clsx(inputs));
}
const getBackendUrl = () => {
  const envBackendUrl = process.env.BACKEND_URL;
  if (envBackendUrl && envBackendUrl !== "/") {
    return `${envBackendUrl}/admin`;
  }
  return `${window.location.origin}/admin`;
};
const LOCALE = enUS;
const getFullDate = ({
  date,
  includeTime = false
}) => {
  const ensuredDate = new Date(date);
  if (isNaN(ensuredDate.getTime())) {
    return "";
  }
  const timeFormat = includeTime ? "p" : "";
  return format(ensuredDate, `PP ${timeFormat}`, {
    locale: LOCALE
  });
};
class CustomClient extends Medusa.Client {
  async fetch(input, init) {
    try {
      const result = await super.fetch(input, init);
      return result;
    } catch (error) {
      if (error instanceof Medusa.FetchError) {
        ui.toast.error("Operation failed.", {
          description: error.message,
          position: "top-right"
        });
      }
      throw error;
    }
  }
}
class CustomMedusa extends Medusa__default.default {
  constructor(config2) {
    super(config2);
    __publicField(this, "client");
    __publicField(this, "admin");
    __publicField(this, "store");
    __publicField(this, "auth");
    this.client = new CustomClient(config2);
    this.admin = new Medusa.Admin(this.client);
    this.store = new Medusa.Store(this.client);
    this.auth = new Medusa.Auth(this.client, config2);
  }
}
const enthusiastAdminSdk = new CustomMedusa({
  baseUrl: getBackendUrl(),
  debug: true,
  auth: {
    type: "session"
  }
});
class AdminEnthusiastConfigApiClient {
  async getAvailableProviders() {
    const response = await enthusiastAdminSdk.client.fetch(`/enthusiast/config`);
    const result = response;
    return {
      embeddingProviders: result.embedding_providers ?? result.embeddingProviders ?? [],
      languageModelProviders: result.language_model_providers ?? result.languageModelProviders ?? []
    };
  }
  async getLanguageModelsForProvider(name) {
    const response = await enthusiastAdminSdk.client.fetch(
      `/enthusiast/config/language-model-providers/${name}`
    );
    return response;
  }
  async getEmbeddingModelsForProvider(name) {
    const response = await enthusiastAdminSdk.client.fetch(
      `/enthusiast/config/embedding-providers/${name}`
    );
    return response;
  }
}
class AdminEnthusiastConversationsApiClient {
  async getConversations(dataSetId, agentId = void 0, page = 1) {
    let url = `/enthusiast/conversations?data_set_id=${dataSetId}&page=${page}`;
    if (agentId) {
      url += `&agent_id=${agentId}`;
    }
    return await enthusiastAdminSdk.client.fetch(url);
  }
  async createConversation(agentId) {
    const requestBody = {
      agent_id: agentId
    };
    const response = await enthusiastAdminSdk.client.fetch(
      `/enthusiast/conversations`,
      {
        method: "POST",
        body: requestBody
      }
    );
    return response.id;
  }
  async sendMessage(conversationId, dataSetId, message2, streaming, fileIds) {
    const requestBody = {
      question_message: message2,
      data_set_id: dataSetId,
      streaming,
      file_ids: fileIds
    };
    const response = await enthusiastAdminSdk.client.fetch(
      `/enthusiast/conversations/${conversationId}`,
      {
        method: "POST",
        body: requestBody
      }
    );
    return response;
  }
  async getTaskStatus(taskHandle) {
    const response = await enthusiastAdminSdk.client.fetch(
      `/enthusiast/task-status/${taskHandle.task_id}`
    );
    const { state } = response;
    return state;
  }
  async fetchResponseMessage(conversationId, taskHandle) {
    const taskStatus = await this.getTaskStatus(taskHandle);
    if (taskStatus === "SUCCESS" || taskStatus === "FAILURE") {
      const conversation = await this.getConversation(conversationId);
      return conversation.history[conversation.history.length - 1];
    }
    return null;
  }
  async getConversation(conversation_id) {
    try {
      const response = await enthusiastAdminSdk.client.fetch(
        `/enthusiast/conversations/${conversation_id}`
      );
      return response;
    } catch (error) {
      if (error instanceof Error) {
        throw new Error(`Failed to get conversation history: ${error.message}`);
      } else {
        throw new Error("Failed to get conversation history: An unknown error occurred.");
      }
    }
  }
  async updateMessageFeedback(messageId, feedbackData) {
    await enthusiastAdminSdk.client.fetch(`/enthusiast/messages/${messageId}/feedback/`, {
      method: "PATCH",
      body: feedbackData
    });
  }
  async getSupportedFileTypes() {
    try {
      const response = await enthusiastAdminSdk.client.fetch(`/enthusiast/supported-file-types/`);
      return response;
    } catch (error) {
      if (error instanceof Error) {
        throw new Error(`Failed to get supported file types: ${error.message}`);
      } else {
        throw new Error("Failed to get supported file types: An unknown error occurred.");
      }
    }
  }
  async uploadFile(conversationId, file) {
    const formData = new FormData();
    formData.append("file", file);
    const url = `${getBackendUrl()}/enthusiast/conversations/${conversationId}/upload`;
    const response = await fetch(url, {
      method: "POST",
      body: formData,
      credentials: "include"
    });
    if (!response.ok) {
      throw new Error(`Failed to upload file: ${response.status} ${response.statusText}`);
    }
    return await response.json();
  }
  async getFileUploadStatus(taskId) {
    const response = await enthusiastAdminSdk.client.fetch(
      `/enthusiast/file-upload-status/${taskId}/`
    );
    return response;
  }
  async getStreamStatus() {
    const response = await enthusiastAdminSdk.client.fetch(
      "/enthusiast/conversations/stream-status"
    );
    return response;
  }
}
class AdminDataSetsApiClient {
  async getInternalDataSets() {
    return await enthusiastAdminSdk.client.fetch(`/datasets`);
  }
  async connectDatasets(datasetId) {
    return await enthusiastAdminSdk.client.fetch(`/datasets/${datasetId}/connect`, {
      method: "POST"
    });
  }
  async synchronizeDatasets(datasetId) {
    return await enthusiastAdminSdk.client.fetch(`/datasets/${datasetId}/synchronize`, {
      method: "POST"
    });
  }
  async setAsActive(datasetId) {
    return await enthusiastAdminSdk.client.fetch(`/datasets/${datasetId}/activate`, {
      method: "POST"
    });
  }
}
class AdminEnthusiastDatasetsApiClient {
  async list() {
    return await enthusiastAdminSdk.client.fetch(`/enthusiast/datasets`);
  }
  async create(payload) {
    return await enthusiastAdminSdk.client.fetch(`/enthusiast/datasets`, {
      method: "POST",
      body: payload
    });
  }
}
class AdminEnthusiastAgentsApiClient {
  async getAgentById(agentId) {
    const response = await enthusiastAdminSdk.client.fetch(`/enthusiast/agents/${agentId}`);
    return response;
  }
  async getDatasetAgents(dataSetId) {
    return await enthusiastAdminSdk.client.fetch(`/enthusiast/datasets/${dataSetId}/agents`);
  }
}
class AdminApiClient {
  dataSets() {
    return new AdminDataSetsApiClient();
  }
  enthusiastDatasets() {
    return new AdminEnthusiastDatasetsApiClient();
  }
  conversations() {
    return new AdminEnthusiastConversationsApiClient();
  }
  agents() {
    return new AdminEnthusiastAgentsApiClient();
  }
  config() {
    return new AdminEnthusiastConfigApiClient();
  }
  async getStatus() {
    return await enthusiastAdminSdk.client.fetch("/enthusiast/status");
  }
}
const adminApiClient = new AdminApiClient();
function useActiveDataset() {
  const [dataset, setDataset] = React.useState(null);
  const [hasAnyDatasets, setHasAnyDatasets] = React.useState(null);
  const [isLoading, setIsLoading] = React.useState(true);
  React.useEffect(() => {
    const fetchDataset = async () => {
      try {
        setIsLoading(true);
        const res = await adminApiClient.dataSets().getInternalDataSets();
        setHasAnyDatasets(res.length > 0);
        const activeDataset = res.find((d) => d.is_active) ?? null;
        setDataset(activeDataset);
      } finally {
        setIsLoading(false);
      }
    };
    void fetchDataset();
  }, []);
  const datasetId = React.useMemo(() => (dataset == null ? void 0 : dataset.external_id) ?? null, [dataset]);
  return { dataset, datasetId, hasAnyDatasets, isLoading };
}
const LoadingSpinner = () => {
  return /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex min-h-screen items-center justify-center", children: /* @__PURE__ */ jsxRuntime.jsx(icons.Spinner, { className: "text-ui-fg-interactive animate-spin" }) });
};
const noDatasetsImage = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAjAAAAFoCAYAAABJxMFoAAAdQklEQVR4Xu3dcY9U93kv8LyEvARegl+CX8KwWySyLCqK1dYSf5jif65sVXbj+we3UYIFt1JcVG+WlRrjNaIpatMU1cQ2jYxDi9M4ONiYMTYx11zstU18iQnW3HlmdjZnfvOb3ZndM7tnZj4f6SfDztlZLzNwvvt7nvOcb3wDAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKCKarUD35ydna/NzOw7Ojs7d6b53/rqanSv+ZXZ2X2Xm+t8HDszM3dgz565h9LnAwAYiQgtzQDy1GoYSYLK0KvefJ6FP/mT+YfTrwMAsGXN4LJrdnY+dlm6Qsj+/X/e+Ku/+p+N559farz88iuN69dvND7++P92rfjYW29daZw9+5PGkSNHG48+eigNMq0wEzsz6dcFABhae8clyj7dgSNCS4SS3/3uy8ZmRKg5fvy5XJip7917YFf6/wEAsKFOqSj6V9LgErsqZTp16nRPkInSkiADAAxsdvZb0ZhbT4NL7LiMSoSi2JFJdmNWIkSl/38AAGuimTZtzo0el+ht2S4RZB5//Ik0yNT1xwAAXaJBtxkSFtLgEqWdzfa4bFWEpt6y0twZZSUAmHL9+lyilLNTwSUVISrZjdEfAwDTanZ2/rE0uIy6z2Wz+vTH1JWVAGBKrPa5XC6GgSjVVDG4pOLS67SsJMgAwARrD6LrbdCNEs24yffHKCsBwMToN4huJxt0U/H/cevWx42bN2+1ykX37t1LD+kRx8X03/T7ip4eQQYAxlS/Bt1RDKLbinr9g8Zbb/2mZ0WY+eqr++nhK+kH9McAwITYiUF0mxE7L2lwSdft23caDx58nX5qj1xZKf4M3PUaACquCoPohhHB5Nq1ek9oSdfVq+81VlY+Sz89K24YmQYZ/TEAUEFVHEQ3jAgnEVLS4JKuOCZTVurRp6zUcFsCAKiAfn0uVRpEN6j79++3gkcaWnKrT39Mj3i+KJ0lQaauPwYAdsg4DaIbRgSZmzc/6gkt6Xr77Xda/TGDyPXHxCwcZSUA2CbjPIhuGJ9/fnfgstKg/TFRUovSWhJk9McAwKhM0iC6YQzaHxOXYw9aVsr0x9RnZr51KP0zBwA2aRwG0Y3aoGWlWMP0x6RlpXaQ0R8DAJvWr0G3aoPotlMEmRs3bvaElnTFjs0g03xDn/4YZSUAGFZZg+gi6EziLs0gZaXYiRlU/BnFjlayG9Nw2TUADGCrg+h+9asrrfsDPfroYz0n4whA8dgk7d7E9xJXI6Xh5cqVdxpffHE3PXxD/fpj7MYAQMZWB9H1mXfSd0WQmRRRVoodmfbNID9q3LnzSePrrze+9cB6IjAmVysJMQDQ0a/PZZhBdHFcsYcjTryDhJn4GvR3/fqNnhATr1f6GgLAVClrEF3sFhSf49ixdjA5duwHax+LklKsNNhcv/5+8mwUpX+2zbD5dPo6AsBUKHsQXdy8MBdgYmemuIsTZaYILEeOHF07NnpmWF8S+lbswgAwVUY1iC5CSjpdNk66jz/+RLaZt7MiNLGxNCDWanMPpa8tAEyc7RhEF/0a6SyT9VYcO0lXI41Sbxlp/4H0NQaAidGvQXdUg+jiOeNke/jwEz2Bpfi1Y0ehrOA0DdIdmCgBpq81AEyEsgbRbVYElPhaFy9eaoWa2KEZNLTcvfu7xhtvXG6cPv3PrXX27L81Llx4o/nxwT5/0qSNz3pgAJg4Wx1Et9PiHkIRWhYXX8yuN998K/2UiZaWj3bvnvvH9DUHgLG11UF0VRG7L2loSVcEnGvX6umnTpw+N3t0FRIA469fn8swg+iq5t136+vuwnRWlJYmtawUl5enV3Z1lquQABhrZQ2iq6LYiYm+lzS05NYk9cdE6MzcCylZrkICYAxtdRBd9Jl88slK48aNm63djriHT/x+O8TXjgbdH/3ozFoA+elPz/ctCQ0aZGLHZpz7YyK4vPDC6Z5dl+9+91gz0Pxd18dchQTAWNnqILoIKhEWiuGhuOLjo97NiK+fft3OWq8kNGhZaRz7YzI3bmwNATx79qetO1vHr4uP6YEBYCyUMYgudj1yJ/sIFBEc0sdGtZvxr//aP8B01noh6s03fz1QkHn55Qt9n6Mqos8lvUT6298+2Fhe/nEruMRaWjrV9XgzwC6k7w8AqJR+DbrDDqKLMFI8ub/xxputUk5RlGripF887sqVq13HlCH3dXJrvZLQoGWlWOuFoZ0Sr10aXObmHmmVii5denMtvFy4cLHxyCMHi8fV9+7duyt9nwBAZZQ5iK64wxLBYD3F8tJGx25FGSWhCDK53aN0rfcc26nT51J8TWNFn0sxuMSK8lGEmj8eN7+yZ4+rjwCoqFEMoiuWbSKg9NuRiECQNteOWhkloWHC0Acf3Ew/fVvkGnSjt+W1117vCi6XLv2y8cwzf5OGnLrwAkAljXIQ3a1bt3tO5LEj0bnyKIJLlIvSEHDjxm+TZxqNskpCEYbS43NrvecoW/S5pMPoDh58fK1Btxhc4vLp7l2X1uTdZ2u1mqZdAKqlX59L2YPoIoykAaXfil2Y7QovRWWUhIYJQ9FjM6ogk2vQjXBy4sTJruDSadRNg8vs7Px5l0sDUEk7MYguyi3nz1/oCTPx+/j4r399tafBN+fBg68b9+7da4Ws+HWZyigJxe7SoM/RLwxtRm4QXa5Bt9Pnkl4i3Vz16H9K3ysAsOO2OohuJ0VYiXkyV66803Uyvnnz1kDBZxhllISGCUP9nmMQ/QbRRT9L2ucSVxf1BpcIsvNPKxcBUDlbHURXBXEJcFoCKa4IN2UGmUFLQhFA+onnGDQMRb/QsDYaRNdZnT6X7uCizwWAiipjEF1VrKx81hNa0nX16nut48q0UUlovQDTMUgYitsrDCrX55IOouusXINu9LmY6wJA5fRr0B12EF3VRDiJkJKepNMVx0SfTJlyJaG43HuYeznlniMal2OXZhCDDqKLFbswyTC6mKZ7WYMuAJVU5iC67VZs0O23QxTHbFRO6qxR9MfE80XPylaeN0JPlIziv4M8z7CD6PJ9LvsOpe8VANhxoxhEt53u3Pm0p0F3vZLQ/fv3mwHlo57Qklu3b99JP31s5Bp0Bx9Ep0EXgIoa5SC67RL/n2noKK71SkKff3534LJSvzBURVsdRBc3X9TnAkDl9OtzKXsQ3XaIstDbb3fvvuTWeiWhQftjYvZKv+eoglyDrkF0AEyEdp9Lb4PuOPS59FNGSWiY51gvDO0Eg+gAmGgzyWXR4zKIblBllIQiyMRlyennpCueo18Y2i4G0QEw8WaSXpfjx38wduWiQZVREhr0OdYLQ6NkEB0AE6/5U/ZTxZNX/NQ+6coqCcVl14MEmbi/Ub/nKFOuz8UgOgAmzuqVRmsnsCgbTZNhSkKffPJp+uktZYWhrTCIDoCp0jx5HSqeyOIn+GlURkkogkxMxE0/J13rPcewDKIDYCpFyaB4Qpt2g5aE1ttJGSYM9XuOQeQadA2iA2AqFAPMtJWP+hm0JBR3qV7PILcliBk1wzKIDoCp1wwwZ4onty+/nMwrjzZjo5LQIGWgjcJQ7MIMKtegaxAdAFNpJumBuXjxF+l5c+pFUKnXb7TCRqwbNz4c+hLze/d+33qOzj2Z4nliBycCzkYMogOAxJ49cw8VT3ZRmrALUw0G0QFAHzPJDkysKFOwsyZpEN3S0qnayZMvnjl5cvl8/Dp9HACGll6FVDxZRhMq2yvX5zLug+gWF5cvLy6+2Fhd9fRxABhavwATa//+P5uKqbxVMMmD6CK0CDAAlCq9CuncuZ/1nByjLyZKGpRvGgbRCTAAlC5OfsUTYqdUEZfhpkHmyJHvKyuVKNegO4mD6AQYAEpXqx34ZvOEGD/Ft06M0W8RJ8z2ifPNVgmj+8QZd6p+TpDZgmkbRCfAADASMzNzB4onyNgFKJ5IL1x4vWcHQFlpeLkG3WkYRCfAADAyUY4onixjR+C11y52nVRzzaMRZAy/W9+0D6ITYAAYqZmkH6Z9kn0uuzuQBhllpV6TNIhuYeHMN0+efPHA4uKpp0+eXD4Uvx50NUPLigADwEjVant3xU/8xRNp9MVEaOk+4b7eulKm+4S7r3XCNsl3sgbRhWbweLYQQrayLqfPDQClWe2L6QoyTz75nZ6ykv6Ybrk+l3EfRBcWFn60qxk+nj158qWF3tWesrvxevHMwsLyw+lzA0Cp2lcodffGxGqXQLqDTK6sFEFmWspKkzyIDgDGUq22d9fu3ft+WDzh5spKsU6cWOw5OU9yf8w0DKKrosXFlx5r7/zErs6ZXenjALAmdghmMv0xaXkkV1aaxNsS5Bp0J3EQXRUV+2qaIWYhfRwAeuT6Y3JlpQgycTl28bhJ6I+ZtkF0VSTAALAptVZZaf7Z7l2FdrmoM8m3s3L9MdEvMm5lpVyD7jQMoqsiAQaALWkHmcH6Y8b1tgTTPoiuigQYAEqRKytFkMmVldJ+kCjHnD37kzQ37LhJGkQ3aQQYAEo1057m2xVkcv0x5879rKesVKX+mEkbRDdJYiqwAANA6WqZstK43JYg1+eSu9IqVr5Bt5qD6CbJ6lA9AWYD8T6cmdkfO6NHZ2fnzsy0f7CIVXjPzq/EDKLmOh/HNdchfVrA1Isg0zyhX07DQNofE2WlXH/M888vbVuQMYhu+3XurzTsvZXieAEmb3XUwdHV+UI9f6cGXxFsIvTMHUi/BsDUyPXHtOelDNYfM8qykkF0O2dxcflyMYhsdgkw7b9jEaLT9/Gjjz7WOHbsuVaP2cWLlxrXr99ohfXOit+/9daV1uPxA8Phw+n7u7Xqzed/au/eA7vSrwswFQa9LUGUa9IdjggyUd4pS78GXYPotk//+ysNem+lWC8txPOkzz0tYsclDS7xnj516nQrmGxGBJv4oSETZup2ZICpVcv0x0RZKW5BUAwNsXL9MREw4h/XzZaWIgTlgss4DaJrl16Wj/aezDdaPUHhQPrcjIda7cCu1b6VtfdlJ7hEOC9LhKB0aONMayzAvLEAwHTas2fuofiHsPgP43r9MWmQiRVhJra9Y/s7gsn16+8n2+PvNy5e/EXr8dhGj+309DkiuKRfsxOeeoNLNQbRRfBIyyibXCsRhtLnn1ZLS8tP/XFXp5r3V2rfYLXVbNv13iw7uKTih4Y0yLSDvLISMKVy/TG5slInVDz55Hd6gsWwKz4/elzSHZdY+T6Xag2iSwPMwsKpp3sbXTde01x6SS0sLD9c/DONP5/0mJ3UDi5zT6XNuds50Tq+TvzAkP590h8DTK1aLS737O2PiZCRCzKdoBFlpzgmAsfBg4d7gk3s2sSK0BPHRQBK+1s6a5wG0aUBZmlp+eH0GIZT5QAT4XkmCfkRXDbb47JVEWQys4/q+mOAqRVBJtcfkyvxlLXGcRCdAFO+KgaY1Qbd88X3ZfS5jPKqvGHkykoRZKI8nH4vAFMhGgTbP9F1B5lcyWezq3+DbvUH0Qkw5atSgIkG3eZ7cSENLqPuc9ms6DFLg4z+GGCq5fpjOk23/UpLG60IQfngMj6D6ASY8lUhwPTrc4n3axWDS1GfslIjvp/0+wSYCrU/9sd0BZlOmIneluiFiWBy7twrrR6Xzorfx0yZePyZZ/5X9kqm9gyN8ardCzDl2+kAMzs7/1gaXHayz2WzchOt2393x+vvGECp4h/B5j/0Z9J/6Idf8yvR4zIuOy4pAaZ8OxVgcoPoohxTleDy4MHXjU8//WxtNMHnn99ND8nK9cfE96msBEy91Xu+HIogEn0r7Xsu9QSbeqwIPXFc3Niu6v0tgxBg+ov5LZ3LxIdZi4unnt7OALPeILqq+OKLu40rV97pKcNevfpeY2Xls/TwrPh+0qGR+mMAplR7BP+pH8bQtZgBkz4+rWIoXzN8rBSDyGbXqALMTg2i24x6/YOe8FJc8fhXX91PP61Hn/6Y5g8X33IPMQAICwuxo5LeMiG9pcL6qxlgni17QnG/Bt3tHEQ3rDt3Pu0JLbl18+atgYNMWlZqBxn9MQBsUrv0MszJPm642BMUjlZ1BP9OqtogumHcv3+/Ua/HHat7g0txRVnpk08+TT89q09/jLISAMOLklRaRtnkupw+97Sq+iC6YUTPS4SUNLika9D+mCiXRdks2Y2JdVSQAWBgvQHmpcfSRtf11sLC8qH2f8stvYyjcRtEN4woA739dm9jb7qGKSvl+2OUlQAYQBpg3OhxeP36XMZhEN0woqx08+ZHPaElt27d+nigIHPx4qWeslIEmXEddQDANukNMHZShjEpg+iGEUGmzLJS0B8DwFDSAJM+Tl7VB9Fth2H6Y+7du5d+eo8+ZaVG7G7FLlf6GgAwxQSY4YzDILrtFBN7I3ikoSW3oqw0iHi+I0eOpkGmrj8GgDUCzGDGaRDdThi0PyaOG1SurBRBRlkJAAFmA/0adKs8iG4nRZjrV1aKuTKbkbstgWm+AFNOgOlvnAfR7bS4+WOUjGJXJv671V2qCIuHDz+RhJi5p9LXDIApEZdNt6frvnhmYeEFP9V+Y7IG0U2aCJDF16X5Ov1p+voBwFSZ5EF0kyJeh6QvZsUVSgCUYmlp+eH2rk56H6Xcyt1baXvvr9Svz2XSBtFNihh+V3ydmsvOIQBbt7i4fLnYV7OF9Wz63GWbxkF04y5CZfH12r177h/T1xUAhtYMHvVCCFlJ75+03op7Ky0unnp61PdXMohuvD366GNrr1v0K6WvLwAMLQkw9fTxnWQQ3WQovn4CDAClqGKAMYhucsQuWfI66oEBYOuqFGD6NegaRDe+0um8tdrcQ+nrDgBDq0qAMYhu8sSOWbL7YgcGgHLsdIAxiG7yRJnv+PEfpMGltVyFBEApdirAGEQ3mX71qys9ZaPi0sQLQCmSAHM5fbxs/fpcDKIbbxFc0lsHzM090lhe/rEAA0D5FhZeqnWm7C4snKqlj5dpnAfRffnl/2usrKy01oMHX6cPT612uei5nuBy/PjfNS5derNx9uxPux6b0QMDwLgY90F0Dx48aHz88e219fnnX6SHTJ0ILi+8cLpV9iu+rs888zeN1157vfna/qa1HnnkYNfje/fu3ZW+PwCgUsZlEN1XX91v1OvvN65du964efO3rd8XDRJgooRy5Mj3WztKk96AHN9fGlwef/yJ1m5LJ7jEil2Y4jEzM3NPp+8RAKiMcRtEt7LyWWs3qLhu37699ngaYO7evbv2WMynSXs/YndpEuX6XL797YOtPpdicLl06ZetnZjicbt37/th+j4BgEro16A7DoPo7t+/33j33fe6QszVq++u9bvcu3ev8cUXX7TCSwSaEDsRaUh7/vmlSoa0rciFtGKfSzG8xC5MWjbavXtu5Df6BIBNmZRBdLEbc+3ae63wslHoiu/t8OEnWuWUcQhpw+r0uaQh7bvfPZYNLlFG6j52fiXeF+l7BQB23DgPovvDH/7Q2lkpLtpyDboRUIoNuv3KRe0duPmna7XayO5QDgCbMu6D6P7zP3/Z+Pd/fyW7PvjgZnr4uu7c+aTxve8db/zFXzzWs+Lk/uGHwz3fTsoNojt48PGeBt0ILnH5dJSSisc2w+yCK40AqJx+fS7jNojunXeu9QSXWK+88h+N69ffTw9fVwSUJ574657wEusv//J/NC5f/u/0Uyon16Ab4eTEiZNdwSXW0tKpTHCZPx+7cen7BQB23DgPotsOsROTrhiAV2UbDaLbuM9lX12fCwCVNO6D6IYRzbtnz/6ktf7rv36ZPtzlo4/+T+Pv/36p8bd/e6LxL//yb60pveNi0EF0sS5cuJgJLvpcAKiocRlEV4a4gigaj+Ok3lkRYjo+/PC3jXPnXm6Vg37/+9+3Pvbzn19s7UB1VvTBbBR6qmDQQXSdPpfu4NK+LFpwAaByxm0Q3VZFz0sxuJw+/U+tnpCOmLx77NgP1tbrr/9i7bErV37TCi7FIBO7MlWU63PJDaKLlW/QnT+vQReAyunXoDuJM06KIpS9+urPW028cZKPoXZF6wWYjth5iVLS9773v1s7M1Wy1UF0UT7UoAtAJU3KILpRGCTAVFEZg+hm3D0agCoa50F02+nVV/+j8Q//sNw4ffrH2Zs5Vk2uQdcgOgDGXq7PZZwG0ZFnEB0AE2vPngMPzSTlonEbREe3XIOuQXQATIx2ePljk27suuhzGV8G0QEw8VbvX1TvnLyi1DDJVxdNMoPoAJgaM8nNFzXqjieD6ACYGqtNu2snseiXYLzk+lwMogNgokWDZvFkVhyTT7UZRAfA1JqZ2X+geFJTPqo+g+gAmHp79szFpdNrJzc7MNWWa9A1iA6AqbPaA7N2+bQemGoyiA4AErOz82eKJ7uXX341PX+yQ3INugbRATD10quQYu3f/2eNev399FzKNjKIDgDWkV6FVAwxGnq3n0F0ADCA9CqkdMUugKm828MgOgAYUHoV0okTi60yRXpyjF2BL790U8dRyPW5GEQHAOtIr0KKn/jb5YnXey7DjatglJXKYxAdAGxB9EwUT4xxNUvnxBm/Tk+cbva4NQbRAUAJVndh6p0TZOwCnDv3SteJNEpLaZDRHzO8XIOuQXQAsEm12t5daYgp7sTEypWV4mqlOCmzPoPoAGBE0hATq3357sWeIBMn3+Jx+mPycg26BtEBwAikPTGxYlcgdgfSE25aVoqTtbKSQXQAsCNiN2b37n0/LJ5U49LetKwUK3fZ9bT2xxhEBwAVMDMzF4Pu6mmQyZWV0v6YKCtN092tDaIDgIppnmAPpUEm1x9z7tzPespKk94fk+tzMYgOACqilikrtfs6nus5Uef6YyatrGQQHQCMkQgys7Pzl4sn41x/TJSVcv0xzz+/NNZBxiA6ABhjuf6Y9lC2wfpjxrGslGvQNYgOAMZQ7rLrXH9MrqwUQeb69ffTnFA5BtEBwASqZfpjoqwUtyAonuD7BZmq9sfkGnQNogOACbNnz9xDM5nLrnP9Mb0lln2VuS2BQXQAMIVy/TG5slIEmSef/E7XyX8n+2MMogOAKVdr3Vuptz8mrtZJg0yurBThYDvLSgbRAQBrIsjk+mPSslKsKNGkfSSj7o/J9bkYRAcAtOTKShEUzp17pSsk5PpjoqxUdn+MQXQAwMByQaZff0waGiLIxC7IZi+9jh6X3I5LLIPoAIB11TJlpViD3pagE2aOHPl+64aREUoi1MSuSnHFx6K3Jab/RmhJe1xiRRNx2qBrEB0A0FcEmdnZ+TPFoNCvPyZ2QyJU5MLMsCt2VXKlIoPoAICB5cpKMek2LSt1Vtz1OkJOlH0ijBw8eLgndMSKsBMrdlni2GjMTUNLZxlEBwBsyupl19FjshYicv0xZa58n4tBdADAEGqZ/pgoK+X6Y7ayDKIDAEpXaw3C673sOnZk0kuvB13R49Jnx8UgOgCgPLn+mE6Yid6WuGFkhJIINXE1UXHFx4q9MmmPS6xoItagCwCMRDTTrpaWesLMsCuac5WKAIBt1b7r9dyBKPtEGGmuy6sD5tKwUo8Vuyyrx9aEFgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACgsv4/gpiFpV6hMooAAAAASUVORK5CYII=";
const columnHelper = ui.createDataTableColumnHelper();
const columns = (navigate) => [
  columnHelper.accessor("name", {
    header: "Name",
    enableSorting: true,
    sortLabel: "Name"
  }),
  columnHelper.accessor("description", {
    header: "Description"
  }),
  columnHelper.display({
    id: "actions",
    header: "",
    cell: ({ row }) => {
      return /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxRuntime.jsxs(
        ui.Button,
        {
          variant: "secondary",
          onClick: (e) => {
            e.stopPropagation();
            navigate(`/enthusiast/chat/new?agent=${row.original.id}`);
          },
          children: [
            /* @__PURE__ */ jsxRuntime.jsx(icons.ChatBubble, {}),
            "Start Chat"
          ]
        }
      ) });
    }
  })
];
const AgentTable = () => {
  const { dataset, hasAnyDatasets, isLoading: isDatasetLoading } = useActiveDataset();
  const noDatasets = !isDatasetLoading && hasAnyDatasets === false;
  const noActiveDatasets = !isDatasetLoading && hasAnyDatasets === true && dataset === null;
  const [isLoading, setIsLoading] = React.useState(true);
  const [agents, setAgents] = React.useState([]);
  const navigate = reactRouterDom.useNavigate();
  React.useEffect(() => {
    const fetchDatasetAgents = async () => {
      if (!dataset) {
        setAgents([]);
        setIsLoading(false);
        return;
      }
      try {
        setIsLoading(true);
        const res = await adminApiClient.agents().getDatasetAgents(dataset.external_id);
        const availableAgents = res.filter((agent) => !agent.corrupted);
        const availableAgentsDetails = await Promise.all(
          availableAgents.map((agent) => {
            return adminApiClient.agents().getAgentById(agent.id);
          })
        );
        setAgents(availableAgentsDetails);
      } finally {
        setIsLoading(false);
      }
    };
    if (!isDatasetLoading) {
      void fetchDatasetAgents();
    }
  }, [dataset, isDatasetLoading]);
  const table = ui.useDataTable({
    columns: columns(navigate),
    data: agents || [],
    getRowId: (row) => row.id.toString(),
    rowCount: agents.length,
    onRowClick(event, row) {
      navigate(`/enthusiast/chat/new?agent=${row.id}`);
    }
  });
  if (isLoading) {
    return /* @__PURE__ */ jsxRuntime.jsx(LoadingSpinner, {});
  }
  if (noDatasets) {
    return /* @__PURE__ */ jsxRuntime.jsx(ui.Container, { children: /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex h-[385px] items-center justify-center", children: /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "text-center space-y-3 max-w-md px-4", children: [
      /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex justify-center mb-2", children: /* @__PURE__ */ jsxRuntime.jsx(
        "img",
        {
          src: noDatasetsImage,
          alt: "No connections illustration",
          className: "h-48 w-auto"
        }
      ) }),
      /* @__PURE__ */ jsxRuntime.jsx("h2", { className: "text-lg font-semibold text-gray-900", children: "Enthusiast needs to be configured." }),
      /* @__PURE__ */ jsxRuntime.jsx("p", { className: "text-gray-600 text-xs leading-relaxed", children: "Go to settings to configure your Enthusiast connection." }),
      /* @__PURE__ */ jsxRuntime.jsx("div", { className: "pt-1", children: /* @__PURE__ */ jsxRuntime.jsx(
        ui.Button,
        {
          variant: "secondary",
          size: "small",
          onClick: () => navigate("/enthusiast/settings?create_dataset=true"),
          className: "border border-gray-300",
          children: "Open Settings"
        }
      ) })
    ] }) }) });
  }
  if (noActiveDatasets) {
    navigate("/enthusiast/settings");
  }
  return /* @__PURE__ */ jsxRuntime.jsx(ui.Container, { className: "p-4", children: /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex flex-col min-h-0", children: /* @__PURE__ */ jsxRuntime.jsxs(ui.DataTable, { instance: table, children: [
    /* @__PURE__ */ jsxRuntime.jsxs(ui.DataTable.Toolbar, { className: "flex flex-col items-start justify-between gap-2 md:flex-row md:items-center flex-shrink-0", children: [
      /* @__PURE__ */ jsxRuntime.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { children: "Agents" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { className: "text-ui-fg-subtle", size: "small", children: "Choose an agent to start a session" })
      ] }),
      /* @__PURE__ */ jsxRuntime.jsxs(ui.Button, { variant: "secondary", onClick: () => navigate("/enthusiast/settings"), children: [
        /* @__PURE__ */ jsxRuntime.jsx(icons.CogSixTooth, {}),
        "Settings"
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx(
      "div",
      {
        className: "overflow-auto min-h-0 max-h-[calc(100vh-16rem)]",
        onWheel: (e) => {
          const container = e.currentTarget;
          container.scrollTop += e.deltaY;
        },
        children: /* @__PURE__ */ jsxRuntime.jsx(
          ui.DataTable.Table,
          {
            emptyState: {
              empty: {
                heading: "No agents available",
                description: "You can configure available agents in Enthusiast's admin panel"
              }
            }
          }
        )
      }
    )
  ] }) }) });
};
function Error$1({ heading, content }) {
  return /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex min-h-screen items-center justify-center", children: /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "text-center space-y-2", children: [
    /* @__PURE__ */ jsxRuntime.jsx("h2", { className: "text-lg font-medium", children: heading }),
    /* @__PURE__ */ jsxRuntime.jsx("p", { className: "text-gray-600", children: content })
  ] }) });
}
const EnthusiastMain = () => {
  const [isConnected, setIsConnected] = React.useState(null);
  const [isLoading, setIsLoading] = React.useState(true);
  React.useEffect(() => {
    let mounted = true;
    const fetchStatus = async () => {
      try {
        setIsLoading(true);
        await adminApiClient.getStatus();
        if (mounted) {
          setIsConnected(true);
        }
      } catch (err) {
        if (mounted) {
          setIsConnected(false);
        }
      } finally {
        if (mounted) {
          setIsLoading(false);
        }
      }
    };
    void fetchStatus();
    return () => {
      mounted = false;
    };
  }, []);
  if (isLoading) {
    return /* @__PURE__ */ jsxRuntime.jsx(LoadingSpinner, {});
  }
  if (!isConnected) {
    return /* @__PURE__ */ jsxRuntime.jsx(Error$1, { heading: "Something went wrong.", content: "Please check your Enthusiast integration." });
  }
  return /* @__PURE__ */ jsxRuntime.jsx(AgentTable, {});
};
const icon = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFsAAABbCAYAAAAcNvmZAAAF20lEQVR4Ae2dT2xUVRTGv9d/YqtDFRpjJFCXdEMJLGqkTbupxo1iunBhYmVRlpaEHYktJrhqYruURa1x48IAK4JsOhaNLDQOm3FJISTEUBQqFOxM53nPnXntTKcz7868d+6bNz2/ZOi0czvM+955555z7n09DgLg/opeZDCMFhyBq54D3WhOHqnHLXWMKbQj5byFZdSBgxpx/1CCPsFn6j8eV7/di91JSh3/nBI+WYvwxmJrK97AlBZZyOMooV0sIIs5Z0Rbv89wA9wbypKBaTSvmwgGiZ7DGWcIV6oPq0LBZVxWT4chmDDtDOJ8pRcril1wG4uFiU8wxcGCcwKf7vzSDojQAakgeMuOgzeU6xCh60cFEWqem9r+4zKx9SAX/RCCMq20HC7+QYkb0e4ji9sQwoGilAyOemFhqWVn8Q2E8CBX3IZJ79tNyy6Y/CKEsHmkjPhNsu4ty3bwCQQOulVaP05PtNjaV0sazoeL9+lL3rIzEn0wM+wuojsvtiPpODsd+MDz2Ucg8JJDvye2uBFuHOz1xJbSKTcq5m6BYA0R2yIitkVEbIu0IWJW11pw/bdOpO+2496DNv09kejMYfTYMwz0PceB/Vk0A7oQpYpQLixzb6UNs5f24vrvnVh9Wv0CGzj8HDOnH8Zd9GQkYs//mNBC+4m8nVPvruLzj/9BTLEv9uylbi10vfQdWsf35/7SbiZmJK1OkEGFJtJ3OvDRhdc2fXucsPaJf1h6KbDQHiR4WO9lEyti68nwcrjizF9L4OafexAnrIhNVk1hXdjEzbrtiH2jCxyQZcfJutnFpjiaw6q33v9FxAV2sbktTyy7iPSddnDCedWEDbvY3GJQvE3RThxg/5Sjx5+xJyBxySYjK0TtQpLxy3ljjIhtERHbIiK2RURsi4jYFmGPs89e3Oeb2NDKCzfpux344rtXqo7pO5RRy25/gwt2sW+m9/hmePQ692IurXf61VESnbzpBrsbSXT5Z3e1LvzWA1m2HyafNQjsR3mgx99ibVTuTApi3FcXv9j7N3zH2KhJm5zQvoPr4IRdbJMDoAVczmIVCW1SfTS5CoPALvbo8TXfMST0/LWXwYXJshwJTXtSOOGfIFX5k7aP+UGr5Rx1aZoYacHZj4HD/4EbK0kN1bT9IOs++/U+hAm958RXPUZjxwafgBsrYtOBmIRV5FvD3J5gklAR5EJMrr6gWBGbXMmpd/41GhvGFjVt0bM9eiuyCZMnH8MG1mojtAPVNGkgwWk/Xz0+nK6O9869biw0WfXYEL8LIayJXYt1EyTaick38q7AQHQaT2P1SaphkdmWVRPW1yDJ6iiurhXyqRSa9R3M6BNHriK/st6qrbieq2Bs6ClmJlZgCfv7s0kUEtxGPaQa5D6uXrhvc2Xe/oIv1R9mJh4iSkjoKDbUR2Jeo8fWIhOcJumLZx5Ecn9OZNcyRQC2BfcsmrvgVIlIHScJfvXL++wFIMK7FycqoYnI1yDp4EkEzlh38sPHejKM+ta+htp+ll8nfFXFzC8gDKi4NHN6pVHun0w25F4/SlCoLGpyQ+p2aAKk5ImulAa7SbUxxS7Gu5WDHl4S450AEjPR5RaSnXX91UZBqU4aX+wmQnax2kTEtoiIbRER2yKe2L6dKITg5MV2RWwL3PIs+ycIvLhI5cVuQQoCL62e2JnqzWyEgDhYdt4uiO2M6P5YSQhcJOmfrdDPxbcQeMjkuzKVdvP4GbelP03IFDUIKk1qcpX7Ygl1ktnStERsZwgLEN8dJucL86GmPF3PKpN36uvkKZSQdAZ1W8dNysTWZ8LBSUgKXz9krNnyRm6VWxT+gn7lw6lJkPzV+FrIt7gaKXYfHhWrfhSEq1dHxKXUgKM0qyA0UbXEqgVXvywxuBFzKsQ7Wklowrxh8hLG1amZkji8jCQo6hj0j+JqbwW+pFuAUwPl3d5uJQlDkT1qFtvDXVQW3oph9Q7UN6u38GjmJvfL2ifnVDl6A1dMWn8LEfI/IVMVMXVIjTAAAAAASUVORK5CYII=";
const EnthusiastIcon = React__namespace.forwardRef(({ ...props }, ref) => {
  return /* @__PURE__ */ jsxRuntime.jsx(
    "img",
    {
      ref,
      src: icon,
      alt: "",
      width: 15,
      height: 15,
      style: { objectFit: "contain", display: "block" },
      ...props
    }
  );
});
EnthusiastIcon.displayName = "EnthusiastIcon";
const EnthusiastPage = () => {
  return /* @__PURE__ */ jsxRuntime.jsx(EnthusiastMain, {});
};
const config = adminSdk.defineRouteConfig({
  label: "Enthusiast",
  icon: EnthusiastIcon
});
const handle$2 = {
  breadcrumb: () => "Enthusiast"
};
const EnthusiastNewChatPage = () => {
  const location = reactRouterDom.useLocation();
  return /* @__PURE__ */ jsxRuntime.jsx(reactRouterDom.Navigate, { to: `/enthusiast/chat/new${location.search}`, replace: true });
};
adminSdk.defineRouteConfig({});
const ColumnHeaderWithTooltip = ({ name, tooltip }) => {
  return /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-x-1", children: [
    /* @__PURE__ */ jsxRuntime.jsx("span", { children: name }),
    tooltip && /* @__PURE__ */ jsxRuntime.jsx(ui.Tooltip, { content: tooltip, children: /* @__PURE__ */ jsxRuntime.jsx("button", { type: "button", className: "text-ui-fg-subtle hover:text-ui-fg-base", children: /* @__PURE__ */ jsxRuntime.jsx(icons.InformationCircle, {}) }) })
  ] });
};
var isCheckBoxInput = (element) => element.type === "checkbox";
var isDateObject = (value) => value instanceof Date;
var isNullOrUndefined = (value) => value == null;
const isObjectType = (value) => typeof value === "object";
var isObject = (value) => !isNullOrUndefined(value) && !Array.isArray(value) && isObjectType(value) && !isDateObject(value);
var getEventValue = (event) => isObject(event) && event.target ? isCheckBoxInput(event.target) ? event.target.checked : event.target.value : event;
var getNodeParentName = (name) => name.substring(0, name.search(/\.\d+(\.|$)/)) || name;
var isNameInFieldArray = (names, name) => names.has(getNodeParentName(name));
var isPlainObject = (tempObject) => {
  const prototypeCopy = tempObject.constructor && tempObject.constructor.prototype;
  return isObject(prototypeCopy) && prototypeCopy.hasOwnProperty("isPrototypeOf");
};
var isWeb = typeof window !== "undefined" && typeof window.HTMLElement !== "undefined" && typeof document !== "undefined";
function cloneObject(data) {
  let copy;
  const isArray = Array.isArray(data);
  if (data instanceof Date) {
    copy = new Date(data);
  } else if (data instanceof Set) {
    copy = new Set(data);
  } else if (!(isWeb && (data instanceof Blob || data instanceof FileList)) && (isArray || isObject(data))) {
    copy = isArray ? [] : {};
    if (!isArray && !isPlainObject(data)) {
      copy = data;
    } else {
      for (const key in data) {
        if (data.hasOwnProperty(key)) {
          copy[key] = cloneObject(data[key]);
        }
      }
    }
  } else {
    return data;
  }
  return copy;
}
var compact = (value) => Array.isArray(value) ? value.filter(Boolean) : [];
var isUndefined = (val) => val === void 0;
var get = (object, path, defaultValue) => {
  if (!path || !isObject(object)) {
    return defaultValue;
  }
  const result = compact(path.split(/[,[\].]+?/)).reduce((result2, key) => isNullOrUndefined(result2) ? result2 : result2[key], object);
  return isUndefined(result) || result === object ? isUndefined(object[path]) ? defaultValue : object[path] : result;
};
var isBoolean = (value) => typeof value === "boolean";
const EVENTS = {
  BLUR: "blur",
  FOCUS_OUT: "focusout",
  CHANGE: "change"
};
const VALIDATION_MODE = {
  onBlur: "onBlur",
  onChange: "onChange",
  onSubmit: "onSubmit",
  onTouched: "onTouched",
  all: "all"
};
const INPUT_VALIDATION_RULES = {
  max: "max",
  min: "min",
  maxLength: "maxLength",
  minLength: "minLength",
  pattern: "pattern",
  required: "required",
  validate: "validate"
};
const HookFormContext = React__namespace.default.createContext(null);
const useFormContext = () => React__namespace.default.useContext(HookFormContext);
const FormProvider = (props) => {
  const { children, ...data } = props;
  return React__namespace.default.createElement(HookFormContext.Provider, { value: data }, children);
};
var getProxyFormState = (formState, control, localProxyFormState, isRoot = true) => {
  const result = {
    defaultValues: control._defaultValues
  };
  for (const key in formState) {
    Object.defineProperty(result, key, {
      get: () => {
        const _key = key;
        if (control._proxyFormState[_key] !== VALIDATION_MODE.all) {
          control._proxyFormState[_key] = !isRoot || VALIDATION_MODE.all;
        }
        localProxyFormState && (localProxyFormState[_key] = true);
        return formState[_key];
      }
    });
  }
  return result;
};
var isEmptyObject = (value) => isObject(value) && !Object.keys(value).length;
var shouldRenderFormState = (formStateData, _proxyFormState, updateFormState, isRoot) => {
  updateFormState(formStateData);
  const { name, ...formState } = formStateData;
  return isEmptyObject(formState) || Object.keys(formState).length >= Object.keys(_proxyFormState).length || Object.keys(formState).find((key) => _proxyFormState[key] === (!isRoot || VALIDATION_MODE.all));
};
var convertToArrayPayload = (value) => Array.isArray(value) ? value : [value];
var shouldSubscribeByName = (name, signalName, exact) => !name || !signalName || name === signalName || convertToArrayPayload(name).some((currentName) => currentName && (exact ? currentName === signalName : currentName.startsWith(signalName) || signalName.startsWith(currentName)));
function useSubscribe(props) {
  const _props = React__namespace.default.useRef(props);
  _props.current = props;
  React__namespace.default.useEffect(() => {
    const subscription = !props.disabled && _props.current.subject && _props.current.subject.subscribe({
      next: _props.current.next
    });
    return () => {
      subscription && subscription.unsubscribe();
    };
  }, [props.disabled]);
}
function useFormState(props) {
  const methods = useFormContext();
  const { control = methods.control, disabled, name, exact } = props || {};
  const [formState, updateFormState] = React__namespace.default.useState(control._formState);
  const _mounted = React__namespace.default.useRef(true);
  const _localProxyFormState = React__namespace.default.useRef({
    isDirty: false,
    isLoading: false,
    dirtyFields: false,
    touchedFields: false,
    isValidating: false,
    isValid: false,
    errors: false
  });
  const _name = React__namespace.default.useRef(name);
  _name.current = name;
  useSubscribe({
    disabled,
    next: (value) => _mounted.current && shouldSubscribeByName(_name.current, value.name, exact) && shouldRenderFormState(value, _localProxyFormState.current, control._updateFormState) && updateFormState({
      ...control._formState,
      ...value
    }),
    subject: control._subjects.state
  });
  React__namespace.default.useEffect(() => {
    _mounted.current = true;
    _localProxyFormState.current.isValid && control._updateValid(true);
    return () => {
      _mounted.current = false;
    };
  }, [control]);
  return getProxyFormState(formState, control, _localProxyFormState.current, false);
}
var isString = (value) => typeof value === "string";
var generateWatchOutput = (names, _names, formValues, isGlobal, defaultValue) => {
  if (isString(names)) {
    isGlobal && _names.watch.add(names);
    return get(formValues, names, defaultValue);
  }
  if (Array.isArray(names)) {
    return names.map((fieldName) => (isGlobal && _names.watch.add(fieldName), get(formValues, fieldName)));
  }
  isGlobal && (_names.watchAll = true);
  return formValues;
};
function useWatch(props) {
  const methods = useFormContext();
  const { control = methods.control, name, defaultValue, disabled, exact } = props || {};
  const _name = React__namespace.default.useRef(name);
  _name.current = name;
  useSubscribe({
    disabled,
    subject: control._subjects.values,
    next: (formState) => {
      if (shouldSubscribeByName(_name.current, formState.name, exact)) {
        updateValue(cloneObject(generateWatchOutput(_name.current, control._names, formState.values || control._formValues, false, defaultValue)));
      }
    }
  });
  const [value, updateValue] = React__namespace.default.useState(control._getWatch(name, defaultValue));
  React__namespace.default.useEffect(() => control._removeUnmounted());
  return value;
}
var isKey = (value) => /^\w*$/.test(value);
var stringToPath = (input) => compact(input.replace(/["|']|\]/g, "").split(/\.|\[/));
var set = (object, path, value) => {
  let index = -1;
  const tempPath = isKey(path) ? [path] : stringToPath(path);
  const length = tempPath.length;
  const lastIndex = length - 1;
  while (++index < length) {
    const key = tempPath[index];
    let newValue = value;
    if (index !== lastIndex) {
      const objValue = object[key];
      newValue = isObject(objValue) || Array.isArray(objValue) ? objValue : !isNaN(+tempPath[index + 1]) ? [] : {};
    }
    object[key] = newValue;
    object = object[key];
  }
  return object;
};
function useController(props) {
  const methods = useFormContext();
  const { name, disabled, control = methods.control, shouldUnregister } = props;
  const isArrayField = isNameInFieldArray(control._names.array, name);
  const value = useWatch({
    control,
    name,
    defaultValue: get(control._formValues, name, get(control._defaultValues, name, props.defaultValue)),
    exact: true
  });
  const formState = useFormState({
    control,
    name
  });
  const _registerProps = React__namespace.default.useRef(control.register(name, {
    ...props.rules,
    value,
    ...isBoolean(props.disabled) ? { disabled: props.disabled } : {}
  }));
  React__namespace.default.useEffect(() => {
    const _shouldUnregisterField = control._options.shouldUnregister || shouldUnregister;
    const updateMounted = (name2, value2) => {
      const field = get(control._fields, name2);
      if (field) {
        field._f.mount = value2;
      }
    };
    updateMounted(name, true);
    if (_shouldUnregisterField) {
      const value2 = cloneObject(get(control._options.defaultValues, name));
      set(control._defaultValues, name, value2);
      if (isUndefined(get(control._formValues, name))) {
        set(control._formValues, name, value2);
      }
    }
    return () => {
      (isArrayField ? _shouldUnregisterField && !control._state.action : _shouldUnregisterField) ? control.unregister(name) : updateMounted(name, false);
    };
  }, [name, control, isArrayField, shouldUnregister]);
  React__namespace.default.useEffect(() => {
    if (get(control._fields, name)) {
      control._updateDisabledField({
        disabled,
        fields: control._fields,
        name,
        value: get(control._fields, name)._f.value
      });
    }
  }, [disabled, name, control]);
  return {
    field: {
      name,
      value,
      ...isBoolean(disabled) || isBoolean(formState.disabled) ? { disabled: formState.disabled || disabled } : {},
      onChange: React__namespace.default.useCallback((event) => _registerProps.current.onChange({
        target: {
          value: getEventValue(event),
          name
        },
        type: EVENTS.CHANGE
      }), [name]),
      onBlur: React__namespace.default.useCallback(() => _registerProps.current.onBlur({
        target: {
          value: get(control._formValues, name),
          name
        },
        type: EVENTS.BLUR
      }), [name, control]),
      ref: (elm) => {
        const field = get(control._fields, name);
        if (field && elm) {
          field._f.ref = {
            focus: () => elm.focus(),
            select: () => elm.select(),
            setCustomValidity: (message2) => elm.setCustomValidity(message2),
            reportValidity: () => elm.reportValidity()
          };
        }
      }
    },
    formState,
    fieldState: Object.defineProperties({}, {
      invalid: {
        enumerable: true,
        get: () => !!get(formState.errors, name)
      },
      isDirty: {
        enumerable: true,
        get: () => !!get(formState.dirtyFields, name)
      },
      isTouched: {
        enumerable: true,
        get: () => !!get(formState.touchedFields, name)
      },
      error: {
        enumerable: true,
        get: () => get(formState.errors, name)
      }
    })
  };
}
const Controller = (props) => props.render(useController(props));
var appendErrors = (name, validateAllFieldCriteria, errors, type, message2) => validateAllFieldCriteria ? {
  ...errors[name],
  types: {
    ...errors[name] && errors[name].types ? errors[name].types : {},
    [type]: message2 || true
  }
} : {};
var getValidationModes = (mode) => ({
  isOnSubmit: !mode || mode === VALIDATION_MODE.onSubmit,
  isOnBlur: mode === VALIDATION_MODE.onBlur,
  isOnChange: mode === VALIDATION_MODE.onChange,
  isOnAll: mode === VALIDATION_MODE.all,
  isOnTouch: mode === VALIDATION_MODE.onTouched
});
var isWatched = (name, _names, isBlurEvent) => !isBlurEvent && (_names.watchAll || _names.watch.has(name) || [..._names.watch].some((watchName) => name.startsWith(watchName) && /^\.\w+/.test(name.slice(watchName.length))));
const iterateFieldsByAction = (fields, action, fieldsNames, abortEarly) => {
  for (const key of fieldsNames || Object.keys(fields)) {
    const field = get(fields, key);
    if (field) {
      const { _f, ...currentField } = field;
      if (_f) {
        if (_f.refs && _f.refs[0] && action(_f.refs[0], key) && !abortEarly) {
          break;
        } else if (_f.ref && action(_f.ref, _f.name) && !abortEarly) {
          break;
        } else {
          iterateFieldsByAction(currentField, action);
        }
      } else if (isObject(currentField)) {
        iterateFieldsByAction(currentField, action);
      }
    }
  }
};
var updateFieldArrayRootError = (errors, error, name) => {
  const fieldArrayErrors = compact(get(errors, name));
  set(fieldArrayErrors, "root", error[name]);
  set(errors, name, fieldArrayErrors);
  return errors;
};
var isFileInput = (element) => element.type === "file";
var isFunction = (value) => typeof value === "function";
var isHTMLElement = (value) => {
  if (!isWeb) {
    return false;
  }
  const owner = value ? value.ownerDocument : 0;
  return value instanceof (owner && owner.defaultView ? owner.defaultView.HTMLElement : HTMLElement);
};
var isMessage = (value) => isString(value);
var isRadioInput = (element) => element.type === "radio";
var isRegex = (value) => value instanceof RegExp;
const defaultResult = {
  value: false,
  isValid: false
};
const validResult = { value: true, isValid: true };
var getCheckboxValue = (options) => {
  if (Array.isArray(options)) {
    if (options.length > 1) {
      const values2 = options.filter((option) => option && option.checked && !option.disabled).map((option) => option.value);
      return { value: values2, isValid: !!values2.length };
    }
    return options[0].checked && !options[0].disabled ? (
      // @ts-expect-error expected to work in the browser
      options[0].attributes && !isUndefined(options[0].attributes.value) ? isUndefined(options[0].value) || options[0].value === "" ? validResult : { value: options[0].value, isValid: true } : validResult
    ) : defaultResult;
  }
  return defaultResult;
};
const defaultReturn = {
  isValid: false,
  value: null
};
var getRadioValue = (options) => Array.isArray(options) ? options.reduce((previous, option) => option && option.checked && !option.disabled ? {
  isValid: true,
  value: option.value
} : previous, defaultReturn) : defaultReturn;
function getValidateError(result, ref, type = "validate") {
  if (isMessage(result) || Array.isArray(result) && result.every(isMessage) || isBoolean(result) && !result) {
    return {
      type,
      message: isMessage(result) ? result : "",
      ref
    };
  }
}
var getValueAndMessage = (validationData) => isObject(validationData) && !isRegex(validationData) ? validationData : {
  value: validationData,
  message: ""
};
var validateField = async (field, formValues, validateAllFieldCriteria, shouldUseNativeValidation, isFieldArray) => {
  const { ref, refs, required, maxLength, minLength, min, max, pattern, validate, name, valueAsNumber, mount, disabled } = field._f;
  const inputValue = get(formValues, name);
  if (!mount || disabled) {
    return {};
  }
  const inputRef = refs ? refs[0] : ref;
  const setCustomValidity = (message2) => {
    if (shouldUseNativeValidation && inputRef.reportValidity) {
      inputRef.setCustomValidity(isBoolean(message2) ? "" : message2 || "");
      inputRef.reportValidity();
    }
  };
  const error = {};
  const isRadio = isRadioInput(ref);
  const isCheckBox = isCheckBoxInput(ref);
  const isRadioOrCheckbox2 = isRadio || isCheckBox;
  const isEmpty = (valueAsNumber || isFileInput(ref)) && isUndefined(ref.value) && isUndefined(inputValue) || isHTMLElement(ref) && ref.value === "" || inputValue === "" || Array.isArray(inputValue) && !inputValue.length;
  const appendErrorsCurry = appendErrors.bind(null, name, validateAllFieldCriteria, error);
  const getMinMaxMessage = (exceedMax, maxLengthMessage, minLengthMessage, maxType = INPUT_VALIDATION_RULES.maxLength, minType = INPUT_VALIDATION_RULES.minLength) => {
    const message2 = exceedMax ? maxLengthMessage : minLengthMessage;
    error[name] = {
      type: exceedMax ? maxType : minType,
      message: message2,
      ref,
      ...appendErrorsCurry(exceedMax ? maxType : minType, message2)
    };
  };
  if (isFieldArray ? !Array.isArray(inputValue) || !inputValue.length : required && (!isRadioOrCheckbox2 && (isEmpty || isNullOrUndefined(inputValue)) || isBoolean(inputValue) && !inputValue || isCheckBox && !getCheckboxValue(refs).isValid || isRadio && !getRadioValue(refs).isValid)) {
    const { value, message: message2 } = isMessage(required) ? { value: !!required, message: required } : getValueAndMessage(required);
    if (value) {
      error[name] = {
        type: INPUT_VALIDATION_RULES.required,
        message: message2,
        ref: inputRef,
        ...appendErrorsCurry(INPUT_VALIDATION_RULES.required, message2)
      };
      if (!validateAllFieldCriteria) {
        setCustomValidity(message2);
        return error;
      }
    }
  }
  if (!isEmpty && (!isNullOrUndefined(min) || !isNullOrUndefined(max))) {
    let exceedMax;
    let exceedMin;
    const maxOutput = getValueAndMessage(max);
    const minOutput = getValueAndMessage(min);
    if (!isNullOrUndefined(inputValue) && !isNaN(inputValue)) {
      const valueNumber = ref.valueAsNumber || (inputValue ? +inputValue : inputValue);
      if (!isNullOrUndefined(maxOutput.value)) {
        exceedMax = valueNumber > maxOutput.value;
      }
      if (!isNullOrUndefined(minOutput.value)) {
        exceedMin = valueNumber < minOutput.value;
      }
    } else {
      const valueDate = ref.valueAsDate || new Date(inputValue);
      const convertTimeToDate = (time) => /* @__PURE__ */ new Date((/* @__PURE__ */ new Date()).toDateString() + " " + time);
      const isTime = ref.type == "time";
      const isWeek = ref.type == "week";
      if (isString(maxOutput.value) && inputValue) {
        exceedMax = isTime ? convertTimeToDate(inputValue) > convertTimeToDate(maxOutput.value) : isWeek ? inputValue > maxOutput.value : valueDate > new Date(maxOutput.value);
      }
      if (isString(minOutput.value) && inputValue) {
        exceedMin = isTime ? convertTimeToDate(inputValue) < convertTimeToDate(minOutput.value) : isWeek ? inputValue < minOutput.value : valueDate < new Date(minOutput.value);
      }
    }
    if (exceedMax || exceedMin) {
      getMinMaxMessage(!!exceedMax, maxOutput.message, minOutput.message, INPUT_VALIDATION_RULES.max, INPUT_VALIDATION_RULES.min);
      if (!validateAllFieldCriteria) {
        setCustomValidity(error[name].message);
        return error;
      }
    }
  }
  if ((maxLength || minLength) && !isEmpty && (isString(inputValue) || isFieldArray && Array.isArray(inputValue))) {
    const maxLengthOutput = getValueAndMessage(maxLength);
    const minLengthOutput = getValueAndMessage(minLength);
    const exceedMax = !isNullOrUndefined(maxLengthOutput.value) && inputValue.length > +maxLengthOutput.value;
    const exceedMin = !isNullOrUndefined(minLengthOutput.value) && inputValue.length < +minLengthOutput.value;
    if (exceedMax || exceedMin) {
      getMinMaxMessage(exceedMax, maxLengthOutput.message, minLengthOutput.message);
      if (!validateAllFieldCriteria) {
        setCustomValidity(error[name].message);
        return error;
      }
    }
  }
  if (pattern && !isEmpty && isString(inputValue)) {
    const { value: patternValue, message: message2 } = getValueAndMessage(pattern);
    if (isRegex(patternValue) && !inputValue.match(patternValue)) {
      error[name] = {
        type: INPUT_VALIDATION_RULES.pattern,
        message: message2,
        ref,
        ...appendErrorsCurry(INPUT_VALIDATION_RULES.pattern, message2)
      };
      if (!validateAllFieldCriteria) {
        setCustomValidity(message2);
        return error;
      }
    }
  }
  if (validate) {
    if (isFunction(validate)) {
      const result = await validate(inputValue, formValues);
      const validateError = getValidateError(result, inputRef);
      if (validateError) {
        error[name] = {
          ...validateError,
          ...appendErrorsCurry(INPUT_VALIDATION_RULES.validate, validateError.message)
        };
        if (!validateAllFieldCriteria) {
          setCustomValidity(validateError.message);
          return error;
        }
      }
    } else if (isObject(validate)) {
      let validationResult = {};
      for (const key in validate) {
        if (!isEmptyObject(validationResult) && !validateAllFieldCriteria) {
          break;
        }
        const validateError = getValidateError(await validate[key](inputValue, formValues), inputRef, key);
        if (validateError) {
          validationResult = {
            ...validateError,
            ...appendErrorsCurry(key, validateError.message)
          };
          setCustomValidity(validateError.message);
          if (validateAllFieldCriteria) {
            error[name] = validationResult;
          }
        }
      }
      if (!isEmptyObject(validationResult)) {
        error[name] = {
          ref: inputRef,
          ...validationResult
        };
        if (!validateAllFieldCriteria) {
          return error;
        }
      }
    }
  }
  setCustomValidity(true);
  return error;
};
function baseGet(object, updatePath) {
  const length = updatePath.slice(0, -1).length;
  let index = 0;
  while (index < length) {
    object = isUndefined(object) ? index++ : object[updatePath[index++]];
  }
  return object;
}
function isEmptyArray(obj) {
  for (const key in obj) {
    if (obj.hasOwnProperty(key) && !isUndefined(obj[key])) {
      return false;
    }
  }
  return true;
}
function unset(object, path) {
  const paths = Array.isArray(path) ? path : isKey(path) ? [path] : stringToPath(path);
  const childObject = paths.length === 1 ? object : baseGet(object, paths);
  const index = paths.length - 1;
  const key = paths[index];
  if (childObject) {
    delete childObject[key];
  }
  if (index !== 0 && (isObject(childObject) && isEmptyObject(childObject) || Array.isArray(childObject) && isEmptyArray(childObject))) {
    unset(object, paths.slice(0, -1));
  }
  return object;
}
var createSubject = () => {
  let _observers = [];
  const next = (value) => {
    for (const observer of _observers) {
      observer.next && observer.next(value);
    }
  };
  const subscribe = (observer) => {
    _observers.push(observer);
    return {
      unsubscribe: () => {
        _observers = _observers.filter((o) => o !== observer);
      }
    };
  };
  const unsubscribe = () => {
    _observers = [];
  };
  return {
    get observers() {
      return _observers;
    },
    next,
    subscribe,
    unsubscribe
  };
};
var isPrimitive = (value) => isNullOrUndefined(value) || !isObjectType(value);
function deepEqual(object1, object2) {
  if (isPrimitive(object1) || isPrimitive(object2)) {
    return object1 === object2;
  }
  if (isDateObject(object1) && isDateObject(object2)) {
    return object1.getTime() === object2.getTime();
  }
  const keys1 = Object.keys(object1);
  const keys2 = Object.keys(object2);
  if (keys1.length !== keys2.length) {
    return false;
  }
  for (const key of keys1) {
    const val1 = object1[key];
    if (!keys2.includes(key)) {
      return false;
    }
    if (key !== "ref") {
      const val2 = object2[key];
      if (isDateObject(val1) && isDateObject(val2) || isObject(val1) && isObject(val2) || Array.isArray(val1) && Array.isArray(val2) ? !deepEqual(val1, val2) : val1 !== val2) {
        return false;
      }
    }
  }
  return true;
}
var isMultipleSelect = (element) => element.type === `select-multiple`;
var isRadioOrCheckbox = (ref) => isRadioInput(ref) || isCheckBoxInput(ref);
var live = (ref) => isHTMLElement(ref) && ref.isConnected;
var objectHasFunction = (data) => {
  for (const key in data) {
    if (isFunction(data[key])) {
      return true;
    }
  }
  return false;
};
function markFieldsDirty(data, fields = {}) {
  const isParentNodeArray = Array.isArray(data);
  if (isObject(data) || isParentNodeArray) {
    for (const key in data) {
      if (Array.isArray(data[key]) || isObject(data[key]) && !objectHasFunction(data[key])) {
        fields[key] = Array.isArray(data[key]) ? [] : {};
        markFieldsDirty(data[key], fields[key]);
      } else if (!isNullOrUndefined(data[key])) {
        fields[key] = true;
      }
    }
  }
  return fields;
}
function getDirtyFieldsFromDefaultValues(data, formValues, dirtyFieldsFromValues) {
  const isParentNodeArray = Array.isArray(data);
  if (isObject(data) || isParentNodeArray) {
    for (const key in data) {
      if (Array.isArray(data[key]) || isObject(data[key]) && !objectHasFunction(data[key])) {
        if (isUndefined(formValues) || isPrimitive(dirtyFieldsFromValues[key])) {
          dirtyFieldsFromValues[key] = Array.isArray(data[key]) ? markFieldsDirty(data[key], []) : { ...markFieldsDirty(data[key]) };
        } else {
          getDirtyFieldsFromDefaultValues(data[key], isNullOrUndefined(formValues) ? {} : formValues[key], dirtyFieldsFromValues[key]);
        }
      } else {
        dirtyFieldsFromValues[key] = !deepEqual(data[key], formValues[key]);
      }
    }
  }
  return dirtyFieldsFromValues;
}
var getDirtyFields = (defaultValues, formValues) => getDirtyFieldsFromDefaultValues(defaultValues, formValues, markFieldsDirty(formValues));
var getFieldValueAs = (value, { valueAsNumber, valueAsDate, setValueAs }) => isUndefined(value) ? value : valueAsNumber ? value === "" ? NaN : value ? +value : value : valueAsDate && isString(value) ? new Date(value) : setValueAs ? setValueAs(value) : value;
function getFieldValue(_f) {
  const ref = _f.ref;
  if (_f.refs ? _f.refs.every((ref2) => ref2.disabled) : ref.disabled) {
    return;
  }
  if (isFileInput(ref)) {
    return ref.files;
  }
  if (isRadioInput(ref)) {
    return getRadioValue(_f.refs).value;
  }
  if (isMultipleSelect(ref)) {
    return [...ref.selectedOptions].map(({ value }) => value);
  }
  if (isCheckBoxInput(ref)) {
    return getCheckboxValue(_f.refs).value;
  }
  return getFieldValueAs(isUndefined(ref.value) ? _f.ref.value : ref.value, _f);
}
var getResolverOptions = (fieldsNames, _fields, criteriaMode, shouldUseNativeValidation) => {
  const fields = {};
  for (const name of fieldsNames) {
    const field = get(_fields, name);
    field && set(fields, name, field._f);
  }
  return {
    criteriaMode,
    names: [...fieldsNames],
    fields,
    shouldUseNativeValidation
  };
};
var getRuleValue = (rule) => isUndefined(rule) ? rule : isRegex(rule) ? rule.source : isObject(rule) ? isRegex(rule.value) ? rule.value.source : rule.value : rule;
var hasValidation = (options) => options.mount && (options.required || options.min || options.max || options.maxLength || options.minLength || options.pattern || options.validate);
function schemaErrorLookup(errors, _fields, name) {
  const error = get(errors, name);
  if (error || isKey(name)) {
    return {
      error,
      name
    };
  }
  const names = name.split(".");
  while (names.length) {
    const fieldName = names.join(".");
    const field = get(_fields, fieldName);
    const foundError = get(errors, fieldName);
    if (field && !Array.isArray(field) && name !== fieldName) {
      return { name };
    }
    if (foundError && foundError.type) {
      return {
        name: fieldName,
        error: foundError
      };
    }
    names.pop();
  }
  return {
    name
  };
}
var skipValidation = (isBlurEvent, isTouched, isSubmitted, reValidateMode, mode) => {
  if (mode.isOnAll) {
    return false;
  } else if (!isSubmitted && mode.isOnTouch) {
    return !(isTouched || isBlurEvent);
  } else if (isSubmitted ? reValidateMode.isOnBlur : mode.isOnBlur) {
    return !isBlurEvent;
  } else if (isSubmitted ? reValidateMode.isOnChange : mode.isOnChange) {
    return isBlurEvent;
  }
  return true;
};
var unsetEmptyArray = (ref, name) => !compact(get(ref, name)).length && unset(ref, name);
const defaultOptions = {
  mode: VALIDATION_MODE.onSubmit,
  reValidateMode: VALIDATION_MODE.onChange,
  shouldFocusError: true
};
function createFormControl(props = {}, flushRootRender) {
  let _options = {
    ...defaultOptions,
    ...props
  };
  let _formState = {
    submitCount: 0,
    isDirty: false,
    isLoading: isFunction(_options.defaultValues),
    isValidating: false,
    isSubmitted: false,
    isSubmitting: false,
    isSubmitSuccessful: false,
    isValid: false,
    touchedFields: {},
    dirtyFields: {},
    errors: _options.errors || {},
    disabled: false
  };
  let _fields = {};
  let _defaultValues = isObject(_options.defaultValues) || isObject(_options.values) ? cloneObject(_options.defaultValues || _options.values) || {} : {};
  let _formValues = _options.shouldUnregister ? {} : cloneObject(_defaultValues);
  let _state = {
    action: false,
    mount: false,
    watch: false
  };
  let _names = {
    mount: /* @__PURE__ */ new Set(),
    unMount: /* @__PURE__ */ new Set(),
    array: /* @__PURE__ */ new Set(),
    watch: /* @__PURE__ */ new Set()
  };
  let delayErrorCallback;
  let timer = 0;
  const _proxyFormState = {
    isDirty: false,
    dirtyFields: false,
    touchedFields: false,
    isValidating: false,
    isValid: false,
    errors: false
  };
  const _subjects = {
    values: createSubject(),
    array: createSubject(),
    state: createSubject()
  };
  const shouldCaptureDirtyFields = props.resetOptions && props.resetOptions.keepDirtyValues;
  const validationModeBeforeSubmit = getValidationModes(_options.mode);
  const validationModeAfterSubmit = getValidationModes(_options.reValidateMode);
  const shouldDisplayAllAssociatedErrors = _options.criteriaMode === VALIDATION_MODE.all;
  const debounce = (callback) => (wait) => {
    clearTimeout(timer);
    timer = setTimeout(callback, wait);
  };
  const _updateValid = async (shouldUpdateValid) => {
    if (_proxyFormState.isValid || shouldUpdateValid) {
      const isValid2 = _options.resolver ? isEmptyObject((await _executeSchema()).errors) : await executeBuiltInValidation(_fields, true);
      if (isValid2 !== _formState.isValid) {
        _subjects.state.next({
          isValid: isValid2
        });
      }
    }
  };
  const _updateIsValidating = (value) => _proxyFormState.isValidating && _subjects.state.next({
    isValidating: value
  });
  const _updateFieldArray = (name, values2 = [], method, args, shouldSetValues = true, shouldUpdateFieldsAndState = true) => {
    if (args && method) {
      _state.action = true;
      if (shouldUpdateFieldsAndState && Array.isArray(get(_fields, name))) {
        const fieldValues = method(get(_fields, name), args.argA, args.argB);
        shouldSetValues && set(_fields, name, fieldValues);
      }
      if (shouldUpdateFieldsAndState && Array.isArray(get(_formState.errors, name))) {
        const errors = method(get(_formState.errors, name), args.argA, args.argB);
        shouldSetValues && set(_formState.errors, name, errors);
        unsetEmptyArray(_formState.errors, name);
      }
      if (_proxyFormState.touchedFields && shouldUpdateFieldsAndState && Array.isArray(get(_formState.touchedFields, name))) {
        const touchedFields = method(get(_formState.touchedFields, name), args.argA, args.argB);
        shouldSetValues && set(_formState.touchedFields, name, touchedFields);
      }
      if (_proxyFormState.dirtyFields) {
        _formState.dirtyFields = getDirtyFields(_defaultValues, _formValues);
      }
      _subjects.state.next({
        name,
        isDirty: _getDirty(name, values2),
        dirtyFields: _formState.dirtyFields,
        errors: _formState.errors,
        isValid: _formState.isValid
      });
    } else {
      set(_formValues, name, values2);
    }
  };
  const updateErrors = (name, error) => {
    set(_formState.errors, name, error);
    _subjects.state.next({
      errors: _formState.errors
    });
  };
  const _setErrors = (errors) => {
    _formState.errors = errors;
    _subjects.state.next({
      errors: _formState.errors,
      isValid: false
    });
  };
  const updateValidAndValue = (name, shouldSkipSetValueAs, value, ref) => {
    const field = get(_fields, name);
    if (field) {
      const defaultValue = get(_formValues, name, isUndefined(value) ? get(_defaultValues, name) : value);
      isUndefined(defaultValue) || ref && ref.defaultChecked || shouldSkipSetValueAs ? set(_formValues, name, shouldSkipSetValueAs ? defaultValue : getFieldValue(field._f)) : setFieldValue(name, defaultValue);
      _state.mount && _updateValid();
    }
  };
  const updateTouchAndDirty = (name, fieldValue, isBlurEvent, shouldDirty, shouldRender) => {
    let shouldUpdateField = false;
    let isPreviousDirty = false;
    const output = {
      name
    };
    const disabledField = get(_fields, name) && get(_fields, name)._f.disabled;
    if (!isBlurEvent || shouldDirty) {
      if (_proxyFormState.isDirty) {
        isPreviousDirty = _formState.isDirty;
        _formState.isDirty = output.isDirty = _getDirty();
        shouldUpdateField = isPreviousDirty !== output.isDirty;
      }
      const isCurrentFieldPristine = disabledField || deepEqual(get(_defaultValues, name), fieldValue);
      isPreviousDirty = !disabledField && get(_formState.dirtyFields, name);
      isCurrentFieldPristine || disabledField ? unset(_formState.dirtyFields, name) : set(_formState.dirtyFields, name, true);
      output.dirtyFields = _formState.dirtyFields;
      shouldUpdateField = shouldUpdateField || _proxyFormState.dirtyFields && isPreviousDirty !== !isCurrentFieldPristine;
    }
    if (isBlurEvent) {
      const isPreviousFieldTouched = get(_formState.touchedFields, name);
      if (!isPreviousFieldTouched) {
        set(_formState.touchedFields, name, isBlurEvent);
        output.touchedFields = _formState.touchedFields;
        shouldUpdateField = shouldUpdateField || _proxyFormState.touchedFields && isPreviousFieldTouched !== isBlurEvent;
      }
    }
    shouldUpdateField && shouldRender && _subjects.state.next(output);
    return shouldUpdateField ? output : {};
  };
  const shouldRenderByError = (name, isValid2, error, fieldState) => {
    const previousFieldError = get(_formState.errors, name);
    const shouldUpdateValid = _proxyFormState.isValid && isBoolean(isValid2) && _formState.isValid !== isValid2;
    if (props.delayError && error) {
      delayErrorCallback = debounce(() => updateErrors(name, error));
      delayErrorCallback(props.delayError);
    } else {
      clearTimeout(timer);
      delayErrorCallback = null;
      error ? set(_formState.errors, name, error) : unset(_formState.errors, name);
    }
    if ((error ? !deepEqual(previousFieldError, error) : previousFieldError) || !isEmptyObject(fieldState) || shouldUpdateValid) {
      const updatedFormState = {
        ...fieldState,
        ...shouldUpdateValid && isBoolean(isValid2) ? { isValid: isValid2 } : {},
        errors: _formState.errors,
        name
      };
      _formState = {
        ..._formState,
        ...updatedFormState
      };
      _subjects.state.next(updatedFormState);
    }
    _updateIsValidating(false);
  };
  const _executeSchema = async (name) => _options.resolver(_formValues, _options.context, getResolverOptions(name || _names.mount, _fields, _options.criteriaMode, _options.shouldUseNativeValidation));
  const executeSchemaAndUpdateState = async (names) => {
    const { errors } = await _executeSchema(names);
    if (names) {
      for (const name of names) {
        const error = get(errors, name);
        error ? set(_formState.errors, name, error) : unset(_formState.errors, name);
      }
    } else {
      _formState.errors = errors;
    }
    return errors;
  };
  const executeBuiltInValidation = async (fields, shouldOnlyCheckValid, context = {
    valid: true
  }) => {
    for (const name in fields) {
      const field = fields[name];
      if (field) {
        const { _f, ...fieldValue } = field;
        if (_f) {
          const isFieldArrayRoot = _names.array.has(_f.name);
          const fieldError = await validateField(field, _formValues, shouldDisplayAllAssociatedErrors, _options.shouldUseNativeValidation && !shouldOnlyCheckValid, isFieldArrayRoot);
          if (fieldError[_f.name]) {
            context.valid = false;
            if (shouldOnlyCheckValid) {
              break;
            }
          }
          !shouldOnlyCheckValid && (get(fieldError, _f.name) ? isFieldArrayRoot ? updateFieldArrayRootError(_formState.errors, fieldError, _f.name) : set(_formState.errors, _f.name, fieldError[_f.name]) : unset(_formState.errors, _f.name));
        }
        fieldValue && await executeBuiltInValidation(fieldValue, shouldOnlyCheckValid, context);
      }
    }
    return context.valid;
  };
  const _removeUnmounted = () => {
    for (const name of _names.unMount) {
      const field = get(_fields, name);
      field && (field._f.refs ? field._f.refs.every((ref) => !live(ref)) : !live(field._f.ref)) && unregister(name);
    }
    _names.unMount = /* @__PURE__ */ new Set();
  };
  const _getDirty = (name, data) => (name && data && set(_formValues, name, data), !deepEqual(getValues(), _defaultValues));
  const _getWatch = (names, defaultValue, isGlobal) => generateWatchOutput(names, _names, {
    ..._state.mount ? _formValues : isUndefined(defaultValue) ? _defaultValues : isString(names) ? { [names]: defaultValue } : defaultValue
  }, isGlobal, defaultValue);
  const _getFieldArray = (name) => compact(get(_state.mount ? _formValues : _defaultValues, name, props.shouldUnregister ? get(_defaultValues, name, []) : []));
  const setFieldValue = (name, value, options = {}) => {
    const field = get(_fields, name);
    let fieldValue = value;
    if (field) {
      const fieldReference = field._f;
      if (fieldReference) {
        !fieldReference.disabled && set(_formValues, name, getFieldValueAs(value, fieldReference));
        fieldValue = isHTMLElement(fieldReference.ref) && isNullOrUndefined(value) ? "" : value;
        if (isMultipleSelect(fieldReference.ref)) {
          [...fieldReference.ref.options].forEach((optionRef) => optionRef.selected = fieldValue.includes(optionRef.value));
        } else if (fieldReference.refs) {
          if (isCheckBoxInput(fieldReference.ref)) {
            fieldReference.refs.length > 1 ? fieldReference.refs.forEach((checkboxRef) => (!checkboxRef.defaultChecked || !checkboxRef.disabled) && (checkboxRef.checked = Array.isArray(fieldValue) ? !!fieldValue.find((data) => data === checkboxRef.value) : fieldValue === checkboxRef.value)) : fieldReference.refs[0] && (fieldReference.refs[0].checked = !!fieldValue);
          } else {
            fieldReference.refs.forEach((radioRef) => radioRef.checked = radioRef.value === fieldValue);
          }
        } else if (isFileInput(fieldReference.ref)) {
          fieldReference.ref.value = "";
        } else {
          fieldReference.ref.value = fieldValue;
          if (!fieldReference.ref.type) {
            _subjects.values.next({
              name,
              values: { ..._formValues }
            });
          }
        }
      }
    }
    (options.shouldDirty || options.shouldTouch) && updateTouchAndDirty(name, fieldValue, options.shouldTouch, options.shouldDirty, true);
    options.shouldValidate && trigger(name);
  };
  const setValues = (name, value, options) => {
    for (const fieldKey in value) {
      const fieldValue = value[fieldKey];
      const fieldName = `${name}.${fieldKey}`;
      const field = get(_fields, fieldName);
      (_names.array.has(name) || !isPrimitive(fieldValue) || field && !field._f) && !isDateObject(fieldValue) ? setValues(fieldName, fieldValue, options) : setFieldValue(fieldName, fieldValue, options);
    }
  };
  const setValue = (name, value, options = {}) => {
    const field = get(_fields, name);
    const isFieldArray = _names.array.has(name);
    const cloneValue = cloneObject(value);
    set(_formValues, name, cloneValue);
    if (isFieldArray) {
      _subjects.array.next({
        name,
        values: { ..._formValues }
      });
      if ((_proxyFormState.isDirty || _proxyFormState.dirtyFields) && options.shouldDirty) {
        _subjects.state.next({
          name,
          dirtyFields: getDirtyFields(_defaultValues, _formValues),
          isDirty: _getDirty(name, cloneValue)
        });
      }
    } else {
      field && !field._f && !isNullOrUndefined(cloneValue) ? setValues(name, cloneValue, options) : setFieldValue(name, cloneValue, options);
    }
    isWatched(name, _names) && _subjects.state.next({ ..._formState });
    _subjects.values.next({
      name,
      values: { ..._formValues }
    });
    !_state.mount && flushRootRender();
  };
  const onChange = async (event) => {
    const target = event.target;
    let name = target.name;
    let isFieldValueUpdated = true;
    const field = get(_fields, name);
    const getCurrentFieldValue = () => target.type ? getFieldValue(field._f) : getEventValue(event);
    const _updateIsFieldValueUpdated = (fieldValue) => {
      isFieldValueUpdated = Number.isNaN(fieldValue) || fieldValue === get(_formValues, name, fieldValue);
    };
    if (field) {
      let error;
      let isValid2;
      const fieldValue = getCurrentFieldValue();
      const isBlurEvent = event.type === EVENTS.BLUR || event.type === EVENTS.FOCUS_OUT;
      const shouldSkipValidation = !hasValidation(field._f) && !_options.resolver && !get(_formState.errors, name) && !field._f.deps || skipValidation(isBlurEvent, get(_formState.touchedFields, name), _formState.isSubmitted, validationModeAfterSubmit, validationModeBeforeSubmit);
      const watched = isWatched(name, _names, isBlurEvent);
      set(_formValues, name, fieldValue);
      if (isBlurEvent) {
        field._f.onBlur && field._f.onBlur(event);
        delayErrorCallback && delayErrorCallback(0);
      } else if (field._f.onChange) {
        field._f.onChange(event);
      }
      const fieldState = updateTouchAndDirty(name, fieldValue, isBlurEvent, false);
      const shouldRender = !isEmptyObject(fieldState) || watched;
      !isBlurEvent && _subjects.values.next({
        name,
        type: event.type,
        values: { ..._formValues }
      });
      if (shouldSkipValidation) {
        _proxyFormState.isValid && _updateValid();
        return shouldRender && _subjects.state.next({ name, ...watched ? {} : fieldState });
      }
      !isBlurEvent && watched && _subjects.state.next({ ..._formState });
      _updateIsValidating(true);
      if (_options.resolver) {
        const { errors } = await _executeSchema([name]);
        _updateIsFieldValueUpdated(fieldValue);
        if (isFieldValueUpdated) {
          const previousErrorLookupResult = schemaErrorLookup(_formState.errors, _fields, name);
          const errorLookupResult = schemaErrorLookup(errors, _fields, previousErrorLookupResult.name || name);
          error = errorLookupResult.error;
          name = errorLookupResult.name;
          isValid2 = isEmptyObject(errors);
        }
      } else {
        error = (await validateField(field, _formValues, shouldDisplayAllAssociatedErrors, _options.shouldUseNativeValidation))[name];
        _updateIsFieldValueUpdated(fieldValue);
        if (isFieldValueUpdated) {
          if (error) {
            isValid2 = false;
          } else if (_proxyFormState.isValid) {
            isValid2 = await executeBuiltInValidation(_fields, true);
          }
        }
      }
      if (isFieldValueUpdated) {
        field._f.deps && trigger(field._f.deps);
        shouldRenderByError(name, isValid2, error, fieldState);
      }
    }
  };
  const _focusInput = (ref, key) => {
    if (get(_formState.errors, key) && ref.focus) {
      ref.focus();
      return 1;
    }
    return;
  };
  const trigger = async (name, options = {}) => {
    let isValid2;
    let validationResult;
    const fieldNames = convertToArrayPayload(name);
    _updateIsValidating(true);
    if (_options.resolver) {
      const errors = await executeSchemaAndUpdateState(isUndefined(name) ? name : fieldNames);
      isValid2 = isEmptyObject(errors);
      validationResult = name ? !fieldNames.some((name2) => get(errors, name2)) : isValid2;
    } else if (name) {
      validationResult = (await Promise.all(fieldNames.map(async (fieldName) => {
        const field = get(_fields, fieldName);
        return await executeBuiltInValidation(field && field._f ? { [fieldName]: field } : field);
      }))).every(Boolean);
      !(!validationResult && !_formState.isValid) && _updateValid();
    } else {
      validationResult = isValid2 = await executeBuiltInValidation(_fields);
    }
    _subjects.state.next({
      ...!isString(name) || _proxyFormState.isValid && isValid2 !== _formState.isValid ? {} : { name },
      ..._options.resolver || !name ? { isValid: isValid2 } : {},
      errors: _formState.errors,
      isValidating: false
    });
    options.shouldFocus && !validationResult && iterateFieldsByAction(_fields, _focusInput, name ? fieldNames : _names.mount);
    return validationResult;
  };
  const getValues = (fieldNames) => {
    const values2 = {
      ..._defaultValues,
      ..._state.mount ? _formValues : {}
    };
    return isUndefined(fieldNames) ? values2 : isString(fieldNames) ? get(values2, fieldNames) : fieldNames.map((name) => get(values2, name));
  };
  const getFieldState = (name, formState) => ({
    invalid: !!get((formState || _formState).errors, name),
    isDirty: !!get((formState || _formState).dirtyFields, name),
    isTouched: !!get((formState || _formState).touchedFields, name),
    error: get((formState || _formState).errors, name)
  });
  const clearErrors = (name) => {
    name && convertToArrayPayload(name).forEach((inputName) => unset(_formState.errors, inputName));
    _subjects.state.next({
      errors: name ? _formState.errors : {}
    });
  };
  const setError = (name, error, options) => {
    const ref = (get(_fields, name, { _f: {} })._f || {}).ref;
    set(_formState.errors, name, {
      ...error,
      ref
    });
    _subjects.state.next({
      name,
      errors: _formState.errors,
      isValid: false
    });
    options && options.shouldFocus && ref && ref.focus && ref.focus();
  };
  const watch = (name, defaultValue) => isFunction(name) ? _subjects.values.subscribe({
    next: (payload) => name(_getWatch(void 0, defaultValue), payload)
  }) : _getWatch(name, defaultValue, true);
  const unregister = (name, options = {}) => {
    for (const fieldName of name ? convertToArrayPayload(name) : _names.mount) {
      _names.mount.delete(fieldName);
      _names.array.delete(fieldName);
      if (!options.keepValue) {
        unset(_fields, fieldName);
        unset(_formValues, fieldName);
      }
      !options.keepError && unset(_formState.errors, fieldName);
      !options.keepDirty && unset(_formState.dirtyFields, fieldName);
      !options.keepTouched && unset(_formState.touchedFields, fieldName);
      !_options.shouldUnregister && !options.keepDefaultValue && unset(_defaultValues, fieldName);
    }
    _subjects.values.next({
      values: { ..._formValues }
    });
    _subjects.state.next({
      ..._formState,
      ...!options.keepDirty ? {} : { isDirty: _getDirty() }
    });
    !options.keepIsValid && _updateValid();
  };
  const _updateDisabledField = ({ disabled, name, field, fields, value }) => {
    if (isBoolean(disabled)) {
      const inputValue = disabled ? void 0 : isUndefined(value) ? getFieldValue(field ? field._f : get(fields, name)._f) : value;
      set(_formValues, name, inputValue);
      updateTouchAndDirty(name, inputValue, false, false, true);
    }
  };
  const register = (name, options = {}) => {
    let field = get(_fields, name);
    const disabledIsDefined = isBoolean(options.disabled);
    set(_fields, name, {
      ...field || {},
      _f: {
        ...field && field._f ? field._f : { ref: { name } },
        name,
        mount: true,
        ...options
      }
    });
    _names.mount.add(name);
    if (field) {
      _updateDisabledField({
        field,
        disabled: options.disabled,
        name
      });
    } else {
      updateValidAndValue(name, true, options.value);
    }
    return {
      ...disabledIsDefined ? { disabled: options.disabled } : {},
      ..._options.progressive ? {
        required: !!options.required,
        min: getRuleValue(options.min),
        max: getRuleValue(options.max),
        minLength: getRuleValue(options.minLength),
        maxLength: getRuleValue(options.maxLength),
        pattern: getRuleValue(options.pattern)
      } : {},
      name,
      onChange,
      onBlur: onChange,
      ref: (ref) => {
        if (ref) {
          register(name, options);
          field = get(_fields, name);
          const fieldRef = isUndefined(ref.value) ? ref.querySelectorAll ? ref.querySelectorAll("input,select,textarea")[0] || ref : ref : ref;
          const radioOrCheckbox = isRadioOrCheckbox(fieldRef);
          const refs = field._f.refs || [];
          if (radioOrCheckbox ? refs.find((option) => option === fieldRef) : fieldRef === field._f.ref) {
            return;
          }
          set(_fields, name, {
            _f: {
              ...field._f,
              ...radioOrCheckbox ? {
                refs: [
                  ...refs.filter(live),
                  fieldRef,
                  ...Array.isArray(get(_defaultValues, name)) ? [{}] : []
                ],
                ref: { type: fieldRef.type, name }
              } : { ref: fieldRef }
            }
          });
          updateValidAndValue(name, false, void 0, fieldRef);
        } else {
          field = get(_fields, name, {});
          if (field._f) {
            field._f.mount = false;
          }
          (_options.shouldUnregister || options.shouldUnregister) && !(isNameInFieldArray(_names.array, name) && _state.action) && _names.unMount.add(name);
        }
      }
    };
  };
  const _focusError = () => _options.shouldFocusError && iterateFieldsByAction(_fields, _focusInput, _names.mount);
  const _disableForm = (disabled) => {
    if (isBoolean(disabled)) {
      _subjects.state.next({ disabled });
      iterateFieldsByAction(_fields, (ref, name) => {
        let requiredDisabledState = disabled;
        const currentField = get(_fields, name);
        if (currentField && isBoolean(currentField._f.disabled)) {
          requiredDisabledState || (requiredDisabledState = currentField._f.disabled);
        }
        ref.disabled = requiredDisabledState;
      }, 0, false);
    }
  };
  const handleSubmit = (onValid, onInvalid) => async (e) => {
    if (e) {
      e.preventDefault && e.preventDefault();
      e.persist && e.persist();
    }
    let fieldValues = cloneObject(_formValues);
    _subjects.state.next({
      isSubmitting: true
    });
    if (_options.resolver) {
      const { errors, values: values2 } = await _executeSchema();
      _formState.errors = errors;
      fieldValues = values2;
    } else {
      await executeBuiltInValidation(_fields);
    }
    unset(_formState.errors, "root");
    if (isEmptyObject(_formState.errors)) {
      _subjects.state.next({
        errors: {}
      });
      await onValid(fieldValues, e);
    } else {
      if (onInvalid) {
        await onInvalid({ ..._formState.errors }, e);
      }
      _focusError();
      setTimeout(_focusError);
    }
    _subjects.state.next({
      isSubmitted: true,
      isSubmitting: false,
      isSubmitSuccessful: isEmptyObject(_formState.errors),
      submitCount: _formState.submitCount + 1,
      errors: _formState.errors
    });
  };
  const resetField = (name, options = {}) => {
    if (get(_fields, name)) {
      if (isUndefined(options.defaultValue)) {
        setValue(name, get(_defaultValues, name));
      } else {
        setValue(name, options.defaultValue);
        set(_defaultValues, name, options.defaultValue);
      }
      if (!options.keepTouched) {
        unset(_formState.touchedFields, name);
      }
      if (!options.keepDirty) {
        unset(_formState.dirtyFields, name);
        _formState.isDirty = options.defaultValue ? _getDirty(name, get(_defaultValues, name)) : _getDirty();
      }
      if (!options.keepError) {
        unset(_formState.errors, name);
        _proxyFormState.isValid && _updateValid();
      }
      _subjects.state.next({ ..._formState });
    }
  };
  const _reset = (formValues, keepStateOptions = {}) => {
    const updatedValues = formValues ? cloneObject(formValues) : _defaultValues;
    const cloneUpdatedValues = cloneObject(updatedValues);
    const values2 = formValues && !isEmptyObject(formValues) ? cloneUpdatedValues : _defaultValues;
    if (!keepStateOptions.keepDefaultValues) {
      _defaultValues = updatedValues;
    }
    if (!keepStateOptions.keepValues) {
      if (keepStateOptions.keepDirtyValues || shouldCaptureDirtyFields) {
        for (const fieldName of _names.mount) {
          get(_formState.dirtyFields, fieldName) ? set(values2, fieldName, get(_formValues, fieldName)) : setValue(fieldName, get(values2, fieldName));
        }
      } else {
        if (isWeb && isUndefined(formValues)) {
          for (const name of _names.mount) {
            const field = get(_fields, name);
            if (field && field._f) {
              const fieldReference = Array.isArray(field._f.refs) ? field._f.refs[0] : field._f.ref;
              if (isHTMLElement(fieldReference)) {
                const form = fieldReference.closest("form");
                if (form) {
                  form.reset();
                  break;
                }
              }
            }
          }
        }
        _fields = {};
      }
      _formValues = props.shouldUnregister ? keepStateOptions.keepDefaultValues ? cloneObject(_defaultValues) : {} : cloneObject(values2);
      _subjects.array.next({
        values: { ...values2 }
      });
      _subjects.values.next({
        values: { ...values2 }
      });
    }
    _names = {
      mount: /* @__PURE__ */ new Set(),
      unMount: /* @__PURE__ */ new Set(),
      array: /* @__PURE__ */ new Set(),
      watch: /* @__PURE__ */ new Set(),
      watchAll: false,
      focus: ""
    };
    !_state.mount && flushRootRender();
    _state.mount = !_proxyFormState.isValid || !!keepStateOptions.keepIsValid;
    _state.watch = !!props.shouldUnregister;
    _subjects.state.next({
      submitCount: keepStateOptions.keepSubmitCount ? _formState.submitCount : 0,
      isDirty: keepStateOptions.keepDirty ? _formState.isDirty : !!(keepStateOptions.keepDefaultValues && !deepEqual(formValues, _defaultValues)),
      isSubmitted: keepStateOptions.keepIsSubmitted ? _formState.isSubmitted : false,
      dirtyFields: keepStateOptions.keepDirtyValues ? _formState.dirtyFields : keepStateOptions.keepDefaultValues && formValues ? getDirtyFields(_defaultValues, formValues) : {},
      touchedFields: keepStateOptions.keepTouched ? _formState.touchedFields : {},
      errors: keepStateOptions.keepErrors ? _formState.errors : {},
      isSubmitSuccessful: keepStateOptions.keepIsSubmitSuccessful ? _formState.isSubmitSuccessful : false,
      isSubmitting: false
    });
  };
  const reset = (formValues, keepStateOptions) => _reset(isFunction(formValues) ? formValues(_formValues) : formValues, keepStateOptions);
  const setFocus = (name, options = {}) => {
    const field = get(_fields, name);
    const fieldReference = field && field._f;
    if (fieldReference) {
      const fieldRef = fieldReference.refs ? fieldReference.refs[0] : fieldReference.ref;
      if (fieldRef.focus) {
        fieldRef.focus();
        options.shouldSelect && fieldRef.select();
      }
    }
  };
  const _updateFormState = (updatedFormState) => {
    _formState = {
      ..._formState,
      ...updatedFormState
    };
  };
  const _resetDefaultValues = () => isFunction(_options.defaultValues) && _options.defaultValues().then((values2) => {
    reset(values2, _options.resetOptions);
    _subjects.state.next({
      isLoading: false
    });
  });
  return {
    control: {
      register,
      unregister,
      getFieldState,
      handleSubmit,
      setError,
      _executeSchema,
      _getWatch,
      _getDirty,
      _updateValid,
      _removeUnmounted,
      _updateFieldArray,
      _updateDisabledField,
      _getFieldArray,
      _reset,
      _resetDefaultValues,
      _updateFormState,
      _disableForm,
      _subjects,
      _proxyFormState,
      _setErrors,
      get _fields() {
        return _fields;
      },
      get _formValues() {
        return _formValues;
      },
      get _state() {
        return _state;
      },
      set _state(value) {
        _state = value;
      },
      get _defaultValues() {
        return _defaultValues;
      },
      get _names() {
        return _names;
      },
      set _names(value) {
        _names = value;
      },
      get _formState() {
        return _formState;
      },
      set _formState(value) {
        _formState = value;
      },
      get _options() {
        return _options;
      },
      set _options(value) {
        _options = {
          ..._options,
          ...value
        };
      }
    },
    trigger,
    register,
    handleSubmit,
    watch,
    setValue,
    getValues,
    reset,
    resetField,
    clearErrors,
    unregister,
    setError,
    setFocus,
    getFieldState
  };
}
function useForm(props = {}) {
  const _formControl = React__namespace.default.useRef();
  const _values = React__namespace.default.useRef();
  const [formState, updateFormState] = React__namespace.default.useState({
    isDirty: false,
    isValidating: false,
    isLoading: isFunction(props.defaultValues),
    isSubmitted: false,
    isSubmitting: false,
    isSubmitSuccessful: false,
    isValid: false,
    submitCount: 0,
    dirtyFields: {},
    touchedFields: {},
    errors: props.errors || {},
    disabled: false,
    defaultValues: isFunction(props.defaultValues) ? void 0 : props.defaultValues
  });
  if (!_formControl.current) {
    _formControl.current = {
      ...createFormControl(props, () => updateFormState((formState2) => ({ ...formState2 }))),
      formState
    };
  }
  const control = _formControl.current.control;
  control._options = props;
  useSubscribe({
    subject: control._subjects.state,
    next: (value) => {
      if (shouldRenderFormState(value, control._proxyFormState, control._updateFormState, true)) {
        updateFormState({ ...control._formState });
      }
    }
  });
  React__namespace.default.useEffect(() => control._disableForm(props.disabled), [control, props.disabled]);
  React__namespace.default.useEffect(() => {
    if (control._proxyFormState.isDirty) {
      const isDirty = control._getDirty();
      if (isDirty !== formState.isDirty) {
        control._subjects.state.next({
          isDirty
        });
      }
    }
  }, [control, formState.isDirty]);
  React__namespace.default.useEffect(() => {
    if (props.values && !deepEqual(props.values, _values.current)) {
      control._reset(props.values, control._options.resetOptions);
      _values.current = props.values;
      updateFormState((state) => ({ ...state }));
    } else {
      control._resetDefaultValues();
    }
  }, [props.values, control]);
  React__namespace.default.useEffect(() => {
    if (props.errors) {
      control._setErrors(props.errors);
    }
  }, [props.errors, control]);
  React__namespace.default.useEffect(() => {
    if (!control._state.mount) {
      control._updateValid();
      control._state.mount = true;
    }
    if (control._state.watch) {
      control._state.watch = false;
      control._subjects.state.next({ ...control._formState });
    }
    control._removeUnmounted();
  });
  _formControl.current.formState = getProxyFormState(formState, control);
  return _formControl.current;
}
function composeEventHandlers(originalEventHandler, ourEventHandler, { checkForDefaultPrevented = true } = {}) {
  return function handleEvent(event) {
    originalEventHandler == null ? void 0 : originalEventHandler(event);
    if (checkForDefaultPrevented === false || !event.defaultPrevented) {
      return ourEventHandler == null ? void 0 : ourEventHandler(event);
    }
  };
}
function createContextScope(scopeName, createContextScopeDeps = []) {
  let defaultContexts = [];
  function createContext3(rootComponentName, defaultContext) {
    const BaseContext = React__namespace.createContext(defaultContext);
    const index = defaultContexts.length;
    defaultContexts = [...defaultContexts, defaultContext];
    const Provider = (props) => {
      var _a;
      const { scope, children, ...context } = props;
      const Context = ((_a = scope == null ? void 0 : scope[scopeName]) == null ? void 0 : _a[index]) || BaseContext;
      const value = React__namespace.useMemo(() => context, Object.values(context));
      return /* @__PURE__ */ jsxRuntime.jsx(Context.Provider, { value, children });
    };
    Provider.displayName = rootComponentName + "Provider";
    function useContext2(consumerName, scope) {
      var _a;
      const Context = ((_a = scope == null ? void 0 : scope[scopeName]) == null ? void 0 : _a[index]) || BaseContext;
      const context = React__namespace.useContext(Context);
      if (context) return context;
      if (defaultContext !== void 0) return defaultContext;
      throw new Error(`\`${consumerName}\` must be used within \`${rootComponentName}\``);
    }
    return [Provider, useContext2];
  }
  const createScope = () => {
    const scopeContexts = defaultContexts.map((defaultContext) => {
      return React__namespace.createContext(defaultContext);
    });
    return function useScope(scope) {
      const contexts = (scope == null ? void 0 : scope[scopeName]) || scopeContexts;
      return React__namespace.useMemo(
        () => ({ [`__scope${scopeName}`]: { ...scope, [scopeName]: contexts } }),
        [scope, contexts]
      );
    };
  };
  createScope.scopeName = scopeName;
  return [createContext3, composeContextScopes(createScope, ...createContextScopeDeps)];
}
function composeContextScopes(...scopes) {
  const baseScope = scopes[0];
  if (scopes.length === 1) return baseScope;
  const createScope = () => {
    const scopeHooks = scopes.map((createScope2) => ({
      useScope: createScope2(),
      scopeName: createScope2.scopeName
    }));
    return function useComposedScopes(overrideScopes) {
      const nextScopes = scopeHooks.reduce((nextScopes2, { useScope, scopeName }) => {
        const scopeProps = useScope(overrideScopes);
        const currentScope = scopeProps[`__scope${scopeName}`];
        return { ...nextScopes2, ...currentScope };
      }, {});
      return React__namespace.useMemo(() => ({ [`__scope${baseScope.scopeName}`]: nextScopes }), [nextScopes]);
    };
  };
  createScope.scopeName = baseScope.scopeName;
  return createScope;
}
function useCallbackRef(callback) {
  const callbackRef = React__namespace.useRef(callback);
  React__namespace.useEffect(() => {
    callbackRef.current = callback;
  });
  return React__namespace.useMemo(() => (...args) => {
    var _a;
    return (_a = callbackRef.current) == null ? void 0 : _a.call(callbackRef, ...args);
  }, []);
}
function useControllableState({
  prop,
  defaultProp,
  onChange = () => {
  }
}) {
  const [uncontrolledProp, setUncontrolledProp] = useUncontrolledState({ defaultProp, onChange });
  const isControlled = prop !== void 0;
  const value = isControlled ? prop : uncontrolledProp;
  const handleChange = useCallbackRef(onChange);
  const setValue = React__namespace.useCallback(
    (nextValue) => {
      if (isControlled) {
        const setter = nextValue;
        const value2 = typeof nextValue === "function" ? setter(prop) : nextValue;
        if (value2 !== prop) handleChange(value2);
      } else {
        setUncontrolledProp(nextValue);
      }
    },
    [isControlled, prop, setUncontrolledProp, handleChange]
  );
  return [value, setValue];
}
function useUncontrolledState({
  defaultProp,
  onChange
}) {
  const uncontrolledState = React__namespace.useState(defaultProp);
  const [value] = uncontrolledState;
  const prevValueRef = React__namespace.useRef(value);
  const handleChange = useCallbackRef(onChange);
  React__namespace.useEffect(() => {
    if (prevValueRef.current !== value) {
      handleChange(value);
      prevValueRef.current = value;
    }
  }, [value, prevValueRef, handleChange]);
  return uncontrolledState;
}
var useLayoutEffect2 = Boolean(globalThis == null ? void 0 : globalThis.document) ? React__namespace.useLayoutEffect : () => {
};
function setRef(ref, value) {
  if (typeof ref === "function") {
    return ref(value);
  } else if (ref !== null && ref !== void 0) {
    ref.current = value;
  }
}
function composeRefs(...refs) {
  return (node) => {
    let hasCleanup = false;
    const cleanups = refs.map((ref) => {
      const cleanup = setRef(ref, node);
      if (!hasCleanup && typeof cleanup == "function") {
        hasCleanup = true;
      }
      return cleanup;
    });
    if (hasCleanup) {
      return () => {
        for (let i = 0; i < cleanups.length; i++) {
          const cleanup = cleanups[i];
          if (typeof cleanup == "function") {
            cleanup();
          } else {
            setRef(refs[i], null);
          }
        }
      };
    }
  };
}
function useComposedRefs(...refs) {
  return React__namespace.useCallback(composeRefs(...refs), refs);
}
var Slot = React__namespace.forwardRef((props, forwardedRef) => {
  const { children, ...slotProps } = props;
  const childrenArray = React__namespace.Children.toArray(children);
  const slottable = childrenArray.find(isSlottable);
  if (slottable) {
    const newElement = slottable.props.children;
    const newChildren = childrenArray.map((child) => {
      if (child === slottable) {
        if (React__namespace.Children.count(newElement) > 1) return React__namespace.Children.only(null);
        return React__namespace.isValidElement(newElement) ? newElement.props.children : null;
      } else {
        return child;
      }
    });
    return /* @__PURE__ */ jsxRuntime.jsx(SlotClone, { ...slotProps, ref: forwardedRef, children: React__namespace.isValidElement(newElement) ? React__namespace.cloneElement(newElement, void 0, newChildren) : null });
  }
  return /* @__PURE__ */ jsxRuntime.jsx(SlotClone, { ...slotProps, ref: forwardedRef, children });
});
Slot.displayName = "Slot";
var SlotClone = React__namespace.forwardRef((props, forwardedRef) => {
  const { children, ...slotProps } = props;
  if (React__namespace.isValidElement(children)) {
    const childrenRef = getElementRef$1(children);
    return React__namespace.cloneElement(children, {
      ...mergeProps(slotProps, children.props),
      // @ts-ignore
      ref: forwardedRef ? composeRefs(forwardedRef, childrenRef) : childrenRef
    });
  }
  return React__namespace.Children.count(children) > 1 ? React__namespace.Children.only(null) : null;
});
SlotClone.displayName = "SlotClone";
var Slottable = ({ children }) => {
  return /* @__PURE__ */ jsxRuntime.jsx(jsxRuntime.Fragment, { children });
};
function isSlottable(child) {
  return React__namespace.isValidElement(child) && child.type === Slottable;
}
function mergeProps(slotProps, childProps) {
  const overrideProps = { ...childProps };
  for (const propName in childProps) {
    const slotPropValue = slotProps[propName];
    const childPropValue = childProps[propName];
    const isHandler = /^on[A-Z]/.test(propName);
    if (isHandler) {
      if (slotPropValue && childPropValue) {
        overrideProps[propName] = (...args) => {
          childPropValue(...args);
          slotPropValue(...args);
        };
      } else if (slotPropValue) {
        overrideProps[propName] = slotPropValue;
      }
    } else if (propName === "style") {
      overrideProps[propName] = { ...slotPropValue, ...childPropValue };
    } else if (propName === "className") {
      overrideProps[propName] = [slotPropValue, childPropValue].filter(Boolean).join(" ");
    }
  }
  return { ...slotProps, ...overrideProps };
}
function getElementRef$1(element) {
  var _a, _b;
  let getter = (_a = Object.getOwnPropertyDescriptor(element.props, "ref")) == null ? void 0 : _a.get;
  let mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
  if (mayWarn) {
    return element.ref;
  }
  getter = (_b = Object.getOwnPropertyDescriptor(element, "ref")) == null ? void 0 : _b.get;
  mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
  if (mayWarn) {
    return element.props.ref;
  }
  return element.props.ref || element.ref;
}
var NODES = [
  "a",
  "button",
  "div",
  "form",
  "h2",
  "h3",
  "img",
  "input",
  "label",
  "li",
  "nav",
  "ol",
  "p",
  "span",
  "svg",
  "ul"
];
var Primitive = NODES.reduce((primitive, node) => {
  const Node = React__namespace.forwardRef((props, forwardedRef) => {
    const { asChild, ...primitiveProps } = props;
    const Comp = asChild ? Slot : node;
    if (typeof window !== "undefined") {
      window[Symbol.for("radix-ui")] = true;
    }
    return /* @__PURE__ */ jsxRuntime.jsx(Comp, { ...primitiveProps, ref: forwardedRef });
  });
  Node.displayName = `Primitive.${node}`;
  return { ...primitive, [node]: Node };
}, {});
function useStateMachine(initialState, machine) {
  return React__namespace.useReducer((state, event) => {
    const nextState = machine[state][event];
    return nextState ?? state;
  }, initialState);
}
var Presence = (props) => {
  const { present, children } = props;
  const presence = usePresence(present);
  const child = typeof children === "function" ? children({ present: presence.isPresent }) : React__namespace.Children.only(children);
  const ref = useComposedRefs(presence.ref, getElementRef(child));
  const forceMount = typeof children === "function";
  return forceMount || presence.isPresent ? React__namespace.cloneElement(child, { ref }) : null;
};
Presence.displayName = "Presence";
function usePresence(present) {
  const [node, setNode] = React__namespace.useState();
  const stylesRef = React__namespace.useRef({});
  const prevPresentRef = React__namespace.useRef(present);
  const prevAnimationNameRef = React__namespace.useRef("none");
  const initialState = present ? "mounted" : "unmounted";
  const [state, send] = useStateMachine(initialState, {
    mounted: {
      UNMOUNT: "unmounted",
      ANIMATION_OUT: "unmountSuspended"
    },
    unmountSuspended: {
      MOUNT: "mounted",
      ANIMATION_END: "unmounted"
    },
    unmounted: {
      MOUNT: "mounted"
    }
  });
  React__namespace.useEffect(() => {
    const currentAnimationName = getAnimationName(stylesRef.current);
    prevAnimationNameRef.current = state === "mounted" ? currentAnimationName : "none";
  }, [state]);
  useLayoutEffect2(() => {
    const styles2 = stylesRef.current;
    const wasPresent = prevPresentRef.current;
    const hasPresentChanged = wasPresent !== present;
    if (hasPresentChanged) {
      const prevAnimationName = prevAnimationNameRef.current;
      const currentAnimationName = getAnimationName(styles2);
      if (present) {
        send("MOUNT");
      } else if (currentAnimationName === "none" || (styles2 == null ? void 0 : styles2.display) === "none") {
        send("UNMOUNT");
      } else {
        const isAnimating = prevAnimationName !== currentAnimationName;
        if (wasPresent && isAnimating) {
          send("ANIMATION_OUT");
        } else {
          send("UNMOUNT");
        }
      }
      prevPresentRef.current = present;
    }
  }, [present, send]);
  useLayoutEffect2(() => {
    if (node) {
      let timeoutId;
      const ownerWindow = node.ownerDocument.defaultView ?? window;
      const handleAnimationEnd = (event) => {
        const currentAnimationName = getAnimationName(stylesRef.current);
        const isCurrentAnimation = currentAnimationName.includes(event.animationName);
        if (event.target === node && isCurrentAnimation) {
          send("ANIMATION_END");
          if (!prevPresentRef.current) {
            const currentFillMode = node.style.animationFillMode;
            node.style.animationFillMode = "forwards";
            timeoutId = ownerWindow.setTimeout(() => {
              if (node.style.animationFillMode === "forwards") {
                node.style.animationFillMode = currentFillMode;
              }
            });
          }
        }
      };
      const handleAnimationStart = (event) => {
        if (event.target === node) {
          prevAnimationNameRef.current = getAnimationName(stylesRef.current);
        }
      };
      node.addEventListener("animationstart", handleAnimationStart);
      node.addEventListener("animationcancel", handleAnimationEnd);
      node.addEventListener("animationend", handleAnimationEnd);
      return () => {
        ownerWindow.clearTimeout(timeoutId);
        node.removeEventListener("animationstart", handleAnimationStart);
        node.removeEventListener("animationcancel", handleAnimationEnd);
        node.removeEventListener("animationend", handleAnimationEnd);
      };
    } else {
      send("ANIMATION_END");
    }
  }, [node, send]);
  return {
    isPresent: ["mounted", "unmountSuspended"].includes(state),
    ref: React__namespace.useCallback((node2) => {
      if (node2) stylesRef.current = getComputedStyle(node2);
      setNode(node2);
    }, [])
  };
}
function getAnimationName(styles2) {
  return (styles2 == null ? void 0 : styles2.animationName) || "none";
}
function getElementRef(element) {
  var _a, _b;
  let getter = (_a = Object.getOwnPropertyDescriptor(element.props, "ref")) == null ? void 0 : _a.get;
  let mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
  if (mayWarn) {
    return element.ref;
  }
  getter = (_b = Object.getOwnPropertyDescriptor(element, "ref")) == null ? void 0 : _b.get;
  mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
  if (mayWarn) {
    return element.props.ref;
  }
  return element.props.ref || element.ref;
}
var useReactId = React__namespace["useId".toString()] || (() => void 0);
var count = 0;
function useId(deterministicId) {
  const [id, setId] = React__namespace.useState(useReactId());
  useLayoutEffect2(() => {
    setId((reactId) => reactId ?? String(count++));
  }, [deterministicId]);
  return deterministicId || (id ? `radix-${id}` : "");
}
var COLLAPSIBLE_NAME = "Collapsible";
var [createCollapsibleContext] = createContextScope(COLLAPSIBLE_NAME);
var [CollapsibleProvider, useCollapsibleContext] = createCollapsibleContext(COLLAPSIBLE_NAME);
var Collapsible$1 = React__namespace.forwardRef(
  (props, forwardedRef) => {
    const {
      __scopeCollapsible,
      open: openProp,
      defaultOpen,
      disabled,
      onOpenChange,
      ...collapsibleProps
    } = props;
    const [open = false, setOpen] = useControllableState({
      prop: openProp,
      defaultProp: defaultOpen,
      onChange: onOpenChange
    });
    return /* @__PURE__ */ jsxRuntime.jsx(
      CollapsibleProvider,
      {
        scope: __scopeCollapsible,
        disabled,
        contentId: useId(),
        open,
        onOpenToggle: React__namespace.useCallback(() => setOpen((prevOpen) => !prevOpen), [setOpen]),
        children: /* @__PURE__ */ jsxRuntime.jsx(
          Primitive.div,
          {
            "data-state": getState(open),
            "data-disabled": disabled ? "" : void 0,
            ...collapsibleProps,
            ref: forwardedRef
          }
        )
      }
    );
  }
);
Collapsible$1.displayName = COLLAPSIBLE_NAME;
var TRIGGER_NAME = "CollapsibleTrigger";
var CollapsibleTrigger$1 = React__namespace.forwardRef(
  (props, forwardedRef) => {
    const { __scopeCollapsible, ...triggerProps } = props;
    const context = useCollapsibleContext(TRIGGER_NAME, __scopeCollapsible);
    return /* @__PURE__ */ jsxRuntime.jsx(
      Primitive.button,
      {
        type: "button",
        "aria-controls": context.contentId,
        "aria-expanded": context.open || false,
        "data-state": getState(context.open),
        "data-disabled": context.disabled ? "" : void 0,
        disabled: context.disabled,
        ...triggerProps,
        ref: forwardedRef,
        onClick: composeEventHandlers(props.onClick, context.onOpenToggle)
      }
    );
  }
);
CollapsibleTrigger$1.displayName = TRIGGER_NAME;
var CONTENT_NAME = "CollapsibleContent";
var CollapsibleContent$1 = React__namespace.forwardRef(
  (props, forwardedRef) => {
    const { forceMount, ...contentProps } = props;
    const context = useCollapsibleContext(CONTENT_NAME, props.__scopeCollapsible);
    return /* @__PURE__ */ jsxRuntime.jsx(Presence, { present: forceMount || context.open, children: ({ present }) => /* @__PURE__ */ jsxRuntime.jsx(CollapsibleContentImpl, { ...contentProps, ref: forwardedRef, present }) });
  }
);
CollapsibleContent$1.displayName = CONTENT_NAME;
var CollapsibleContentImpl = React__namespace.forwardRef((props, forwardedRef) => {
  const { __scopeCollapsible, present, children, ...contentProps } = props;
  const context = useCollapsibleContext(CONTENT_NAME, __scopeCollapsible);
  const [isPresent, setIsPresent] = React__namespace.useState(present);
  const ref = React__namespace.useRef(null);
  const composedRefs = useComposedRefs(forwardedRef, ref);
  const heightRef = React__namespace.useRef(0);
  const height = heightRef.current;
  const widthRef = React__namespace.useRef(0);
  const width = widthRef.current;
  const isOpen = context.open || isPresent;
  const isMountAnimationPreventedRef = React__namespace.useRef(isOpen);
  const originalStylesRef = React__namespace.useRef(void 0);
  React__namespace.useEffect(() => {
    const rAF = requestAnimationFrame(() => isMountAnimationPreventedRef.current = false);
    return () => cancelAnimationFrame(rAF);
  }, []);
  useLayoutEffect2(() => {
    const node = ref.current;
    if (node) {
      originalStylesRef.current = originalStylesRef.current || {
        transitionDuration: node.style.transitionDuration,
        animationName: node.style.animationName
      };
      node.style.transitionDuration = "0s";
      node.style.animationName = "none";
      const rect = node.getBoundingClientRect();
      heightRef.current = rect.height;
      widthRef.current = rect.width;
      if (!isMountAnimationPreventedRef.current) {
        node.style.transitionDuration = originalStylesRef.current.transitionDuration;
        node.style.animationName = originalStylesRef.current.animationName;
      }
      setIsPresent(present);
    }
  }, [context.open, present]);
  return /* @__PURE__ */ jsxRuntime.jsx(
    Primitive.div,
    {
      "data-state": getState(context.open),
      "data-disabled": context.disabled ? "" : void 0,
      id: context.contentId,
      hidden: !isOpen,
      ...contentProps,
      ref: composedRefs,
      style: {
        [`--radix-collapsible-content-height`]: height ? `${height}px` : void 0,
        [`--radix-collapsible-content-width`]: width ? `${width}px` : void 0,
        ...props.style
      },
      children: isOpen && children
    }
  );
});
function getState(open) {
  return open ? "open" : "closed";
}
var Root$1 = Collapsible$1;
const Collapsible = Root$1;
const CollapsibleTrigger = CollapsibleTrigger$1;
const CollapsibleContent = CollapsibleContent$1;
const DatasetCreateForm = ({
  setRefetch,
  anyActive,
  isFirst,
  defaultOpen = false,
  onSuccess
}) => {
  const [providersConfig, setProvidersConfig] = React.useState(void 0);
  const [languageModelNames, setLanguageModelNames] = React.useState(void 0);
  const [embeddingModels, setEmbeddingModels] = React.useState(void 0);
  const [formOpen, setFormOpen] = React.useState(defaultOpen);
  const [advancedOpen, setAdvancedOpen] = React.useState(false);
  const defaultValues = {
    name: isFirst ? "Default" : "",
    language_model_provider: "",
    language_model: "",
    embedding_provider: "",
    embedding_model: "",
    embedding_vector_dimensions: 512,
    preconfigure_agents: true
  };
  const form = useForm({ defaultValues });
  React.useEffect(() => {
    const loadProvidersConfig = async () => {
      const result = await adminApiClient.config().getAvailableProviders();
      setProvidersConfig(result);
      if (!form.getValues("language_model_provider") && result.languageModelProviders.length > 0) {
        form.setValue("language_model_provider", result.languageModelProviders[0]);
      }
      if (!form.getValues("embedding_provider") && result.embeddingProviders.length > 0) {
        form.setValue("embedding_provider", result.embeddingProviders[0]);
      }
    };
    void loadProvidersConfig();
  }, []);
  const languageModelProvider = form.watch("language_model_provider");
  React.useEffect(() => {
    const loadLanguageModels = async () => {
      if (languageModelProvider) {
        setLanguageModelNames(void 0);
        const result = await adminApiClient.config().getLanguageModelsForProvider(languageModelProvider);
        setLanguageModelNames(result);
        const current = form.getValues("language_model");
        if (result.length > 0 && (!current || !result.includes(current))) {
          form.setValue("language_model", result[0]);
        }
      }
    };
    void loadLanguageModels();
  }, [languageModelProvider]);
  const embeddingProvider = form.watch("embedding_provider");
  React.useEffect(() => {
    const loadEmbeddingModels = async () => {
      if (embeddingProvider) {
        setEmbeddingModels(void 0);
        const result = await adminApiClient.config().getEmbeddingModelsForProvider(embeddingProvider);
        setEmbeddingModels(result);
        const current = form.getValues("embedding_model");
        if (result.length > 0 && (!current || !result.includes(current))) {
          form.setValue("embedding_model", result[0]);
        }
      }
    };
    void loadEmbeddingModels();
  }, [embeddingProvider]);
  const handleSubmit = form.handleSubmit(async (payload) => {
    const dataset = await adminApiClient.enthusiastDatasets().create(payload);
    if (!anyActive) {
      await adminApiClient.dataSets().setAsActive(dataset.id);
    }
    if (setRefetch) {
      void setRefetch();
    }
    form.reset();
    setFormOpen(false);
    ui.toast.success("Success", {
      description: `Dataset "${dataset.name}" created successfully`,
      position: "top-right"
    });
    onSuccess == null ? void 0 : onSuccess();
  });
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.FocusModal, { open: formOpen, onOpenChange: setFormOpen, children: [
    /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Trigger, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { variant: "secondary", children: "Create" }) }),
    /* @__PURE__ */ jsxRuntime.jsxs(ui.FocusModal.Content, { children: [
      /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Header, { className: "flex items-center justify-between px-6 py-4", children: /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex items-center gap-x-4", children: /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Close, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(
        ui.IconButton,
        {
          size: "small",
          variant: "transparent",
          className: "text-ui-contrast-fg-secondary hover:text-ui-contrast-fg-primary hover:bg-ui-contrast-bg-base-hover active:bg-ui-contrast-bg-base-pressed focus-visible:bg-ui-contrast-bg-base-hover focus-visible:shadow-borders-interactive-with-active",
          children: /* @__PURE__ */ jsxRuntime.jsx(icons.XMarkMini, {})
        }
      ) }) }) }),
      /* @__PURE__ */ jsxRuntime.jsx(FormProvider, { ...form, children: /* @__PURE__ */ jsxRuntime.jsxs(
        "form",
        {
          onSubmit: (e) => {
            void handleSubmit(e);
          },
          className: "flex h-full flex-col overflow-hidden",
          children: [
            /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Body, { children: /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex flex-1 flex-col items-center overflow-y-auto", children: /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "mx-auto flex w-full max-w-[720px] flex-col gap-y-8 px-2 py-16", children: [
              /* @__PURE__ */ jsxRuntime.jsx("div", { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { children: "Connect to a language model" }) }),
              /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-4", children: [
                !isFirst && /* @__PURE__ */ jsxRuntime.jsx(
                  Controller,
                  {
                    control: form.control,
                    name: "name",
                    render: ({ field }) => {
                      return /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col space-y-2", children: [
                        /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex items-center gap-x-1", children: /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { size: "small", weight: "plus", children: "Name" }) }),
                        /* @__PURE__ */ jsxRuntime.jsx(ui.Input, { ...field })
                      ] });
                    }
                  }
                ),
                /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { size: "small", weight: "plus", children: "Language Model" }),
                /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
                  /* @__PURE__ */ jsxRuntime.jsx(
                    Controller,
                    {
                      control: form.control,
                      name: "language_model_provider",
                      render: ({ field }) => {
                        var _a;
                        return /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex flex-col space-y-2", children: /* @__PURE__ */ jsxRuntime.jsxs(
                          ui.Select,
                          {
                            value: field.value ?? void 0,
                            onValueChange: (v) => {
                              field.onChange(v);
                              form.resetField("language_model");
                            },
                            children: [
                              /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Trigger, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Value, { placeholder: "Select a provider" }) }),
                              /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Content, { children: ((_a = providersConfig == null ? void 0 : providersConfig.languageModelProviders) == null ? void 0 : _a.length) ? providersConfig.languageModelProviders.map((name) => /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: name, children: name }, name)) : /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { disabled: true, value: "__empty_lm_provider__", children: providersConfig ? "No providers found" : "Loading..." }) })
                            ]
                          }
                        ) });
                      }
                    }
                  ),
                  /* @__PURE__ */ jsxRuntime.jsx(
                    Controller,
                    {
                      control: form.control,
                      name: "language_model",
                      render: ({ field }) => {
                        return /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex flex-col space-y-2", children: /* @__PURE__ */ jsxRuntime.jsxs(
                          ui.Select,
                          {
                            value: field.value ?? void 0,
                            onValueChange: field.onChange,
                            disabled: !languageModelProvider,
                            children: [
                              /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Trigger, { children: /* @__PURE__ */ jsxRuntime.jsx(
                                ui.Select.Value,
                                {
                                  placeholder: languageModelProvider ? "Select a model" : "Select provider first"
                                }
                              ) }),
                              /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Content, { children: (languageModelNames == null ? void 0 : languageModelNames.length) ? languageModelNames.map((name) => /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: name, children: name }, name)) : /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { disabled: true, value: "__empty_lm__", children: languageModelNames ? "No models found" : "Loading..." }) })
                            ]
                          }
                        ) });
                      }
                    }
                  )
                ] }),
                /* @__PURE__ */ jsxRuntime.jsxs(
                  Collapsible,
                  {
                    className: "py-4",
                    open: advancedOpen,
                    onOpenChange: setAdvancedOpen,
                    children: [
                      /* @__PURE__ */ jsxRuntime.jsx(CollapsibleTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsxs(ui.Button, { variant: "transparent", className: "pl-0", children: [
                        /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { size: "small", weight: "plus", children: "Advanced settings" }),
                        /* @__PURE__ */ jsxRuntime.jsx(
                          icons.ChevronRightMini,
                          {
                            className: cn(
                              "transition-transform duration-200 ease-in-out",
                              advancedOpen && "rotate-90"
                            )
                          }
                        )
                      ] }) }),
                      /* @__PURE__ */ jsxRuntime.jsx(CollapsibleContent, { children: /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col gap-4", children: [
                        /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { size: "small", weight: "plus", children: "Embedding Provider" }),
                        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
                          /* @__PURE__ */ jsxRuntime.jsx(
                            Controller,
                            {
                              control: form.control,
                              name: "embedding_provider",
                              render: ({ field }) => {
                                var _a;
                                return /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex flex-col space-y-2", children: /* @__PURE__ */ jsxRuntime.jsxs(
                                  ui.Select,
                                  {
                                    value: field.value ?? void 0,
                                    onValueChange: (v) => {
                                      field.onChange(v);
                                      form.resetField("embedding_model");
                                    },
                                    children: [
                                      /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Trigger, { children: /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Value, { placeholder: "Select a provider" }) }),
                                      /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Content, { children: ((_a = providersConfig == null ? void 0 : providersConfig.embeddingProviders) == null ? void 0 : _a.length) ? providersConfig.embeddingProviders.map((name) => /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: name, children: name }, name)) : /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { disabled: true, value: "__empty_embed_provider__", children: providersConfig ? "No providers found" : "Loading..." }) })
                                    ]
                                  }
                                ) });
                              }
                            }
                          ),
                          /* @__PURE__ */ jsxRuntime.jsx(
                            Controller,
                            {
                              control: form.control,
                              name: "embedding_model",
                              render: ({ field }) => {
                                return /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex flex-col space-y-2", children: /* @__PURE__ */ jsxRuntime.jsxs(
                                  ui.Select,
                                  {
                                    value: field.value ?? void 0,
                                    onValueChange: field.onChange,
                                    disabled: !embeddingProvider,
                                    children: [
                                      /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Trigger, { children: /* @__PURE__ */ jsxRuntime.jsx(
                                        ui.Select.Value,
                                        {
                                          placeholder: embeddingProvider ? "Select a model" : "Select provider first"
                                        }
                                      ) }),
                                      /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Content, { children: (embeddingModels == null ? void 0 : embeddingModels.length) ? embeddingModels.map((name) => /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { value: name, children: name }, name)) : /* @__PURE__ */ jsxRuntime.jsx(ui.Select.Item, { disabled: true, value: "__empty_embed_model__", children: embeddingModels ? "No models found" : "Loading..." }) })
                                    ]
                                  }
                                ) });
                              }
                            }
                          )
                        ] }),
                        /* @__PURE__ */ jsxRuntime.jsx(
                          Controller,
                          {
                            control: form.control,
                            name: "embedding_vector_dimensions",
                            render: ({ field }) => {
                              return /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col space-y-2", children: [
                                /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex items-center gap-x-1", children: /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { size: "small", weight: "plus", children: "Embedding Provider Dimensions" }) }),
                                /* @__PURE__ */ jsxRuntime.jsx(
                                  ui.Input,
                                  {
                                    type: "number",
                                    value: Number.isFinite(field.value) ? String(field.value) : "",
                                    onChange: (e) => {
                                      const v = e.target.value;
                                      field.onChange(v === "" ? 0 : Number(v));
                                    }
                                  }
                                )
                              ] });
                            }
                          }
                        )
                      ] }) })
                    ]
                  }
                )
              ] })
            ] }) }) }),
            /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Footer, { children: /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center justify-end gap-x-2", children: [
              /* @__PURE__ */ jsxRuntime.jsx(ui.FocusModal.Close, { asChild: true, children: /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { size: "small", variant: "secondary", children: "Cancel" }) }),
              /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { type: "submit", size: "small", children: "Save" })
            ] }) })
          ]
        }
      ) })
    ] })
  ] });
};
const DatasetTable = ({ forceOpenCreate = false, onCreateSuccess }) => {
  const [datasets, setDatasets] = React.useState([]);
  const [hasLoaded, setHasLoaded] = React.useState(false);
  const fetchDatasets = React.useCallback(async () => {
    const res = await adminApiClient.dataSets().getInternalDataSets();
    setDatasets(res);
    setHasLoaded(true);
  }, []);
  React.useEffect(() => {
    void fetchDatasets();
  }, [fetchDatasets]);
  const columnHelper2 = ui.createDataTableColumnHelper();
  const columns2 = [
    columnHelper2.accessor("name", {
      header: "Name"
    }),
    columnHelper2.accessor("is_active", {
      header: () => {
        return /* @__PURE__ */ jsxRuntime.jsx(
          ColumnHeaderWithTooltip,
          {
            name: "Active",
            tooltip: "Active dataset will be used in all chats."
          }
        );
      },
      cell: ({ getValue, row }) => {
        const isChecked = getValue();
        return /* @__PURE__ */ jsxRuntime.jsx(
          ui.RadioGroup,
          {
            value: isChecked ? row.original.id : "",
            onValueChange: () => {
              void (async () => {
                try {
                  await adminApiClient.dataSets().setAsActive(row.original.id);
                  setDatasets(
                    (prev) => prev.map((dataset) => ({
                      ...dataset,
                      is_active: dataset.id === row.original.id
                    }))
                  );
                } finally {
                  void fetchDatasets();
                }
              })();
            },
            children: /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-x-3", children: [
              /* @__PURE__ */ jsxRuntime.jsx(
                ui.RadioGroup.Item,
                {
                  value: row.original.id,
                  id: `radio_${row.original.id}`,
                  checked: isChecked
                }
              ),
              /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: `radio_${row.original.id}`, weight: "plus", children: "Active" })
            ] })
          }
        );
      }
    }),
    columnHelper2.accessor("sync_status", {
      header: "Synchronization Status",
      cell: ({ row }) => {
        return /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center gap-x-3", children: [
          /* @__PURE__ */ jsxRuntime.jsx(ui.Label, { htmlFor: `${row.original.id}`, weight: "plus", children: row.original.sync_status }),
          row.original.sync_status && /* @__PURE__ */ jsxRuntime.jsx(
            ui.IconButton,
            {
              variant: "transparent",
              onClick: () => {
                void (async () => {
                  await adminApiClient.dataSets().synchronizeDatasets(row.original.id);
                  void fetchDatasets();
                })();
              },
              children: /* @__PURE__ */ jsxRuntime.jsx(icons.ArrowPath, {})
            }
          )
        ] });
      }
    }),
    columnHelper2.accessor("last_synced", {
      header: "Last Synchronized",
      cell: ({ getValue }) => {
        const date = getValue();
        if (date) {
          return /* @__PURE__ */ jsxRuntime.jsx(ui.Tooltip, { content: getFullDate({ date, includeTime: true }), children: /* @__PURE__ */ jsxRuntime.jsx("span", { children: getFullDate({ date }) }) });
        }
        return null;
      }
    })
  ];
  const table = ui.useDataTable({
    columns: columns2,
    data: datasets,
    getRowId: (row) => row.id,
    rowCount: datasets.length
  });
  return /* @__PURE__ */ jsxRuntime.jsx(ui.Container, { children: /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex flex-col min-h-0", children: /* @__PURE__ */ jsxRuntime.jsxs(ui.DataTable, { instance: table, children: [
    /* @__PURE__ */ jsxRuntime.jsxs(ui.DataTable.Toolbar, { className: "flex flex-col items-start justify-between gap-2 md:flex-row md:items-center flex-shrink-0", children: [
      /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col", children: [
        /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { children: "Data Sets" }),
        /* @__PURE__ */ jsxRuntime.jsx(ui.Text, { className: "text-ui-fg-subtle", size: "small", children: "A data set represents a configuration of agents, products and documents sources" })
      ] }),
      /* @__PURE__ */ jsxRuntime.jsx(
        DatasetCreateForm,
        {
          setRefetch: fetchDatasets,
          anyActive: datasets.some((dataset) => dataset.is_active),
          isFirst: !datasets.length,
          defaultOpen: forceOpenCreate || hasLoaded && datasets.length === 0,
          onSuccess: onCreateSuccess
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntime.jsx(
      "div",
      {
        className: "flex-1 overflow-auto min-h-0 max-h-[calc(100vh-16rem)]",
        onWheel: (e) => {
          const container = e.currentTarget;
          container.scrollTop += e.deltaY;
        },
        children: /* @__PURE__ */ jsxRuntime.jsx(
          ui.DataTable.Table,
          {
            emptyState: {
              empty: {
                heading: "No Datasets",
                description: "There is no datasets available."
              }
            }
          }
        )
      }
    )
  ] }) }) });
};
const EnthusiastSettingPage = () => {
  const [searchParams] = reactRouterDom.useSearchParams();
  const navigate = reactRouterDom.useNavigate();
  const forceOpenCreate = searchParams.has("create_dataset");
  return /* @__PURE__ */ jsxRuntime.jsx(
    DatasetTable,
    {
      forceOpenCreate,
      onCreateSuccess: forceOpenCreate ? () => navigate("/enthusiast") : void 0
    }
  );
};
adminSdk.defineRouteConfig({});
const handle$1 = {
  breadcrumb: () => "Settings"
};
function AgentList({ agents, currentAgentId, onAgentClick }) {
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "h-full flex flex-col", children: [
    /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { level: "h3", className: "text-lg font-medium", children: "List of Agents" }),
    /* @__PURE__ */ jsxRuntime.jsx(
      "div",
      {
        className: "space-y-1 flex-1 overflow-y-auto min-h-0 [&::-webkit-scrollbar]:hidden pt-4",
        style: {
          scrollbarWidth: "none",
          msOverflowStyle: "none"
        },
        children: agents.map((agent) => {
          const isSelected = currentAgentId === agent.id;
          return /* @__PURE__ */ jsxRuntime.jsxs(
            "button",
            {
              className: cn(
                "w-full flex items-center gap-2 px-2 py-1.5 rounded text-sm hover:bg-ui-bg-base-hover transition-colors",
                isSelected && "bg-muted"
              ),
              onClick: () => onAgentClick(agent.id),
              children: [
                isSelected && /* @__PURE__ */ jsxRuntime.jsx(icons.Check, { className: "w-4 h-4" }),
                !isSelected && /* @__PURE__ */ jsxRuntime.jsx("div", { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntime.jsx("span", { className: "flex-1 text-left", children: agent.name })
              ]
            },
            agent.id
          );
        })
      }
    )
  ] });
}
function ConversationHistory({
  conversations,
  currentConversationId,
  onConversationClick,
  onNewChat
}) {
  return /* @__PURE__ */ jsxRuntime.jsxs(ui.Container, { className: "h-full flex flex-col", children: [
    /* @__PURE__ */ jsxRuntime.jsx(ui.Heading, { level: "h3", className: "text-lg font-medium pb-4", children: "Conversation History" }),
    /* @__PURE__ */ jsxRuntime.jsx(ui.Button, { variant: "secondary", size: "small", className: "w-full mb-3", onClick: onNewChat, children: "Start New Chat" }),
    /* @__PURE__ */ jsxRuntime.jsx(
      "div",
      {
        className: "space-y-1 flex-1 overflow-y-auto min-h-0 [&::-webkit-scrollbar]:hidden pt-4",
        style: {
          scrollbarWidth: "none",
          msOverflowStyle: "none"
        },
        children: conversations.length === 0 ? /* @__PURE__ */ jsxRuntime.jsx("div", { className: "text-sm text-muted-foreground px-2 py-4 text-center", children: "No conversations yet" }) : conversations.map((conv) => {
          const isSelected = currentConversationId === conv.id;
          return /* @__PURE__ */ jsxRuntime.jsxs(
            "button",
            {
              className: cn(
                "w-full flex items-center gap-2 px-2 py-1.5 rounded text-sm hover:bg-ui-bg-base-hover transition-colors",
                isSelected && "bg-muted"
              ),
              onClick: () => onConversationClick(conv.id),
              children: [
                isSelected && /* @__PURE__ */ jsxRuntime.jsx(icons.Check, { className: "w-4 h-4" }),
                !isSelected && /* @__PURE__ */ jsxRuntime.jsx("div", { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntime.jsx("span", { className: "flex-1 text-left", children: conv.summary || `Conversation ${conv.id}` })
              ]
            },
            conv.id
          );
        })
      }
    )
  ] });
}
function ChatSidebar({ currentAgentId, currentConversationId }) {
  const { dataset, isLoading: isDatasetLoading } = useActiveDataset();
  const dataSetId = (dataset == null ? void 0 : dataset.external_id) ?? null;
  const navigate = reactRouterDom.useNavigate();
  const [agents, setAgents] = React.useState([]);
  const [conversations, setConversations] = React.useState([]);
  const [isAgentsLoading, setIsAgentsLoading] = React.useState(true);
  React.useEffect(() => {
    if (isDatasetLoading || !dataSetId) return;
    const loadAgents = async () => {
      try {
        setIsAgentsLoading(true);
        const agentsRes = await adminApiClient.agents().getDatasetAgents(dataSetId);
        setAgents(agentsRes.filter((agent) => !agent.corrupted));
      } catch (error) {
        console.error("Failed to load agents:", error);
      } finally {
        setIsAgentsLoading(false);
      }
    };
    void loadAgents();
  }, [dataSetId, isDatasetLoading]);
  React.useEffect(() => {
    if (!dataSetId || !currentAgentId) return;
    const loadConversations = async () => {
      try {
        const conversationsRes = await adminApiClient.conversations().getConversations(dataSetId, currentAgentId, 1);
        setConversations(conversationsRes.results || []);
      } catch (error) {
        console.error("Failed to load conversations:", error);
      }
    };
    void loadConversations();
  }, [dataSetId, currentAgentId, currentConversationId]);
  const handleAgentClick = (agentId) => {
    navigate(`/enthusiast/chat/new?agent=${encodeURIComponent(agentId)}`);
  };
  const handleConversationClick = (conversationId) => {
    navigate(`/enthusiast/chat/${conversationId}`);
  };
  const handleNewChat = () => {
    navigate(`/enthusiast/chat/new?agent=${encodeURIComponent(currentAgentId)}`);
  };
  if (isAgentsLoading) {
    return /* @__PURE__ */ jsxRuntime.jsx(LoadingSpinner, {});
  }
  return /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "w-64 bg-background flex flex-col h-full overflow-hidden", children: [
    /* @__PURE__ */ jsxRuntime.jsx("div", { className: "px-2 pt-2 h-[40%] min-h-0 pb-4", children: /* @__PURE__ */ jsxRuntime.jsx(
      AgentList,
      {
        agents,
        currentAgentId,
        onAgentClick: handleAgentClick
      }
    ) }),
    /* @__PURE__ */ jsxRuntime.jsx("div", { className: "px-2 pb-2 h-[60%] min-h-0", children: /* @__PURE__ */ jsxRuntime.jsx(
      ConversationHistory,
      {
        conversations: conversations.slice(0, 10),
        currentConversationId,
        onConversationClick: handleConversationClick,
        onNewChat: handleNewChat
      }
    ) })
  ] });
}
const buttonVariants = classVarianceAuthority.cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
        destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
        outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline"
      },
      size: {
        default: "h-9 px-4 py-2",
        sm: "h-8 rounded-md px-3 text-xs",
        lg: "h-10 rounded-md px-8",
        icon: "h-9 w-9"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
const Button = React__namespace.forwardRef(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return /* @__PURE__ */ jsxRuntime.jsx(Comp, { className: cn(buttonVariants({ variant, size, className })), ref, ...props });
  }
);
Button.displayName = "Button";
function FileUpload({
  onFilesChange,
  uploadedFiles,
  onClose,
  disabled = false,
  showUploadArea = true,
  onUploadError
}) {
  const [dragActive, setDragActive] = React.useState(false);
  const [supportedExtensions, setSupportedExtensions] = React.useState([]);
  const [isLoadingExtensions, setIsLoadingExtensions] = React.useState(true);
  React.useEffect(() => {
    const fetchSupportedFileTypes = async () => {
      try {
        setIsLoadingExtensions(true);
        const result = await adminApiClient.conversations().getSupportedFileTypes();
        setSupportedExtensions(result.supported_extensions || []);
      } catch (error) {
        console.error("Failed to fetch supported file types:", error);
      } finally {
        setIsLoadingExtensions(false);
      }
    };
    void fetchSupportedFileTypes();
  }, []);
  const onDrop = React.useCallback(
    (acceptedFiles, rejectedFiles) => {
      if (disabled) return;
      if (rejectedFiles.length > 0) {
        const errors = rejectedFiles.map(({ file, errors: errors2 }) => ({
          file: file.name,
          errors: errors2.map((e) => e.message)
        }));
        if (onUploadError) {
          const errorMessages = errors.map(({ file, errors: errors2 }) => `${file}: ${errors2.join(", ")}`).join("; ");
          onUploadError(errorMessages);
        }
      }
      const newFiles = acceptedFiles.map((file) => ({
        id: Math.random().toString(36).substr(2, 9),
        file,
        preview: file.type.startsWith("image/") ? URL.createObjectURL(file) : void 0
      }));
      onClose();
      onFilesChange([...uploadedFiles, ...newFiles]);
    },
    [uploadedFiles, onFilesChange, disabled, onUploadError, onClose]
  );
  const acceptObject = supportedExtensions.reduce(
    (acc, ext) => {
      if (ext === ".txt") acc["text/plain"] = [];
      else if (ext === ".pdf") acc["application/pdf"] = [];
      else if (ext === ".jpg" || ext === ".jpeg") acc["image/jpeg"] = [];
      else if (ext === ".png") acc["image/png"] = [];
      return acc;
    },
    {}
  );
  const { getRootProps, getInputProps, isDragActive, open } = reactDropzone.useDropzone({
    onDrop,
    disabled: disabled || isLoadingExtensions,
    accept: isLoadingExtensions ? void 0 : acceptObject
  });
  return /* @__PURE__ */ jsxRuntime.jsxs(jsxRuntime.Fragment, { children: [
    /* @__PURE__ */ jsxRuntime.jsxs(
      Button,
      {
        type: "button",
        variant: "ghost",
        size: "icon",
        onClick: open,
        disabled,
        className: "shrink-0 left-2 bottom-2 absolute",
        children: [
          /* @__PURE__ */ jsxRuntime.jsx(lucideReact.Paperclip, { className: "h-4 w-4" }),
          /* @__PURE__ */ jsxRuntime.jsx("span", { className: "sr-only", children: "Attach files" })
        ]
      }
    ),
    /* @__PURE__ */ jsxRuntime.jsx("input", { ...getInputProps() }),
    showUploadArea && /* @__PURE__ */ jsxRuntime.jsx("div", { className: "space-y-3 absolute w-full h-full bg-background rounded-lg z-10", children: /* @__PURE__ */ jsxRuntime.jsxs(
      "div",
      {
        ...getRootProps(),
        className: cn(
          "relative h-full text-center flex flex-col justify-center transition-colors cursor-pointer",
          "hover:bg-muted focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
          isDragActive && "border-primary bg-primary/10",
          disabled && "opacity-50 cursor-not-allowed",
          dragActive && "border-primary bg-primary/10"
        ),
        onDragEnter: () => setDragActive(true),
        onDragLeave: () => setDragActive(false),
        children: [
          /* @__PURE__ */ jsxRuntime.jsx(lucideReact.Upload, { className: "mx-auto h-6 w-6 text-muted-foreground mb-2" }),
          /* @__PURE__ */ jsxRuntime.jsx("div", { className: "text-sm text-foreground", children: "Drag and drop files here" }),
          /* @__PURE__ */ jsxRuntime.jsx("div", { className: "text-xs text-muted-foreground mt-1", children: isLoadingExtensions ? "Loading supported file types..." : `Supported types: ${supportedExtensions.join(", ")}` })
        ]
      }
    ) })
  ] });
}
const getFileIcon$1 = (file) => {
  if (file.type.startsWith("image/")) {
    return /* @__PURE__ */ jsxRuntime.jsx(lucideReact.Image, { className: "h-4 w-4 text-muted-foreground" });
  }
  if (file.type.includes("pdf") || file.type.includes("text")) {
    return /* @__PURE__ */ jsxRuntime.jsx(lucideReact.FileText, { className: "h-4 w-4 text-muted-foreground" });
  }
  return /* @__PURE__ */ jsxRuntime.jsx(lucideReact.File, { className: "h-4 w-4 text-muted-foreground" });
};
const formatFileSize = (bytes) => {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
};
const fileStatus = (file) => {
  if (file.uploaded) {
    return "Ready";
  }
  if (file.uploading) {
    return "Uploading...";
  }
  if (file.uploadError) {
    return "Upload failed";
  }
  return "";
};
function FileList$1({ uploadedFiles, handleFileRemove, disabled = false }) {
  return /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex w-full gap-2 flex-wrap", children: uploadedFiles.length > 0 && uploadedFiles.map((uploadedFile) => /* @__PURE__ */ jsxRuntime.jsxs(
    "div",
    {
      className: "flex items-center justify-between px-3 py-2 bg-muted rounded-lg border border-input w-[260px]",
      children: [
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex items-center space-x-3 flex-1 min-w-0", children: [
          uploadedFile.preview ? /* @__PURE__ */ jsxRuntime.jsx(
            "img",
            {
              src: uploadedFile.preview,
              alt: uploadedFile.file.name,
              className: "h-8 w-8 object-cover rounded"
            }
          ) : /* @__PURE__ */ jsxRuntime.jsx("div", { className: "h-8 w-8 bg-muted-foreground/20 rounded flex items-center justify-center", children: getFileIcon$1(uploadedFile.file) }),
          /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex-1 min-w-0", children: [
            /* @__PURE__ */ jsxRuntime.jsx(
              "div",
              {
                className: `text-sm font-medium truncate ${uploadedFile.uploadError ? "text-destructive" : "text-foreground"}`,
                children: uploadedFile.file.name
              }
            ),
            /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "text-xs text-muted-foreground", children: [
              formatFileSize(uploadedFile.file.size),
              " • ",
              fileStatus(uploadedFile)
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntime.jsx(
          Button,
          {
            variant: "ghost",
            size: "sm",
            onClick: () => handleFileRemove(uploadedFile.id),
            disabled: disabled || uploadedFile.uploading,
            className: "h-8 w-8 p-0 hover:bg-destructive/10 hover:text-destructive ml-2",
            children: /* @__PURE__ */ jsxRuntime.jsx(lucideReact.X, { className: "h-4 w-4" })
          }
        )
      ]
    },
    uploadedFile.id
  )) });
}
const Textarea = React__namespace.forwardRef(
  ({ className, ...props }, ref) => {
    return /* @__PURE__ */ jsxRuntime.jsx(
      "textarea",
      {
        className: cn(
          "flex min-h-[60px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
          className
        ),
        ref,
        ...props
      }
    );
  }
);
Textarea.displayName = "Textarea";
const maxHeight = 300;
function MessageComposer({
  onSubmit,
  isLoading,
  conversationLocked = false,
  conversationId,
  agentId,
  fileUploadEnabled
}) {
  const [input, setInput] = React.useState("");
  const [uploadedFiles, setUploadedFiles] = React.useState([]);
  const [showUploadArea, setShowUploadArea] = React.useState(false);
  const [uploadingFiles, setUploadingFiles] = React.useState(false);
  const [uploadError, setUploadError] = React.useState(null);
  const createdConversationIdRef = React.useRef(null);
  const inputRef = React.useRef(null);
  const inputLength = input.trim().length;
  React.useEffect(() => {
    const handleDragOver = (e) => {
      e.preventDefault();
      if (!fileUploadEnabled || isLoading || conversationLocked || showUploadArea) {
        return;
      }
      setShowUploadArea(true);
    };
    const handleDragEnd = () => {
      setShowUploadArea(false);
    };
    const handleDragLeave = (e) => {
      e.preventDefault();
      if (e.relatedTarget && e.relatedTarget !== document.documentElement) {
        return;
      }
      handleDragEnd();
    };
    document.body.addEventListener("dragover", handleDragOver);
    document.body.addEventListener("dragleave", handleDragLeave);
    document.body.addEventListener("dragend", handleDragEnd);
    window.addEventListener("blur", () => handleDragEnd);
    return () => {
      document.body.removeEventListener("dragover", handleDragOver);
      document.body.removeEventListener("dragleave", handleDragLeave);
      document.body.removeEventListener("dragend", handleDragEnd);
      window.removeEventListener("blur", handleDragEnd);
    };
  }, []);
  const resizeTextArea = (element) => {
    if (!element) {
      return;
    }
    element.style.height = "0px";
    element.style.height = `${Math.min(element.scrollHeight, maxHeight)}px`;
  };
  const uploadFile = async (file, conversationId2) => {
    const uploadResponse = await adminApiClient.conversations().uploadFile(conversationId2, file);
    return uploadResponse.task_id;
  };
  const pollUploadStatus = async (taskId) => {
    var _a;
    const maxAttempts = 30;
    let attempts = 0;
    while (attempts < maxAttempts) {
      const statusData = await adminApiClient.conversations().getFileUploadStatus(taskId);
      if (statusData.status === "SUCCESS") {
        return statusData.result.file_id;
      } else if (statusData.status === "FAILURE") {
        throw new Error(((_a = statusData.result) == null ? void 0 : _a.error) || "Upload failed");
      }
      await new Promise((resolve) => setTimeout(resolve, 1e3));
      attempts++;
    }
    throw new Error("Upload timeout - please try again");
  };
  const resetComposer = () => {
    setInput("");
    setUploadedFiles([]);
    setShowUploadArea(false);
    setUploadError(null);
    createdConversationIdRef.current = null;
    setTimeout(() => {
      resizeTextArea(inputRef.current);
    });
  };
  const submitMessage = async () => {
    if (inputLength === 0) return;
    const allFilesReady = uploadedFiles.every((f) => f.uploaded && f.fileId);
    const hasUploadingFiles = uploadedFiles.some((f) => f.uploading);
    const hasErrors = uploadedFiles.some((f) => f.uploadError);
    if (uploadedFiles.length > 0 && !allFilesReady) {
      if (hasUploadingFiles) {
        setUploadError("Please wait for all files to finish uploading.");
      } else if (hasErrors) {
        setUploadError("Please fix upload errors before sending.");
      }
      return;
    }
    if (!uploadedFiles.length) {
      onSubmit({ text: input, files: [] }, createdConversationIdRef.current || void 0);
      resetComposer();
      return;
    }
    try {
      setUploadingFiles(true);
      const message2 = {
        text: input,
        files: uploadedFiles.filter((f) => f.uploaded && f.fileId).map((f) => ({
          id: f.fileId,
          name: f.file.name,
          type: f.file.name.includes(".") ? f.file.name.split(".").pop() : ""
        }))
      };
      onSubmit(message2, createdConversationIdRef.current || void 0);
      resetComposer();
    } catch {
      setUploadError("Failed to send message. Please try again.");
    } finally {
      setUploadingFiles(false);
    }
  };
  const handleTextAreaInput = (event) => {
    setInput(event.target.value);
    resizeTextArea(event.target);
  };
  const handleTextAreaKeyDown = (event) => {
    if (event.shiftKey || event.key !== "Enter") return;
    event.preventDefault();
    void submitMessage();
  };
  const handleFilesChange = async (files) => {
    setUploadedFiles(files.map((f) => ({ ...f, uploading: true, uploadError: void 0 })));
    let currentConversationId = conversationId || createdConversationIdRef.current;
    if (!currentConversationId && agentId) {
      currentConversationId = await adminApiClient.conversations().createConversation(agentId);
      createdConversationIdRef.current = currentConversationId;
    }
    if (!currentConversationId) {
      throw new Error("No conversation ID available for file upload");
    }
    const uploadPromises = files.map(async (file) => {
      try {
        const taskId = await uploadFile(file.file, currentConversationId);
        setUploadedFiles(
          (prev) => prev.map((f) => f.id === file.id ? { ...f, taskId, uploading: true } : f)
        );
        const fileId = await pollUploadStatus(taskId);
        setUploadedFiles(
          (prev) => prev.map(
            (f) => f.id === file.id ? { ...f, uploaded: true, fileId, uploading: false } : f
          )
        );
      } catch {
        setUploadedFiles(
          (prev) => prev.map(
            (f) => f.id === file.id ? { ...f, uploading: false, uploadError: "Upload failed" } : f
          )
        );
      }
    });
    await Promise.all(uploadPromises);
  };
  const handleFileRemove = (fileId) => {
    setUploadedFiles((prev) => {
      const newFiles = prev.filter((f) => f.id !== fileId);
      if (newFiles.length === 0) {
        setShowUploadArea(false);
      }
      return newFiles;
    });
    setUploadError(null);
  };
  React.useEffect(() => {
    var _a;
    if (!isLoading) {
      (_a = inputRef.current) == null ? void 0 : _a.focus();
    }
  }, [isLoading]);
  return /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "space-y-3", children: [
    uploadError && /* @__PURE__ */ jsxRuntime.jsx("div", { className: "bg-red-50 border border-red-200 rounded-lg p-3", children: /* @__PURE__ */ jsxRuntime.jsx("div", { className: "text-sm text-red-600", children: uploadError }) }),
    /* @__PURE__ */ jsxRuntime.jsx(
      FileList$1,
      {
        uploadedFiles,
        handleFileRemove,
        disabled: isLoading || uploadingFiles || conversationLocked
      }
    ),
    /* @__PURE__ */ jsxRuntime.jsx(
      "form",
      {
        onSubmit: (event) => {
          event.preventDefault();
          void submitMessage();
        },
        className: "flex w-full items-center space-x-2 relative",
        children: /* @__PURE__ */ jsxRuntime.jsxs(
          "div",
          {
            className: cn(
              "relative flex-1 rounded-md border bg-background",
              showUploadArea && "border-dashed"
            ),
            children: [
              fileUploadEnabled && /* @__PURE__ */ jsxRuntime.jsx(
                FileUpload,
                {
                  onFilesChange: (files) => {
                    void handleFilesChange(files);
                  },
                  uploadedFiles,
                  disabled: isLoading || uploadingFiles || conversationLocked,
                  onClose: () => setShowUploadArea(false),
                  showUploadArea,
                  onUploadError: setUploadError
                }
              ),
              /* @__PURE__ */ jsxRuntime.jsx(
                Textarea,
                {
                  id: "message",
                  ref: inputRef,
                  placeholder: conversationLocked ? "This agent is no longer available." : "Type your message...",
                  className: "w-full resize-none border-0 focus-visible:ring-0 focus-visible:outline-none shadow-none pt-3",
                  autoComplete: "off",
                  value: input,
                  onChange: handleTextAreaInput,
                  onKeyDown: handleTextAreaKeyDown,
                  disabled: isLoading || uploadingFiles || conversationLocked
                }
              ),
              /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex", children: /* @__PURE__ */ jsxRuntime.jsxs(
                Button,
                {
                  type: "submit",
                  size: "icon",
                  className: "ml-auto mr-2 mb-2",
                  disabled: isLoading || uploadingFiles || inputLength === 0 || conversationLocked || uploadedFiles.some((f) => f.uploading || f.uploadError),
                  children: [
                    isLoading || uploadingFiles ? /* @__PURE__ */ jsxRuntime.jsx(icons.Loader, { className: "h-4 w-4 animate-spin text-muted-foreground" }) : /* @__PURE__ */ jsxRuntime.jsx(lucideReact.Send, { className: "h-4 w-4" }),
                    /* @__PURE__ */ jsxRuntime.jsx("span", { className: "sr-only", children: "Send" })
                  ]
                }
              ) })
            ]
          }
        )
      }
    )
  ] });
}
function ChatWindow({
  children,
  className,
  onSubmit,
  isLoading,
  conversationLocked,
  conversationId,
  agentId,
  fileUploadEnabled
}) {
  return /* @__PURE__ */ jsxRuntime.jsxs("div", { className: cn("flex flex-col min-h-0", className), children: [
    /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex-1 min-h-0 overflow-y-auto px-4 pt-[18px]", children }),
    /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex-shrink-0 w-full px-8 pt-[18px] pb-[18px] bg-background", children: /* @__PURE__ */ jsxRuntime.jsx(
      MessageComposer,
      {
        onSubmit,
        isLoading,
        conversationLocked,
        conversationId,
        agentId,
        fileUploadEnabled
      }
    ) })
  ] });
}
function BaseBubble({
  variant,
  children,
  className,
  hasBackground = false,
  inMessageGroup
}) {
  return /* @__PURE__ */ jsxRuntime.jsx("div", { className: cn("flex", inMessageGroup && "mt-2"), children: /* @__PURE__ */ jsxRuntime.jsx(
    "div",
    {
      className: cn(
        "flex flex-col max-w-[75%] gap-2 rounded-lg px-3 py-2 text-sm",
        variant === "primary" && "ml-auto",
        hasBackground && variant === "primary" && "bg-[#F4F4F5] dark:bg-[#2A2D31] text-foreground",
        hasBackground && variant === "secondary" && "bg-muted",
        className
      ),
      children
    }
  ) });
}
function FeedbackButton({ isOpen, onClick }) {
  return /* @__PURE__ */ jsxRuntime.jsxs(Button, { onClick, variant: "ghost", children: [
    "Provide feedback for this response",
    isOpen ? /* @__PURE__ */ jsxRuntime.jsx(lucideReact.ChevronUpIcon, {}) : /* @__PURE__ */ jsxRuntime.jsx(lucideReact.ChevronDownIcon, {})
  ] });
}
function CopyToClipboardButton({ message: message2, variant }) {
  const [isCopied, setIsCopied] = React.useState(false);
  const handleCopyClick = async () => {
    await navigator.clipboard.writeText(message2);
    setIsCopied(true);
    setTimeout(() => {
      setIsCopied(false);
    }, 2e3);
  };
  return /* @__PURE__ */ jsxRuntime.jsxs(
    Button,
    {
      onClick: () => {
        void handleCopyClick();
      },
      variant,
      children: [
        /* @__PURE__ */ jsxRuntime.jsx(lucideReact.CopyIcon, {}),
        isCopied ? "Copied!" : "Copy"
      ]
    }
  );
}
var NAME = "Label";
var Label$1 = React__namespace.forwardRef((props, forwardedRef) => {
  return /* @__PURE__ */ jsxRuntime.jsx(
    Primitive.label,
    {
      ...props,
      ref: forwardedRef,
      onMouseDown: (event) => {
        var _a;
        const target = event.target;
        if (target.closest("button, input, select, textarea")) return;
        (_a = props.onMouseDown) == null ? void 0 : _a.call(props, event);
        if (!event.defaultPrevented && event.detail > 1) event.preventDefault();
      }
    }
  );
});
Label$1.displayName = NAME;
var Root = Label$1;
const labelVariants = classVarianceAuthority.cva(
  "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
);
const Label = React__namespace.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntime.jsx(Root, { ref, className: cn(labelVariants(), className), ...props }));
Label.displayName = Root.displayName;
const alertVariants = classVarianceAuthority.cva(
  "relative w-full rounded-lg border px-4 py-3 text-sm [&>svg+div]:translate-y-[-3px] [&>svg]:absolute [&>svg]:left-4 [&>svg]:top-4 [&>svg]:text-foreground [&>svg~*]:pl-7",
  {
    variants: {
      variant: {
        default: "bg-background text-foreground",
        destructive: "border-destructive/50 text-destructive dark:border-destructive [&>svg]:text-destructive"
      }
    },
    defaultVariants: {
      variant: "default"
    }
  }
);
const Alert = React__namespace.forwardRef(({ className, variant, ...props }, ref) => /* @__PURE__ */ jsxRuntime.jsx("div", { ref, role: "alert", className: cn(alertVariants({ variant }), className), ...props }));
Alert.displayName = "Alert";
const AlertTitle = React__namespace.forwardRef(
  ({ className, ...props }, ref) => (
    // eslint-disable-next-line jsx-a11y/heading-has-content
    /* @__PURE__ */ jsxRuntime.jsx(
      "h5",
      {
        ref,
        className: cn("mb-1 font-medium leading-none tracking-tight", className),
        ...props
      }
    )
  )
);
AlertTitle.displayName = "AlertTitle";
const AlertDescription = React__namespace.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntime.jsx("div", { ref, className: cn("text-sm [&_p]:leading-relaxed", className), ...props }));
AlertDescription.displayName = "AlertDescription";
const values = [
  { value: 1, label: "Poor" },
  { value: 2, label: "Fair" },
  { value: 3, label: "Good" },
  { value: 4, label: "Very Good" },
  { value: 5, label: "Excellent" }
];
function MessageFeedbackRating({
  onRatingChange,
  rating,
  disabled
}) {
  const classNamesForButton = (value) => {
    if (value === rating) {
      return "border border-black";
    }
    return "";
  };
  return /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex space-x-2", children: values.map(({ value, label }) => /* @__PURE__ */ jsxRuntime.jsx(
    Button,
    {
      variant: "outline",
      disabled,
      type: "button",
      className: classNamesForButton(value),
      onClick: () => onRatingChange(value),
      children: label
    },
    value
  )) });
}
function MessageFeedbackForm({ messageId }, { className, ...props }) {
  const [isLoading, setIsLoading] = React.useState(false);
  const [isError, setIsError] = React.useState(false);
  const [rating, setRating] = React.useState(null);
  const [feedback, setFeedback] = React.useState("");
  const [isSubmitted, setIsSubmitted] = React.useState(false);
  async function onSubmit(event) {
    event.preventDefault();
    setIsLoading(true);
    const feedbackData = {
      rating,
      feedback
    };
    try {
      await adminApiClient.conversations().updateMessageFeedback(messageId, feedbackData);
      setIsSubmitted(true);
    } catch {
      setIsError(true);
    } finally {
      setIsLoading(false);
    }
  }
  return /* @__PURE__ */ jsxRuntime.jsx("div", { className: cn("grid gap-6", className), ...props, children: /* @__PURE__ */ jsxRuntime.jsx(
    "form",
    {
      onSubmit: (e) => {
        void onSubmit(e);
      },
      children: /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "grid gap-4", children: [
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "grid gap-1", children: [
          isError && /* @__PURE__ */ jsxRuntime.jsxs(Alert, { variant: "destructive", children: [
            /* @__PURE__ */ jsxRuntime.jsx(AlertTitle, { children: "There was an error submitting your feedback." }),
            /* @__PURE__ */ jsxRuntime.jsx(AlertDescription, { children: "Please contact user support." })
          ] }),
          /* @__PURE__ */ jsxRuntime.jsx(Label, { className: "sr-only", htmlFor: "rating", children: "Rating" }),
          /* @__PURE__ */ jsxRuntime.jsx(
            MessageFeedbackRating,
            {
              disabled: isSubmitted,
              rating,
              onRatingChange: setRating
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "grid gap-2", children: [
          /* @__PURE__ */ jsxRuntime.jsx(Label, { htmlFor: "feedback", children: "Your Feedback" }),
          /* @__PURE__ */ jsxRuntime.jsx(
            Textarea,
            {
              disabled: isSubmitted,
              onChange: (event) => setFeedback(event.target.value),
              className: "bg-white",
              placeholder: "Type your feedback here."
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntime.jsx(Button, { disabled: isLoading || isSubmitted, type: "submit", children: isSubmitted ? /* @__PURE__ */ jsxRuntime.jsx(jsxRuntime.Fragment, { children: "Thank you for your feedback!" }) : /* @__PURE__ */ jsxRuntime.jsxs(jsxRuntime.Fragment, { children: [
          isLoading && /* @__PURE__ */ jsxRuntime.jsx(LoadingSpinner, {}),
          "Submit Feedback"
        ] }) })
      ] })
    }
  ) });
}
function MessageBubble({ text, variant, questionId, inMessageGroup }) {
  const [sanitizedHtml, setSanitizedHtml] = React.useState("");
  const [isFeedbackOpen, setIsFeedbackOpen] = React.useState(false);
  React.useEffect(() => {
    const processText = async () => {
      const { marked } = await import("marked");
      const rawHtml = await marked(text);
      const cleanHtml = DOMPurify__default.default.sanitize(rawHtml);
      setSanitizedHtml(cleanHtml);
    };
    void processText();
  }, [text]);
  const shouldShowActionButtons = variant === "secondary" && questionId !== null && text;
  const handleFeedbackClick = () => {
    setIsFeedbackOpen((prev) => !prev);
  };
  return /* @__PURE__ */ jsxRuntime.jsxs(BaseBubble, { variant, hasBackground: true, inMessageGroup, children: [
    text && /* @__PURE__ */ jsxRuntime.jsx("div", { className: variant, dangerouslySetInnerHTML: { __html: sanitizedHtml } }),
    shouldShowActionButtons && /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "mt-4 flex items-center", children: [
      /* @__PURE__ */ jsxRuntime.jsx(FeedbackButton, { isOpen: isFeedbackOpen, onClick: handleFeedbackClick }),
      /* @__PURE__ */ jsxRuntime.jsx(CopyToClipboardButton, { message: text, variant: "ghost" })
    ] }),
    isFeedbackOpen && /* @__PURE__ */ jsxRuntime.jsx("div", { className: "feedback-form-modal mx-4", children: /* @__PURE__ */ jsxRuntime.jsx(MessageFeedbackForm, { messageId: questionId }) })
  ] });
}
const getFileIcon = (contentType) => {
  if (contentType.startsWith("image/")) {
    return /* @__PURE__ */ jsxRuntime.jsx(lucideReact.Image, { className: "h-5 w-5 text-muted-foreground" });
  }
  if (contentType.includes("pdf") || contentType.includes("text")) {
    return /* @__PURE__ */ jsxRuntime.jsx(lucideReact.FileText, { className: "h-5 w-5 text-muted-foreground" });
  }
  return /* @__PURE__ */ jsxRuntime.jsx(lucideReact.File, { className: "h-5 w-5 text-muted-foreground" });
};
function AttachmentBubble({ variant, message: message2, inMessageGroup }) {
  return /* @__PURE__ */ jsxRuntime.jsx(
    BaseBubble,
    {
      variant,
      hasBackground: false,
      className: "px-0 py-0 min-w-[25%]",
      inMessageGroup,
      children: /* @__PURE__ */ jsxRuntime.jsxs(
        "div",
        {
          className: `flex items-center space-x-2 rounded-md border border-input bg-background shadow-sm px-3 py-2`,
          children: [
            /* @__PURE__ */ jsxRuntime.jsx("div", { className: "h-8 w-8 bg-muted rounded flex items-center justify-center", children: getFileIcon(message2.file_type) }),
            /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex-1 min-w-0", children: [
              /* @__PURE__ */ jsxRuntime.jsx("div", { className: "text-sm font-medium truncate text-foreground", children: message2.file_name }),
              /* @__PURE__ */ jsxRuntime.jsx("div", { className: "text-xs text-muted-foreground", children: message2.file_type })
            ] })
          ]
        }
      )
    }
  );
}
function MessageError({ text }) {
  return /* @__PURE__ */ jsxRuntime.jsx("div", { className: "text-red-600 text-center", children: text });
}
const typing = "_typing_iirkk_1";
const typingDot = "_typingDot_iirkk_6";
const styles = {
  typing,
  typingDot
};
function MessageBubbleTyping({ text }) {
  return /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex flex-col", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { className: cn("items-centered rounded-lg px-3 py-4 text-sm", styles.typing), children: [
      /* @__PURE__ */ jsxRuntime.jsx("div", { className: styles.typingDot }),
      /* @__PURE__ */ jsxRuntime.jsx("div", { className: styles.typingDot }),
      /* @__PURE__ */ jsxRuntime.jsx("div", { className: styles.typingDot })
    ] }),
    text && /* @__PURE__ */ jsxRuntime.jsx("p", { className: "text-sm ml-2 -mt-1 text-muted-foreground", children: text })
  ] });
}
const isUserMessage = (message2) => message2.type === "human" || message2.type === "file";
function MessageList({
  messages,
  agentAction,
  isAgentLoading,
  lastMessageRef
}) {
  return /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "grow flex-1 space-y-4", children: [
    messages.map((message2, index) => {
      const inMessageGroup = isUserMessage(message2) && index > 0 && isUserMessage(messages[index - 1]);
      if (message2.type === "system") {
        return /* @__PURE__ */ jsxRuntime.jsx(MessageError, { text: message2.text }, index);
      }
      if (message2.type === "file") {
        return /* @__PURE__ */ jsxRuntime.jsx(
          AttachmentBubble,
          {
            variant: "primary",
            message: message2,
            inMessageGroup
          },
          index
        );
      }
      if (message2.type === "ai" && message2.text === "") {
        return /* @__PURE__ */ jsxRuntime.jsx(MessageBubbleTyping, { text: agentAction }, index);
      }
      return /* @__PURE__ */ jsxRuntime.jsx(
        MessageBubble,
        {
          text: message2.text,
          variant: message2.type === "human" ? "primary" : "secondary",
          questionId: message2.id,
          inMessageGroup
        },
        index
      );
    }),
    isAgentLoading && !messages.some((msg) => msg.type === "ai" && msg.text === "") && /* @__PURE__ */ jsxRuntime.jsx(MessageBubbleTyping, { text: agentAction }),
    /* @__PURE__ */ jsxRuntime.jsx("div", { className: "mb-4" }),
    /* @__PURE__ */ jsxRuntime.jsx("div", { ref: lastMessageRef })
  ] });
}
function PageHeading({ title, description, className, children }) {
  return /* @__PURE__ */ jsxRuntime.jsx("div", { className: cn("pb-4", className), children: /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex", children: [
    /* @__PURE__ */ jsxRuntime.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntime.jsx("h3", { className: "text-lg font-medium", children: title }),
      description && /* @__PURE__ */ jsxRuntime.jsx("p", { className: "text-sm text-muted-foreground", children: description })
    ] }),
    children
  ] }) });
}
function PageMain({ children, className }) {
  return /* @__PURE__ */ jsxRuntime.jsx(ui.Container, { className: cn("flex flex-col divide-y p-0 pt-4 h-full overflow-hidden", className), children });
}
function useConversation(dataSetId) {
  const { chatId } = reactRouterDom.useParams();
  const location = reactRouterDom.useLocation();
  const navigate = reactRouterDom.useNavigate();
  const isNew = chatId === "new";
  const conversationId = !isNew && chatId ? parseInt(chatId, 10) : void 0;
  const queryParams = new URLSearchParams(location.search);
  const agentIdFromUrl = queryParams.get("agent") ? parseInt(queryParams.get("agent"), 10) : void 0;
  const locationState = location.state;
  const pendingMessage = locationState == null ? void 0 : locationState.pendingMessage;
  const [conversation, setConversation] = React.useState(null);
  const [isContentLoading, setIsContentLoading] = React.useState(!isNew);
  const [isLoading, setIsLoading] = React.useState(false);
  const [isAgentLoading, setIsAgentLoading] = React.useState(false);
  const [agentAction, setAgentAction] = React.useState("Thinking...");
  const [messages, setMessages] = React.useState([]);
  const [agentId, setAgentId] = React.useState(agentIdFromUrl);
  const [agentDetails, setAgentDetails] = React.useState();
  const usePolling = React.useRef(true);
  const streamingEnabled = React.useRef(false);
  const initialized = React.useRef(false);
  const currentTaskHandleRef = React.useRef(null);
  const lastAddedMessageIdRef = React.useRef(null);
  const lastMessageRef = React.useRef(null);
  const abortStreamRef = React.useRef(null);
  const isAgentDeleted = !!(conversation == null ? void 0 : conversation.agent.deleted_at);
  const isAgentCorrupted = !!(conversation == null ? void 0 : conversation.agent.corrupted);
  const scrollToLastMessage = (timeout = 0) => {
    setTimeout(() => {
      var _a;
      (_a = lastMessageRef.current) == null ? void 0 : _a.scrollIntoView({ behavior: "smooth" });
    }, timeout);
  };
  React.useEffect(() => {
    return () => {
      if (abortStreamRef.current) {
        abortStreamRef.current();
        abortStreamRef.current = null;
      }
    };
  }, []);
  React.useEffect(() => {
    if (abortStreamRef.current) {
      abortStreamRef.current();
      abortStreamRef.current = null;
    }
    initialized.current = false;
    currentTaskHandleRef.current = null;
    lastAddedMessageIdRef.current = null;
    setMessages([]);
    setConversation(null);
    setAgentDetails(void 0);
    if (isNew) {
      setAgentId(agentIdFromUrl);
      setIsContentLoading(false);
      return;
    }
    setIsContentLoading(true);
    const checkStream = async () => {
      try {
        const streamStatus = await adminApiClient.conversations().getStreamStatus();
        streamingEnabled.current = streamStatus.active;
      } catch {
        streamingEnabled.current = false;
      }
    };
    const loadMessages = async () => {
      var _a;
      const conv = await adminApiClient.conversations().getConversation(conversationId);
      if (String(conv.agent.dataset) !== String(dataSetId)) {
        ui.toast.error("Conversation not found.", {
          description: "This conversation does not belong to the active dataset.",
          position: "top-right"
        });
        navigate("/enthusiast", { replace: true });
        return;
      }
      setConversation(conv);
      setAgentId((_a = conv.agent) == null ? void 0 : _a.id);
      if (pendingMessage && !initialized.current) {
        initialized.current = true;
        setIsContentLoading(false);
        void onMessageComposerSubmit(pendingMessage);
        return;
      }
      const initialMessages = conv.history;
      setMessages(initialMessages);
      setIsContentLoading(false);
      scrollToLastMessage(100);
    };
    void (async () => {
      await checkStream();
      await loadMessages();
    })();
  }, [chatId]);
  React.useEffect(() => {
    if (!isNew || agentIdFromUrl === void 0) return;
    setAgentId(agentIdFromUrl);
    setAgentDetails(void 0);
    setIsContentLoading(true);
  }, [isNew, agentIdFromUrl]);
  React.useEffect(() => {
    if (!agentId || agentDetails) return;
    const loadAgentDetails = async () => {
      try {
        const details = await adminApiClient.agents().getAgentById(agentId);
        setAgentDetails(details);
      } catch (error) {
        console.error("Failed to load agent details:", error);
      } finally {
        setIsContentLoading(false);
      }
    };
    void loadAgentDetails();
  }, [agentId, agentDetails]);
  const handleSseMessage = (eventType, payload) => {
    const handlers = {
      on_parser_start: () => {
        setIsAgentLoading(true);
      },
      on_parser_stream: () => {
        const chunk = payload == null ? void 0 : payload.chunk;
        if (chunk === void 0 || chunk === null) {
          console.warn("Missing chunk in payload:", payload);
          return;
        }
        const chunkStr = String(chunk);
        setIsLoading(false);
        if (chunkStr.trim().length > 0) {
          setIsAgentLoading(false);
        }
        setMessages((prevMessages) => {
          const lastMessage = prevMessages[prevMessages.length - 1];
          if (lastMessage && lastMessage.type === "ai" && lastMessage.id === null) {
            return [
              ...prevMessages.slice(0, -1),
              { ...lastMessage, text: lastMessage.text + chunkStr }
            ];
          } else {
            return [...prevMessages, { type: "ai", text: chunkStr, id: null }];
          }
        });
        scrollToLastMessage();
      },
      message_id: () => {
        setMessages((prevMessages) => {
          const lastMessage = prevMessages[prevMessages.length - 1];
          lastMessage.id = payload.output;
          return [...prevMessages.slice(0, -1), lastMessage];
        });
      },
      action: () => {
        setAgentAction(payload.output || "Thinking...");
        setIsAgentLoading(true);
      },
      error: () => {
        setIsLoading(false);
        setIsAgentLoading(false);
        setMessages((prevMessages) => [
          ...prevMessages,
          { type: "system", text: payload.output || "An error occurred", id: null }
        ]);
      }
    };
    const handler = handlers[eventType];
    if (handler) {
      handler();
    }
  };
  const createSseConnection = async (convId) => {
    try {
      if (abortStreamRef.current) {
        abortStreamRef.current();
        abortStreamRef.current = null;
      }
      const { stream, abort } = await enthusiastAdminSdk.client.fetchStream(
        `/enthusiast/conversations/${convId}/stream`
      );
      if (!stream) {
        usePolling.current = true;
        return false;
      }
      abortStreamRef.current = abort;
      const processEvent = async (stream2) => {
        try {
          for await (const chunk of stream2) {
            const eventType = chunk.event;
            const eventData = chunk.data;
            if (!eventType || !eventData || eventData.length === 0) {
              continue;
            }
            const dataObj = JSON.parse(eventData);
            handleSseMessage(eventType, dataObj);
          }
        } catch (error) {
          if (error instanceof Error && error.name !== "AbortError") {
            console.error("SSE stream error:", error);
            usePolling.current = true;
          }
        } finally {
          abortStreamRef.current = null;
        }
      };
      await processEvent(stream);
      return true;
    } catch (error) {
      console.error("Failed to create SSE connection:", error);
      usePolling.current = true;
      return false;
    }
  };
  const updateTaskStatus = async (convId, taskHandle, streaming) => {
    var _a;
    if (streaming) return;
    if (((_a = currentTaskHandleRef.current) == null ? void 0 : _a.task_id) !== taskHandle.task_id) return;
    try {
      const response = await adminApiClient.conversations().fetchResponseMessage(convId, taskHandle);
      if (response) {
        if (response.id && response.id === lastAddedMessageIdRef.current) {
          setIsAgentLoading(false);
          setIsLoading(false);
          return;
        }
        setIsAgentLoading(false);
        setMessages((prev) => {
          const messageExists = prev.some((msg) => msg.type === "ai" && msg.id === response.id);
          if (messageExists) return prev;
          return [...prev, { type: "ai", text: response.text, id: response.id }];
        });
        if (response.id) {
          lastAddedMessageIdRef.current = response.id;
        }
        setIsLoading(false);
        scrollToLastMessage();
      } else {
        setTimeout(() => {
          void updateTaskStatus(convId, taskHandle, streaming);
        }, 2e3);
      }
    } catch {
      setIsLoading(false);
      setIsAgentLoading(false);
    }
  };
  const onMessageComposerSubmit = async (message2) => {
    const convId = conversationId;
    setIsLoading(true);
    setIsAgentLoading(true);
    setMessages((prev) => {
      const messageExists = prev.some(
        (msg) => msg.type === "human" && msg.text === message2.text && msg.id === null
      );
      if (!messageExists) {
        const fileMessages = message2.files.map((file) => ({
          id: null,
          type: "file",
          file_name: file.name,
          file_type: file.type
        }));
        return [
          ...prev,
          ...fileMessages,
          { type: "human", text: message2.text, id: null }
        ];
      }
      return prev;
    });
    scrollToLastMessage(100);
    const taskHandle = await adminApiClient.conversations().sendMessage(
      convId,
      dataSetId,
      message2.text,
      streamingEnabled.current,
      message2.files.map((f) => f.id)
    );
    currentTaskHandleRef.current = taskHandle;
    usePolling.current = !taskHandle.streaming;
    if (pendingMessage && message2.text === pendingMessage.text) {
      navigate(`/enthusiast/chat/${convId}`, { replace: true, state: {} });
    }
    if (taskHandle.streaming) {
      const connected = await createSseConnection(convId);
      if (!connected) {
        usePolling.current = true;
      }
    }
    try {
      void updateTaskStatus(convId, taskHandle, !usePolling);
    } catch {
      setIsLoading(false);
      setIsAgentLoading(false);
    }
  };
  const onSubmitNewChat = (message2, createdConversationId) => {
    void (async () => {
      const newConversationId = createdConversationId ?? await adminApiClient.conversations().createConversation(agentId);
      navigate(`/enthusiast/chat/${newConversationId}`, {
        state: { pendingMessage: message2 },
        replace: true
      });
    })();
  };
  return {
    isNew,
    conversationId,
    agentIdFromUrl,
    agentId,
    agentDetails,
    conversation,
    messages,
    isContentLoading,
    isLoading,
    isAgentLoading,
    agentAction,
    isAgentDeleted,
    isAgentCorrupted,
    lastMessageRef,
    onMessageComposerSubmit,
    onSubmitNewChat
  };
}
const ContentSpinner = () => /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex flex-1 items-center justify-center", children: /* @__PURE__ */ jsxRuntime.jsx(icons.Spinner, { className: "text-ui-fg-interactive animate-spin" }) });
function ChatSession({ datasetId }) {
  const {
    isNew,
    conversationId,
    agentIdFromUrl,
    agentId,
    agentDetails,
    conversation,
    messages,
    isContentLoading,
    isLoading,
    isAgentLoading,
    agentAction,
    isAgentDeleted,
    isAgentCorrupted,
    lastMessageRef,
    onMessageComposerSubmit,
    onSubmitNewChat
  } = useConversation(datasetId);
  if (isNew && !agentIdFromUrl) {
    ui.toast.info("No agent.", { description: "Choose an agent to start a chat." });
    return /* @__PURE__ */ jsxRuntime.jsx(reactRouterDom.Navigate, { to: "/enthusiast", replace: true });
  }
  return /* @__PURE__ */ jsxRuntime.jsxs("div", { className: "flex h-screen overflow-hidden", children: [
    /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex-1 flex flex-col min-w-0 overflow-hidden px-1 py-2", children: /* @__PURE__ */ jsxRuntime.jsx(PageMain, { className: "h-full", children: isContentLoading ? /* @__PURE__ */ jsxRuntime.jsx(ContentSpinner, {}) : isNew ? /* @__PURE__ */ jsxRuntime.jsxs(jsxRuntime.Fragment, { children: [
      /* @__PURE__ */ jsxRuntime.jsx(
        PageHeading,
        {
          title: (agentDetails == null ? void 0 : agentDetails.name) || "",
          description: "Start a new conversation.",
          className: "flex-shrink-0 bg-background z-[1] px-8"
        }
      ),
      /* @__PURE__ */ jsxRuntime.jsx(
        ChatWindow,
        {
          className: "flex-1 min-h-0 pt-4",
          onSubmit: onSubmitNewChat,
          isLoading: false,
          agentId,
          fileUploadEnabled: agentDetails == null ? void 0 : agentDetails.file_upload,
          children: /* @__PURE__ */ jsxRuntime.jsx("div", { className: "grow flex items-start justify-center pt-16", children: (agentDetails == null ? void 0 : agentDetails.description) && /* @__PURE__ */ jsxRuntime.jsx("div", { className: "text-center space-y-4 max-w-2xl px-6", children: /* @__PURE__ */ jsxRuntime.jsx("div", { className: "bg-background rounded-lg p-6", children: /* @__PURE__ */ jsxRuntime.jsx("p", { className: "text-gray-500 text-base leading-relaxed", children: agentDetails.description }) }) }) })
        },
        `new-${agentId}`
      )
    ] }) : conversation && /* @__PURE__ */ jsxRuntime.jsxs(jsxRuntime.Fragment, { children: [
      /* @__PURE__ */ jsxRuntime.jsx(
        PageHeading,
        {
          title: (agentDetails == null ? void 0 : agentDetails.name) || "",
          description: agentDetails == null ? void 0 : agentDetails.description,
          className: "flex-shrink-0 bg-background z-[1] px-8"
        }
      ),
      /* @__PURE__ */ jsxRuntime.jsx(
        ChatWindow,
        {
          className: "flex-1 min-h-0",
          onSubmit: (message2) => void onMessageComposerSubmit(message2),
          isLoading,
          conversationLocked: isAgentDeleted || isAgentCorrupted,
          conversationId,
          agentId,
          fileUploadEnabled: agentDetails == null ? void 0 : agentDetails.file_upload,
          children: /* @__PURE__ */ jsxRuntime.jsx(
            MessageList,
            {
              messages,
              agentAction,
              isAgentLoading,
              lastMessageRef
            }
          )
        }
      )
    ] }) }) }),
    /* @__PURE__ */ jsxRuntime.jsx(ChatSidebar, { currentAgentId: agentId, currentConversationId: conversationId })
  ] });
}
const SingleColumnLayout = ({ children }) => {
  return /* @__PURE__ */ jsxRuntime.jsx("div", { className: "flex flex-col gap-y-3", style: { height: `calc(100vh - 78px)` }, children });
};
const EnthusiastChatPage = () => {
  const { datasetId, isLoading } = useActiveDataset();
  if (isLoading || !datasetId) return null;
  return /* @__PURE__ */ jsxRuntime.jsx(SingleColumnLayout, { children: /* @__PURE__ */ jsxRuntime.jsx(ChatSession, { datasetId }) });
};
adminSdk.defineRouteConfig({});
async function loader({ request, params }) {
  const { chatId } = params;
  if (!chatId || chatId === "new") {
    const url = new URL(request.url);
    const agentId = url.searchParams.get("agent");
    if (!agentId) return null;
    return await enthusiastAdminSdk.client.fetch(`/enthusiast/agents/${agentId}`);
  }
  const conversation = await enthusiastAdminSdk.client.fetch(
    `/enthusiast/conversations/${chatId}`
  );
  return conversation.agent;
}
const handle = {
  breadcrumb: ({ data }) => (data == null ? void 0 : data.name) || "Agent"
};
const i18nTranslations0 = {};
const widgetModule = { widgets: [] };
const routeModule = {
  routes: [
    {
      Component: EnthusiastPage,
      path: "/enthusiast",
      handle: handle$2
    },
    {
      Component: EnthusiastNewChatPage,
      path: "/enthusiast/chat"
    },
    {
      Component: EnthusiastSettingPage,
      path: "/enthusiast/settings",
      handle: handle$1
    },
    {
      Component: EnthusiastChatPage,
      path: "/enthusiast/chat/:chatId",
      handle,
      loader
    }
  ]
};
const menuItemModule = {
  menuItems: [
    {
      label: config.label,
      icon: config.icon,
      path: "/enthusiast",
      nested: void 0
    }
  ]
};
const formModule = { customFields: {} };
const displayModule = {
  displays: {}
};
const i18nModule = { resources: i18nTranslations0 };
const plugin = {
  widgetModule,
  routeModule,
  menuItemModule,
  formModule,
  displayModule,
  i18nModule
};
module.exports = plugin;
