"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FeedbackButton = FeedbackButton;
const jsx_runtime_1 = require("react/jsx-runtime");
const button_1 = require("../../components/ui/button");
const lucide_react_1 = require("lucide-react");
function FeedbackButton({ isOpen, onClick }) {
    return ((0, jsx_runtime_1.jsxs)(button_1.Button, { onClick: onClick, variant: "ghost", children: ["Provide feedback for this response", isOpen ? (0, jsx_runtime_1.jsx)(lucide_react_1.ChevronUpIcon, {}) : (0, jsx_runtime_1.jsx)(lucide_react_1.ChevronDownIcon, {})] }));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmVlZGJhY2stYnV0dG9uLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL2NvbXBvbmVudHMvY2hhdC9mZWVkYmFjay1idXR0b24udHN4Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBUUEsd0NBT0M7O0FBZkQsdURBQW9EO0FBQ3BELCtDQUE4RDtBQU85RCxTQUFnQixjQUFjLENBQUMsRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUF1QjtJQUNyRSxPQUFPLENBQ0wsd0JBQUMsZUFBTSxJQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFDLE9BQU8sbURBRXRDLE1BQU0sQ0FBQyxDQUFDLENBQUMsdUJBQUMsNEJBQWEsS0FBRyxDQUFDLENBQUMsQ0FBQyx1QkFBQyw4QkFBZSxLQUFHLElBQzFDLENBQ1YsQ0FBQztBQUNKLENBQUMifQ==