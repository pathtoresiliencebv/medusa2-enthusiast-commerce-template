"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = void 0;
const enthusiast_1 = require("../../../../../modules/enthusiast");
const wrappers_1 = require("../../../../../api/wrappers");
exports.GET = (0, wrappers_1.withErrorHandler)(async (req, res) => {
    const enthusiastService = req.scope.resolve(enthusiast_1.ENTHUSIAST_MODULE);
    const taskId = req.params.id;
    const taskState = await enthusiastService.getTaskStatus({
        task_id: taskId,
    });
    res.status(200).json({ state: taskState });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2VudGh1c2lhc3QvdGFzay1zdGF0dXMvW2lkXS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSxrRUFBc0U7QUFFdEUsMERBQStEO0FBR2xELFFBQUEsR0FBRyxHQUFHLElBQUEsMkJBQWdCLEVBQUMsS0FBSyxFQUFFLEdBQWtCLEVBQUUsR0FBbUIsRUFBRSxFQUFFO0lBQ3BGLE1BQU0saUJBQWlCLEdBQXNCLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLDhCQUFpQixDQUFDLENBQUM7SUFDbEYsTUFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7SUFFN0IsTUFBTSxTQUFTLEdBQUcsTUFBTSxpQkFBaUIsQ0FBQyxhQUFhLENBQUM7UUFDdEQsT0FBTyxFQUFFLE1BQU07S0FDRixDQUFDLENBQUM7SUFFakIsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLENBQUMsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQyJ9