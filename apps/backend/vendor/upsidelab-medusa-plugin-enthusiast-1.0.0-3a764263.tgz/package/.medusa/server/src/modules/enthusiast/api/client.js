"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApiClient = exports.ConfigApiClient = exports.AccountsApiClient = exports.AgentsApiClient = exports.DataSetsApiClient = exports.ConversationsApiClient = exports.BaseApiClient = exports.EnthusiastAPIError = void 0;
class EnthusiastAPIError extends Error {
    constructor(status, statusText, body) {
        super(`HTTP ${status} ${statusText}`);
        this.status = status;
        this.statusText = statusText;
        this.body = body;
    }
}
exports.EnthusiastAPIError = EnthusiastAPIError;
class BaseApiClient {
    constructor(apiBase, apiToken) {
        this.apiBase = apiBase;
        this.apiToken = apiToken;
    }
    _requestConfiguration() {
        return {
            headers: {
                Authorization: `Token ${this.apiToken}`,
                "Content-Type": "application/json",
            },
        };
    }
    async _extractErrorMessage(responseObj) {
        let errorMessage;
        try {
            // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
            const errorObj = await responseObj.json();
            if (!errorObj || typeof errorObj !== "object") {
                return "Unknown error";
            }
            const firstEntry = Object.entries(errorObj)[0];
            if (!firstEntry)
                return "Unknown error";
            // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
            const [key, value] = firstEntry;
            let message;
            if (Array.isArray(value)) {
                message = String(value[0]);
            }
            else if (typeof value === "string") {
                message = value;
            }
            else {
                message = JSON.stringify(value);
            }
            return `${key}: ${message}`;
        }
        catch {
            errorMessage = await responseObj.text();
        }
        return errorMessage;
    }
    async raiseForStatus(response) {
        if (!response.ok) {
            const errorMessage = await this._extractErrorMessage(response);
            throw new EnthusiastAPIError(response.status, response.statusText, errorMessage);
        }
        return response;
    }
    async sendRequest(path, init) {
        const response = await fetch(path, init);
        await this.raiseForStatus(response);
        return response;
    }
}
exports.BaseApiClient = BaseApiClient;
class ConversationsApiClient extends BaseApiClient {
    async getConversations(dataSetId, agentId = undefined, page = 1) {
        let url = `${this.apiBase}/api/conversations?data_set_id=${dataSetId}&page=${page}`;
        if (agentId) {
            url = url + `&agent_id=${agentId}`;
        }
        const response = await this.sendRequest(url, this._requestConfiguration());
        return (await response.json());
    }
    async createConversation(agentId) {
        const requestBody = {
            agent_id: agentId,
        };
        const requestConfiguration = this._requestConfiguration();
        requestConfiguration.method = "POST";
        requestConfiguration.body = JSON.stringify(requestBody);
        const response = await this.sendRequest(`${this.apiBase}/api/conversations`, requestConfiguration);
        if (!response.ok) {
            throw new Error(`Failed to create conversation: ${response.statusText}`);
        }
        const { id } = (await response.json());
        return id;
    }
    async sendMessage(conversationId, dataSetId, message, streaming, fileIds) {
        const requestBody = {
            question_message: message,
            data_set_id: dataSetId,
            streaming,
            file_ids: fileIds,
        };
        const response = await this.sendRequest(`${this.apiBase}/api/conversations/${conversationId}`, {
            ...this._requestConfiguration(),
            method: "POST",
            body: JSON.stringify(requestBody),
        });
        if (!response.ok) {
            throw new Error(`Failed to enqueue task: ${response.statusText}`);
        }
        return (await response.json());
    }
    async getTaskStatus(taskHandle) {
        const response = await this.sendRequest(`${this.apiBase}/api/task_status/${taskHandle.task_id}`, { ...this._requestConfiguration() });
        const { state } = (await response.json());
        return state;
    }
    async fetchResponseMessage(conversationId, taskHandle) {
        const taskStatus = await this.getTaskStatus(taskHandle);
        if (taskStatus === "SUCCESS" || taskStatus === "FAILURE") {
            const conversation = await this.getConversation(conversationId);
            return conversation.history[conversation.history.length - 1];
        }
        return null;
    }
    async getConversation(conversation_id) {
        try {
            const response = await this.sendRequest(`${this.apiBase}/api/conversations/${conversation_id}`, {
                ...this._requestConfiguration(),
            });
            if (!response.ok) {
                throw new Error(`Failed to get conversation: ${response.statusText}`);
            }
            return await response.json();
        }
        catch (error) {
            if (error instanceof Error) {
                throw new Error(`Failed to get conversation history: ${error.message}`);
            }
            else {
                throw new Error("Failed to get conversation history: An unknown error occurred.");
            }
        }
    }
    async updateMessageFeedback(messageId, feedbackData) {
        const response = await this.sendRequest(`${this.apiBase}/api/messages/${messageId}/feedback/`, {
            ...this._requestConfiguration(),
            method: "PATCH",
            body: JSON.stringify(feedbackData),
        });
        if (!response.ok) {
            throw new Error(`Could not update feedback for message ID ${messageId}`);
        }
        return (await response.json());
    }
    async getSupportedFileTypes() {
        try {
            const response = await this.sendRequest(`${this.apiBase}/api/supported-file-types/`, {
                ...this._requestConfiguration(),
                method: "GET",
            });
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return (await response.json());
        }
        catch (error) {
            if (error instanceof Error) {
                throw new Error(`Failed to get supported file types: ${error.message}`);
            }
            else {
                throw new Error("Failed to get supported file types: An unknown error occurred.");
            }
        }
    }
    async uploadFile(conversationId, file) {
        const formData = new FormData();
        formData.append("file", file);
        const requestConfig = this._requestConfiguration();
        const headers = { ...requestConfig.headers };
        delete headers["Content-Type"];
        const response = await this.sendRequest(`${this.apiBase}/api/conversations/${conversationId}/upload/`, {
            ...requestConfig,
            method: "POST",
            headers,
            body: formData,
        });
        if (!response.ok) {
            throw new Error(`Failed to start file upload: ${response.status} ${response.statusText}`);
        }
        return (await response.json());
    }
    async getFileUploadStatus(taskId) {
        const response = await this.sendRequest(`${this.apiBase}/api/file-upload-status/${taskId}/`, this._requestConfiguration());
        if (!response.ok) {
            throw new Error("Failed to check upload status");
        }
        return (await response.json());
    }
}
exports.ConversationsApiClient = ConversationsApiClient;
class DataSetsApiClient extends BaseApiClient {
    async getDataSets() {
        const response = await this.sendRequest(`${this.apiBase}/api/data_sets`, this._requestConfiguration());
        const data = (await response.json());
        return data.results;
    }
    async createDataSet(payload) {
        const response = await this.sendRequest(`${this.apiBase}/api/data_sets`, {
            ...this._requestConfiguration(),
            body: JSON.stringify(payload),
            method: "POST",
        });
        const responseJson = (await response.json());
        return responseJson.id;
    }
    async configureDataSetProductSource(productSource) {
        const body = {
            id: productSource.id,
            plugin_name: productSource.plugin_name,
            // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
            config: JSON.parse(productSource.config),
            data_set_id: productSource.data_set_id,
        };
        const response = await this.sendRequest(`${this.apiBase}/api/data_sets/${productSource.data_set_id}/product_sources/${productSource.id}`, {
            ...this._requestConfiguration(),
            body: JSON.stringify(body),
            method: "PATCH",
        });
        const responseJson = (await response.json());
        return responseJson.id;
    }
    async getDataSetProductSource(dataSetId, productSourceId) {
        const response = await this.sendRequest(`${this.apiBase}/api/data_sets/${dataSetId}/product_sources/${productSourceId}`, this._requestConfiguration());
        return (await response.json());
    }
    async addDataSetProductSource(dataSetId, pluginName, config) {
        const response = await this.sendRequest(`${this.apiBase}/api/data_sets/${dataSetId}/product_sources`, {
            ...this._requestConfiguration(),
            method: "POST",
            body: JSON.stringify({ plugin_name: pluginName, config: { configuration_args: config } }),
        });
        return (await response.json());
    }
    async addDataSetIntegration(dataSetId, pluginName, config) {
        const response = await this.sendRequest(`${this.apiBase}/api/data_sets/${dataSetId}/ecommerce_integration`, {
            ...this._requestConfiguration(),
            method: "POST",
            body: JSON.stringify({ plugin_name: pluginName, config: { configuration_args: config } }),
        });
        return (await response.json());
    }
    async syncDataSetIntegration(dataSetId) {
        const response = await this.sendRequest(`${this.apiBase}/api/data_sets/${dataSetId}/ecommerce_integration/sync`, {
            ...this._requestConfiguration(),
            method: "POST",
        });
        return (await response.json());
    }
    async configureDataSetDocumentSource(documentSource) {
        const body = {
            id: documentSource.id,
            plugin_name: documentSource.plugin_name,
            // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
            config: JSON.parse(documentSource.config),
            data_set_id: documentSource.data_set_id,
        };
        const response = await this.sendRequest(`${this.apiBase}/api/data_sets/${documentSource.data_set_id}/document_sources/${documentSource.id}`, {
            ...this._requestConfiguration(),
            body: JSON.stringify(body),
            method: "PATCH",
        });
        const responseJson = (await response.json());
        return responseJson.id;
    }
    async getDataSet(dataSetId) {
        const response = await this.sendRequest(`${this.apiBase}/api/data_sets/${dataSetId}`, this._requestConfiguration());
        const data = (await response.json());
        return {
            id: data.id,
            name: data.name,
            languageModelProvider: data.language_model_provider,
            languageModel: data.language_model,
            embeddingProvider: data.embedding_provider,
            embeddingModel: data.embedding_model,
            embeddingVectorSize: data.embedding_vector_dimensions,
        };
    }
}
exports.DataSetsApiClient = DataSetsApiClient;
class AgentsApiClient extends BaseApiClient {
    async getDatasetAvailableAgents(dataSetId) {
        const query = new URLSearchParams({ dataset: dataSetId.toString() });
        const response = await this.sendRequest(`${this.apiBase}/api/agents?${query.toString()}`, this._requestConfiguration());
        if (!response.ok) {
            throw new Error(`Failed to fetch available agents: ${response.statusText}`);
        }
        return (await response.json());
    }
    async getAgentById(agentId) {
        const response = await this.sendRequest(`${this.apiBase}/api/agents/${agentId}`, this._requestConfiguration());
        if (!response.ok) {
            throw new Error(`Failed to fetch agent: ${response.statusText}`);
        }
        return (await response.json());
    }
}
exports.AgentsApiClient = AgentsApiClient;
class AccountsApiClient extends BaseApiClient {
    async me() {
        const response = await this.sendRequest(`${this.apiBase}/api/account`, this._requestConfiguration());
        return (await response.json());
    }
}
exports.AccountsApiClient = AccountsApiClient;
class ConfigApiClient extends BaseApiClient {
    async getAvailableProviders() {
        const response = await this.sendRequest(`${this.apiBase}/api/config`, this._requestConfiguration());
        const result = (await response.json());
        return {
            embeddingProviders: result.embedding_providers,
            languageModelProviders: result.language_model_providers,
        };
    }
    async getLanguageModelsForProvider(name) {
        const response = await this.sendRequest(`${this.apiBase}/api/config/language_model_providers/${name}`, this._requestConfiguration());
        return (await response.json());
    }
    async getEmbeddingModelsForProvider(name) {
        const response = await this.sendRequest(`${this.apiBase}/api/config/embedding_providers/${name}`, this._requestConfiguration());
        return (await response.json());
    }
    async getAvailableProductSources() {
        const response = await this.sendRequest(`${this.apiBase}/api/plugins/product_source_plugins?page_size=100`, this._requestConfiguration());
        return (await response.json());
    }
    async getAvailableIntegrations() {
        const response = await this.sendRequest(`${this.apiBase}/api/plugins/ecommerce_integration_plugins?page_size=100`, this._requestConfiguration());
        return (await response.json());
    }
}
exports.ConfigApiClient = ConfigApiClient;
class ApiClient {
    constructor(apiBase, apiToken) {
        this.apiBase = apiBase;
        this.apiToken = apiToken;
    }
    dataSets() {
        return new DataSetsApiClient(this.apiBase, this.apiToken);
    }
    conversations() {
        return new ConversationsApiClient(this.apiBase, this.apiToken);
    }
    agents() {
        return new AgentsApiClient(this.apiBase, this.apiToken);
    }
    accounts() {
        return new AccountsApiClient(this.apiBase, this.apiToken);
    }
    config() {
        return new ConfigApiClient(this.apiBase, this.apiToken);
    }
}
exports.ApiClient = ApiClient;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2xpZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc3JjL21vZHVsZXMvZW50aHVzaWFzdC9hcGkvY2xpZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQTJCQSxNQUFhLGtCQUFtQixTQUFRLEtBQUs7SUFDM0MsWUFDUyxNQUFjLEVBQ2QsVUFBa0IsRUFDbEIsSUFBYTtRQUVwQixLQUFLLENBQUMsUUFBUSxNQUFNLElBQUksVUFBVSxFQUFFLENBQUMsQ0FBQztRQUovQixXQUFNLEdBQU4sTUFBTSxDQUFRO1FBQ2QsZUFBVSxHQUFWLFVBQVUsQ0FBUTtRQUNsQixTQUFJLEdBQUosSUFBSSxDQUFTO0lBR3RCLENBQUM7Q0FDRjtBQVJELGdEQVFDO0FBRUQsTUFBc0IsYUFBYTtJQUNqQyxZQUNxQixPQUFlLEVBQ2YsUUFBZ0I7UUFEaEIsWUFBTyxHQUFQLE9BQU8sQ0FBUTtRQUNmLGFBQVEsR0FBUixRQUFRLENBQVE7SUFDbEMsQ0FBQztJQUVKLHFCQUFxQjtRQUNuQixPQUFPO1lBQ0wsT0FBTyxFQUFFO2dCQUNQLGFBQWEsRUFBRSxTQUFTLElBQUksQ0FBQyxRQUFRLEVBQUU7Z0JBQ3ZDLGNBQWMsRUFBRSxrQkFBa0I7YUFDbkM7U0FDRixDQUFDO0lBQ0osQ0FBQztJQUVELEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxXQUFxQjtRQUM5QyxJQUFJLFlBQW9CLENBQUM7UUFDekIsSUFBSSxDQUFDO1lBQ0gsbUVBQW1FO1lBQ25FLE1BQU0sUUFBUSxHQUFHLE1BQU0sV0FBVyxDQUFDLElBQUksRUFBRSxDQUFDO1lBQzFDLElBQUksQ0FBQyxRQUFRLElBQUksT0FBTyxRQUFRLEtBQUssUUFBUSxFQUFFLENBQUM7Z0JBQzlDLE9BQU8sZUFBZSxDQUFDO1lBQ3pCLENBQUM7WUFDRCxNQUFNLFVBQVUsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLFFBQW9DLENBQUMsQ0FBQyxDQUFDLENBRTVELENBQUM7WUFFZCxJQUFJLENBQUMsVUFBVTtnQkFBRSxPQUFPLGVBQWUsQ0FBQztZQUV4QyxtRUFBbUU7WUFDbkUsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsR0FBRyxVQUFVLENBQUM7WUFDaEMsSUFBSSxPQUFlLENBQUM7WUFFcEIsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQ3pCLE9BQU8sR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDN0IsQ0FBQztpQkFBTSxJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVEsRUFBRSxDQUFDO2dCQUNyQyxPQUFPLEdBQUcsS0FBSyxDQUFDO1lBQ2xCLENBQUM7aUJBQU0sQ0FBQztnQkFDTixPQUFPLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNsQyxDQUFDO1lBRUQsT0FBTyxHQUFHLEdBQUcsS0FBSyxPQUFPLEVBQUUsQ0FBQztRQUM5QixDQUFDO1FBQUMsTUFBTSxDQUFDO1lBQ1AsWUFBWSxHQUFHLE1BQU0sV0FBVyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQzFDLENBQUM7UUFDRCxPQUFPLFlBQVksQ0FBQztJQUN0QixDQUFDO0lBRUQsS0FBSyxDQUFDLGNBQWMsQ0FBQyxRQUFrQjtRQUNyQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxDQUFDO1lBQ2pCLE1BQU0sWUFBWSxHQUFHLE1BQU0sSUFBSSxDQUFDLG9CQUFvQixDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQy9ELE1BQU0sSUFBSSxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQyxVQUFVLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFDbkYsQ0FBQztRQUNELE9BQU8sUUFBUSxDQUFDO0lBQ2xCLENBQUM7SUFDRCxLQUFLLENBQUMsV0FBVyxDQUFDLElBQVksRUFBRSxJQUFpQjtRQUMvQyxNQUFNLFFBQVEsR0FBRyxNQUFNLEtBQUssQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDekMsTUFBTSxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3BDLE9BQU8sUUFBUSxDQUFDO0lBQ2xCLENBQUM7Q0FDRjtBQTVERCxzQ0E0REM7QUFFRCxNQUFhLHNCQUF1QixTQUFRLGFBQWE7SUFDdkQsS0FBSyxDQUFDLGdCQUFnQixDQUNwQixTQUFpQixFQUNqQixVQUE4QixTQUFTLEVBQ3ZDLE9BQWUsQ0FBQztRQUVoQixJQUFJLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxPQUFPLGtDQUFrQyxTQUFTLFNBQVMsSUFBSSxFQUFFLENBQUM7UUFDcEYsSUFBSSxPQUFPLEVBQUUsQ0FBQztZQUNaLEdBQUcsR0FBRyxHQUFHLEdBQUcsYUFBYSxPQUFPLEVBQUUsQ0FBQztRQUNyQyxDQUFDO1FBQ0QsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxDQUFDO1FBQzNFLE9BQU8sQ0FBQyxNQUFNLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBMkMsQ0FBQztJQUMzRSxDQUFDO0lBRUQsS0FBSyxDQUFDLGtCQUFrQixDQUFDLE9BQWU7UUFDdEMsTUFBTSxXQUFXLEdBQThCO1lBQzdDLFFBQVEsRUFBRSxPQUFPO1NBQ2xCLENBQUM7UUFFRixNQUFNLG9CQUFvQixHQUFHLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQzFELG9CQUFvQixDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7UUFDckMsb0JBQW9CLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFeEQsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsV0FBVyxDQUNyQyxHQUFHLElBQUksQ0FBQyxPQUFPLG9CQUFvQixFQUNuQyxvQkFBb0IsQ0FDckIsQ0FBQztRQUVGLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDakIsTUFBTSxJQUFJLEtBQUssQ0FBQyxrQ0FBa0MsUUFBUSxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUM7UUFDM0UsQ0FBQztRQUVELE1BQU0sRUFBRSxFQUFFLEVBQUUsR0FBRyxDQUFDLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBRSxDQUFtQixDQUFDO1FBQ3pELE9BQU8sRUFBRSxDQUFDO0lBQ1osQ0FBQztJQUVELEtBQUssQ0FBQyxXQUFXLENBQ2YsY0FBc0IsRUFDdEIsU0FBaUIsRUFDakIsT0FBZSxFQUNmLFNBQWtCLEVBQ2xCLE9BQWtCO1FBRWxCLE1BQU0sV0FBVyxHQUF5QjtZQUN4QyxnQkFBZ0IsRUFBRSxPQUFPO1lBQ3pCLFdBQVcsRUFBRSxTQUFTO1lBQ3RCLFNBQVM7WUFDVCxRQUFRLEVBQUUsT0FBTztTQUNsQixDQUFDO1FBRUYsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sc0JBQXNCLGNBQWMsRUFBRSxFQUFFO1lBQzdGLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixFQUFFO1lBQy9CLE1BQU0sRUFBRSxNQUFNO1lBQ2QsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDO1NBQ2xDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDakIsTUFBTSxJQUFJLEtBQUssQ0FBQywyQkFBMkIsUUFBUSxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUM7UUFDcEUsQ0FBQztRQUVELE9BQU8sQ0FBQyxNQUFNLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBZSxDQUFDO0lBQy9DLENBQUM7SUFFRCxLQUFLLENBQUMsYUFBYSxDQUFDLFVBQXNCO1FBQ3hDLE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FDckMsR0FBRyxJQUFJLENBQUMsT0FBTyxvQkFBb0IsVUFBVSxDQUFDLE9BQU8sRUFBRSxFQUN2RCxFQUFFLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixFQUFFLEVBQUUsQ0FDcEMsQ0FBQztRQUNGLE1BQU0sRUFBRSxLQUFLLEVBQUUsR0FBRyxDQUFDLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBRSxDQUFjLENBQUM7UUFDdkQsT0FBTyxLQUFLLENBQUM7SUFDZixDQUFDO0lBRUQsS0FBSyxDQUFDLG9CQUFvQixDQUN4QixjQUFzQixFQUN0QixVQUFzQjtRQUV0QixNQUFNLFVBQVUsR0FBRyxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLENBQUM7UUFFeEQsSUFBSSxVQUFVLEtBQUssU0FBUyxJQUFJLFVBQVUsS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUN6RCxNQUFNLFlBQVksR0FBRyxNQUFNLElBQUksQ0FBQyxlQUFlLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDaEUsT0FBTyxZQUFZLENBQUMsT0FBUSxDQUFDLFlBQVksQ0FBQyxPQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQ2pFLENBQUM7UUFFRCxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7SUFFRCxLQUFLLENBQUMsZUFBZSxDQUFDLGVBQThCO1FBQ2xELElBQUksQ0FBQztZQUNILE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FDckMsR0FBRyxJQUFJLENBQUMsT0FBTyxzQkFBc0IsZUFBZSxFQUFFLEVBQ3REO2dCQUNFLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixFQUFFO2FBQ2hDLENBQ0YsQ0FBQztZQUVGLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLENBQUM7Z0JBQ2pCLE1BQU0sSUFBSSxLQUFLLENBQUMsK0JBQStCLFFBQVEsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDO1lBQ3hFLENBQUM7WUFFRCxPQUFPLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDO1FBQy9CLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxLQUFLLFlBQVksS0FBSyxFQUFFLENBQUM7Z0JBQzNCLE1BQU0sSUFBSSxLQUFLLENBQUMsdUNBQXVDLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQzFFLENBQUM7aUJBQU0sQ0FBQztnQkFDTixNQUFNLElBQUksS0FBSyxDQUFDLGdFQUFnRSxDQUFDLENBQUM7WUFDcEYsQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO0lBRUQsS0FBSyxDQUFDLHFCQUFxQixDQUFDLFNBQXdCLEVBQUUsWUFBMEI7UUFDOUUsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8saUJBQWlCLFNBQVMsWUFBWSxFQUFFO1lBQzdGLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixFQUFFO1lBQy9CLE1BQU0sRUFBRSxPQUFPO1lBQ2YsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDO1NBQ25DLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDakIsTUFBTSxJQUFJLEtBQUssQ0FBQyw0Q0FBNEMsU0FBUyxFQUFFLENBQUMsQ0FBQztRQUMzRSxDQUFDO1FBRUQsT0FBTyxDQUFDLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBRSxDQUFrQixDQUFDO0lBQ2xELENBQUM7SUFFRCxLQUFLLENBQUMscUJBQXFCO1FBQ3pCLElBQUksQ0FBQztZQUNILE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLDRCQUE0QixFQUFFO2dCQUNuRixHQUFHLElBQUksQ0FBQyxxQkFBcUIsRUFBRTtnQkFDL0IsTUFBTSxFQUFFLEtBQUs7YUFDZCxDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxDQUFDO2dCQUNqQixNQUFNLElBQUksS0FBSyxDQUFDLHVCQUF1QixRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztZQUM1RCxDQUFDO1lBRUQsT0FBTyxDQUFDLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBRSxDQUF1QixDQUFDO1FBQ3ZELENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsSUFBSSxLQUFLLFlBQVksS0FBSyxFQUFFLENBQUM7Z0JBQzNCLE1BQU0sSUFBSSxLQUFLLENBQUMsdUNBQXVDLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQzFFLENBQUM7aUJBQU0sQ0FBQztnQkFDTixNQUFNLElBQUksS0FBSyxDQUFDLGdFQUFnRSxDQUFDLENBQUM7WUFDcEYsQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO0lBRUQsS0FBSyxDQUFDLFVBQVUsQ0FBQyxjQUFzQixFQUFFLElBQVU7UUFDakQsTUFBTSxRQUFRLEdBQUcsSUFBSSxRQUFRLEVBQUUsQ0FBQztRQUNoQyxRQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztRQUU5QixNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUNuRCxNQUFNLE9BQU8sR0FBRyxFQUFFLEdBQUcsYUFBYSxDQUFDLE9BQU8sRUFBNEIsQ0FBQztRQUN2RSxPQUFPLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUUvQixNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQ3JDLEdBQUcsSUFBSSxDQUFDLE9BQU8sc0JBQXNCLGNBQWMsVUFBVSxFQUM3RDtZQUNFLEdBQUcsYUFBYTtZQUNoQixNQUFNLEVBQUUsTUFBTTtZQUNkLE9BQU87WUFDUCxJQUFJLEVBQUUsUUFBUTtTQUNmLENBQ0YsQ0FBQztRQUVGLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDakIsTUFBTSxJQUFJLEtBQUssQ0FBQyxnQ0FBZ0MsUUFBUSxDQUFDLE1BQU0sSUFBSSxRQUFRLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQztRQUM1RixDQUFDO1FBRUQsT0FBTyxDQUFDLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBRSxDQUF1QixDQUFDO0lBQ3ZELENBQUM7SUFFRCxLQUFLLENBQUMsbUJBQW1CLENBQUMsTUFBYztRQUN0QyxNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQ3JDLEdBQUcsSUFBSSxDQUFDLE9BQU8sMkJBQTJCLE1BQU0sR0FBRyxFQUNuRCxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FDN0IsQ0FBQztRQUVGLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDakIsTUFBTSxJQUFJLEtBQUssQ0FBQywrQkFBK0IsQ0FBQyxDQUFDO1FBQ25ELENBQUM7UUFFRCxPQUFPLENBQUMsTUFBTSxRQUFRLENBQUMsSUFBSSxFQUFFLENBQTZCLENBQUM7SUFDN0QsQ0FBQztDQUNGO0FBckxELHdEQXFMQztBQUVELE1BQWEsaUJBQWtCLFNBQVEsYUFBYTtJQUNsRCxLQUFLLENBQUMsV0FBVztRQUNmLE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FDckMsR0FBRyxJQUFJLENBQUMsT0FBTyxnQkFBZ0IsRUFDL0IsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQzdCLENBQUM7UUFDRixNQUFNLElBQUksR0FBRyxDQUFDLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBRSxDQUEyQixDQUFDO1FBQy9ELE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQztJQUN0QixDQUFDO0lBRUQsS0FBSyxDQUFDLGFBQWEsQ0FBQyxPQUE2QjtRQUMvQyxNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxnQkFBZ0IsRUFBRTtZQUN2RSxHQUFHLElBQUksQ0FBQyxxQkFBcUIsRUFBRTtZQUMvQixJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUM7WUFDN0IsTUFBTSxFQUFFLE1BQU07U0FDZixDQUFDLENBQUM7UUFFSCxNQUFNLFlBQVksR0FBRyxDQUFDLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBRSxDQUFvQixDQUFDO1FBQ2hFLE9BQU8sWUFBWSxDQUFDLEVBQUUsQ0FBQztJQUN6QixDQUFDO0lBRUQsS0FBSyxDQUFDLDZCQUE2QixDQUFDLGFBQTRCO1FBQzlELE1BQU0sSUFBSSxHQUFrQztZQUMxQyxFQUFFLEVBQUUsYUFBYSxDQUFDLEVBQUU7WUFDcEIsV0FBVyxFQUFFLGFBQWEsQ0FBQyxXQUFXO1lBQ3RDLG1FQUFtRTtZQUNuRSxNQUFNLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDO1lBQ3hDLFdBQVcsRUFBRSxhQUFhLENBQUMsV0FBVztTQUN2QyxDQUFDO1FBRUYsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsV0FBVyxDQUNyQyxHQUFHLElBQUksQ0FBQyxPQUFPLGtCQUFrQixhQUFhLENBQUMsV0FBVyxvQkFBb0IsYUFBYSxDQUFDLEVBQUUsRUFBRSxFQUNoRztZQUNFLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixFQUFFO1lBQy9CLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQztZQUMxQixNQUFNLEVBQUUsT0FBTztTQUNoQixDQUNGLENBQUM7UUFFRixNQUFNLFlBQVksR0FBRyxDQUFDLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBRSxDQUEwQixDQUFDO1FBQ3RFLE9BQU8sWUFBWSxDQUFDLEVBQUUsQ0FBQztJQUN6QixDQUFDO0lBRUQsS0FBSyxDQUFDLHVCQUF1QixDQUMzQixTQUFpQixFQUNqQixlQUF1QjtRQUV2QixNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQ3JDLEdBQUcsSUFBSSxDQUFDLE9BQU8sa0JBQWtCLFNBQVMsb0JBQW9CLGVBQWUsRUFBRSxFQUMvRSxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FDN0IsQ0FBQztRQUNGLE9BQU8sQ0FBQyxNQUFNLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBa0IsQ0FBQztJQUNsRCxDQUFDO0lBRUQsS0FBSyxDQUFDLHVCQUF1QixDQUMzQixTQUFpQixFQUNqQixVQUFrQixFQUNsQixNQUFjO1FBRWQsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsV0FBVyxDQUNyQyxHQUFHLElBQUksQ0FBQyxPQUFPLGtCQUFrQixTQUFTLGtCQUFrQixFQUM1RDtZQUNFLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixFQUFFO1lBQy9CLE1BQU0sRUFBRSxNQUFNO1lBQ2QsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxXQUFXLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRSxFQUFFLGtCQUFrQixFQUFFLE1BQU0sRUFBRSxFQUFFLENBQUM7U0FDMUYsQ0FDRixDQUFDO1FBQ0YsT0FBTyxDQUFDLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBRSxDQUFrQixDQUFDO0lBQ2xELENBQUM7SUFDRCxLQUFLLENBQUMscUJBQXFCLENBQ3pCLFNBQWlCLEVBQ2pCLFVBQWtCLEVBQ2xCLE1BQWM7UUFFZCxNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQ3JDLEdBQUcsSUFBSSxDQUFDLE9BQU8sa0JBQWtCLFNBQVMsd0JBQXdCLEVBQ2xFO1lBQ0UsR0FBRyxJQUFJLENBQUMscUJBQXFCLEVBQUU7WUFDL0IsTUFBTSxFQUFFLE1BQU07WUFDZCxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLFdBQVcsRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSxFQUFFLEVBQUUsQ0FBQztTQUMxRixDQUNGLENBQUM7UUFDRixPQUFPLENBQUMsTUFBTSxRQUFRLENBQUMsSUFBSSxFQUFFLENBQWtCLENBQUM7SUFDbEQsQ0FBQztJQUVELEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxTQUFpQjtRQUM1QyxNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQ3JDLEdBQUcsSUFBSSxDQUFDLE9BQU8sa0JBQWtCLFNBQVMsNkJBQTZCLEVBQ3ZFO1lBQ0UsR0FBRyxJQUFJLENBQUMscUJBQXFCLEVBQUU7WUFDL0IsTUFBTSxFQUFFLE1BQU07U0FDZixDQUNGLENBQUM7UUFDRixPQUFPLENBQUMsTUFBTSxRQUFRLENBQUMsSUFBSSxFQUFFLENBQWlCLENBQUM7SUFDakQsQ0FBQztJQUVELEtBQUssQ0FBQyw4QkFBOEIsQ0FBQyxjQUE2QjtRQUNoRSxNQUFNLElBQUksR0FBbUM7WUFDM0MsRUFBRSxFQUFFLGNBQWMsQ0FBQyxFQUFFO1lBQ3JCLFdBQVcsRUFBRSxjQUFjLENBQUMsV0FBVztZQUN2QyxtRUFBbUU7WUFDbkUsTUFBTSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQztZQUN6QyxXQUFXLEVBQUUsY0FBYyxDQUFDLFdBQVc7U0FDeEMsQ0FBQztRQUVGLE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FDckMsR0FBRyxJQUFJLENBQUMsT0FBTyxrQkFBa0IsY0FBYyxDQUFDLFdBQVcscUJBQXFCLGNBQWMsQ0FBQyxFQUFFLEVBQUUsRUFDbkc7WUFDRSxHQUFHLElBQUksQ0FBQyxxQkFBcUIsRUFBRTtZQUMvQixJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7WUFDMUIsTUFBTSxFQUFFLE9BQU87U0FDaEIsQ0FDRixDQUFDO1FBRUYsTUFBTSxZQUFZLEdBQUcsQ0FBQyxNQUFNLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBMkIsQ0FBQztRQUN2RSxPQUFPLFlBQVksQ0FBQyxFQUFFLENBQUM7SUFDekIsQ0FBQztJQUVELEtBQUssQ0FBQyxVQUFVLENBQUMsU0FBaUI7UUFDaEMsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsV0FBVyxDQUNyQyxHQUFHLElBQUksQ0FBQyxPQUFPLGtCQUFrQixTQUFTLEVBQUUsRUFDNUMsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQzdCLENBQUM7UUFDRixNQUFNLElBQUksR0FBRyxDQUFDLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBRSxDQUFvQixDQUFDO1FBRXhELE9BQU87WUFDTCxFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUU7WUFDWCxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7WUFDZixxQkFBcUIsRUFBRSxJQUFJLENBQUMsdUJBQXVCO1lBQ25ELGFBQWEsRUFBRSxJQUFJLENBQUMsY0FBYztZQUNsQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsa0JBQWtCO1lBQzFDLGNBQWMsRUFBRSxJQUFJLENBQUMsZUFBZTtZQUNwQyxtQkFBbUIsRUFBRSxJQUFJLENBQUMsMkJBQTJCO1NBQzNDLENBQUM7SUFDZixDQUFDO0NBQ0Y7QUF2SUQsOENBdUlDO0FBRUQsTUFBYSxlQUFnQixTQUFRLGFBQWE7SUFDaEQsS0FBSyxDQUFDLHlCQUF5QixDQUFDLFNBQWlCO1FBQy9DLE1BQU0sS0FBSyxHQUFHLElBQUksZUFBZSxDQUFDLEVBQUUsT0FBTyxFQUFFLFNBQVMsQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDckUsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsV0FBVyxDQUNyQyxHQUFHLElBQUksQ0FBQyxPQUFPLGVBQWUsS0FBSyxDQUFDLFFBQVEsRUFBRSxFQUFFLEVBQ2hELElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUM3QixDQUFDO1FBRUYsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUNqQixNQUFNLElBQUksS0FBSyxDQUFDLHFDQUFxQyxRQUFRLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQztRQUM5RSxDQUFDO1FBRUQsT0FBTyxDQUFDLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBRSxDQUFZLENBQUM7SUFDNUMsQ0FBQztJQUNELEtBQUssQ0FBQyxZQUFZLENBQUMsT0FBZTtRQUNoQyxNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQ3JDLEdBQUcsSUFBSSxDQUFDLE9BQU8sZUFBZSxPQUFPLEVBQUUsRUFDdkMsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQzdCLENBQUM7UUFDRixJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxDQUFDO1lBQ2pCLE1BQU0sSUFBSSxLQUFLLENBQUMsMEJBQTBCLFFBQVEsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDO1FBQ25FLENBQUM7UUFDRCxPQUFPLENBQUMsTUFBTSxRQUFRLENBQUMsSUFBSSxFQUFFLENBQWlCLENBQUM7SUFDakQsQ0FBQztDQUNGO0FBeEJELDBDQXdCQztBQUNELE1BQWEsaUJBQWtCLFNBQVEsYUFBYTtJQUNsRCxLQUFLLENBQUMsRUFBRTtRQUNOLE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FDckMsR0FBRyxJQUFJLENBQUMsT0FBTyxjQUFjLEVBQzdCLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUM3QixDQUFDO1FBQ0YsT0FBTyxDQUFDLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBRSxDQUFZLENBQUM7SUFDNUMsQ0FBQztDQUNGO0FBUkQsOENBUUM7QUFDRCxNQUFhLGVBQWdCLFNBQVEsYUFBYTtJQUNoRCxLQUFLLENBQUMscUJBQXFCO1FBQ3pCLE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FDckMsR0FBRyxJQUFJLENBQUMsT0FBTyxhQUFhLEVBQzVCLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUM3QixDQUFDO1FBQ0YsTUFBTSxNQUFNLEdBQUcsQ0FBQyxNQUFNLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBNEIsQ0FBQztRQUVsRSxPQUFPO1lBQ0wsa0JBQWtCLEVBQUUsTUFBTSxDQUFDLG1CQUFtQjtZQUM5QyxzQkFBc0IsRUFBRSxNQUFNLENBQUMsd0JBQXdCO1NBQ3hELENBQUM7SUFDSixDQUFDO0lBRUQsS0FBSyxDQUFDLDRCQUE0QixDQUFDLElBQVk7UUFDN0MsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsV0FBVyxDQUNyQyxHQUFHLElBQUksQ0FBQyxPQUFPLHdDQUF3QyxJQUFJLEVBQUUsRUFDN0QsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQzdCLENBQUM7UUFDRixPQUFPLENBQUMsTUFBTSxRQUFRLENBQUMsSUFBSSxFQUFFLENBQWEsQ0FBQztJQUM3QyxDQUFDO0lBRUQsS0FBSyxDQUFDLDZCQUE2QixDQUFDLElBQVk7UUFDOUMsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsV0FBVyxDQUNyQyxHQUFHLElBQUksQ0FBQyxPQUFPLG1DQUFtQyxJQUFJLEVBQUUsRUFDeEQsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQzdCLENBQUM7UUFDRixPQUFPLENBQUMsTUFBTSxRQUFRLENBQUMsSUFBSSxFQUFFLENBQWEsQ0FBQztJQUM3QyxDQUFDO0lBRUQsS0FBSyxDQUFDLDBCQUEwQjtRQUM5QixNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQ3JDLEdBQUcsSUFBSSxDQUFDLE9BQU8sbURBQW1ELEVBQ2xFLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUM3QixDQUFDO1FBQ0YsT0FBTyxDQUFDLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBRSxDQUFrQixDQUFDO0lBQ2xELENBQUM7SUFDRCxLQUFLLENBQUMsd0JBQXdCO1FBQzVCLE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FDckMsR0FBRyxJQUFJLENBQUMsT0FBTywwREFBMEQsRUFDekUsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQzdCLENBQUM7UUFDRixPQUFPLENBQUMsTUFBTSxRQUFRLENBQUMsSUFBSSxFQUFFLENBQWtCLENBQUM7SUFDbEQsQ0FBQztDQUNGO0FBNUNELDBDQTRDQztBQUVELE1BQWEsU0FBUztJQUlwQixZQUFZLE9BQWUsRUFBRSxRQUFnQjtRQUMzQyxJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztRQUN2QixJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztJQUMzQixDQUFDO0lBRUQsUUFBUTtRQUNOLE9BQU8sSUFBSSxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUM1RCxDQUFDO0lBRUQsYUFBYTtRQUNYLE9BQU8sSUFBSSxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNqRSxDQUFDO0lBRUQsTUFBTTtRQUNKLE9BQU8sSUFBSSxlQUFlLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDMUQsQ0FBQztJQUVELFFBQVE7UUFDTixPQUFPLElBQUksaUJBQWlCLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDNUQsQ0FBQztJQUVELE1BQU07UUFDSixPQUFPLElBQUksZUFBZSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQzFELENBQUM7Q0FDRjtBQTVCRCw4QkE0QkMifQ==