"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentTable = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
const ui_1 = require("@medusajs/ui");
const react_router_dom_1 = require("react-router-dom");
const react_1 = require("react");
const admin_client_1 = require("../../admin/lib/admin-client");
const use_active_dataset_1 = require("../../admin/hooks/use-active-dataset");
const spinner_1 = require("../../components/utils/spinner");
const icons_1 = require("@medusajs/icons");
const no_datasets_png_1 = __importDefault(require("../../admin/assets/no-datasets.png"));
const columnHelper = (0, ui_1.createDataTableColumnHelper)();
const columns = (navigate) => [
    columnHelper.accessor("name", {
        header: "Name",
        enableSorting: true,
        sortLabel: "Name",
    }),
    columnHelper.accessor("description", {
        header: "Description",
    }),
    columnHelper.display({
        id: "actions",
        header: "",
        cell: ({ row }) => {
            return ((0, jsx_runtime_1.jsx)("div", { className: "flex justify-end", children: (0, jsx_runtime_1.jsxs)(ui_1.Button, { variant: "secondary", onClick: (e) => {
                        e.stopPropagation();
                        navigate(`/enthusiast/chat/new?agent=${row.original.id}`);
                    }, children: [(0, jsx_runtime_1.jsx)(icons_1.ChatBubble, {}), "Start Chat"] }) }));
        },
    }),
];
const AgentTable = () => {
    const { dataset, hasAnyDatasets, isLoading: isDatasetLoading } = (0, use_active_dataset_1.useActiveDataset)();
    const noDatasets = !isDatasetLoading && hasAnyDatasets === false;
    const noActiveDatasets = !isDatasetLoading && hasAnyDatasets === true && dataset === null;
    const [isLoading, setIsLoading] = (0, react_1.useState)(true);
    const [agents, setAgents] = (0, react_1.useState)([]);
    const navigate = (0, react_router_dom_1.useNavigate)();
    (0, react_1.useEffect)(() => {
        const fetchDatasetAgents = async () => {
            if (!dataset) {
                setAgents([]);
                setIsLoading(false);
                return;
            }
            try {
                setIsLoading(true);
                const res = await admin_client_1.adminApiClient.agents().getDatasetAgents(dataset.external_id);
                const availableAgents = res.filter((agent) => !agent.corrupted);
                const availableAgentsDetails = await Promise.all(availableAgents.map((agent) => {
                    return admin_client_1.adminApiClient.agents().getAgentById(agent.id);
                }));
                setAgents(availableAgentsDetails);
            }
            finally {
                setIsLoading(false);
            }
        };
        if (!isDatasetLoading) {
            void fetchDatasetAgents();
        }
    }, [dataset, isDatasetLoading]);
    const table = (0, ui_1.useDataTable)({
        columns: columns(navigate),
        data: agents || [],
        getRowId: (row) => row.id.toString(),
        rowCount: agents.length,
        onRowClick(event, row) {
            navigate(`/enthusiast/chat/new?agent=${row.id}`);
        },
    });
    if (isLoading) {
        return (0, jsx_runtime_1.jsx)(spinner_1.LoadingSpinner, {});
    }
    if (noDatasets) {
        return ((0, jsx_runtime_1.jsx)(ui_1.Container, { children: (0, jsx_runtime_1.jsx)("div", { className: "flex h-[385px] items-center justify-center", children: (0, jsx_runtime_1.jsxs)("div", { className: "text-center space-y-3 max-w-md px-4", children: [(0, jsx_runtime_1.jsx)("div", { className: "flex justify-center mb-2", children: (0, jsx_runtime_1.jsx)("img", { src: no_datasets_png_1.default, alt: "No connections illustration", className: "h-48 w-auto" }) }), (0, jsx_runtime_1.jsx)("h2", { className: "text-lg font-semibold text-gray-900", children: "Enthusiast needs to be configured." }), (0, jsx_runtime_1.jsx)("p", { className: "text-gray-600 text-xs leading-relaxed", children: "Go to settings to configure your Enthusiast connection." }), (0, jsx_runtime_1.jsx)("div", { className: "pt-1", children: (0, jsx_runtime_1.jsx)(ui_1.Button, { variant: "secondary", size: "small", onClick: () => navigate("/enthusiast/settings?create_dataset=true"), className: "border border-gray-300", children: "Open Settings" }) })] }) }) }));
    }
    if (noActiveDatasets) {
        navigate("/enthusiast/settings");
    }
    return ((0, jsx_runtime_1.jsx)(ui_1.Container, { className: "p-4", children: (0, jsx_runtime_1.jsx)("div", { className: "flex flex-col min-h-0", children: (0, jsx_runtime_1.jsxs)(ui_1.DataTable, { instance: table, children: [(0, jsx_runtime_1.jsxs)(ui_1.DataTable.Toolbar, { className: "flex flex-col items-start justify-between gap-2 md:flex-row md:items-center flex-shrink-0", children: [(0, jsx_runtime_1.jsxs)("div", { children: [(0, jsx_runtime_1.jsx)(ui_1.Heading, { children: "Agents" }), (0, jsx_runtime_1.jsx)(ui_1.Text, { className: "text-ui-fg-subtle", size: "small", children: "Choose an agent to start a session" })] }), (0, jsx_runtime_1.jsxs)(ui_1.Button, { variant: "secondary", onClick: () => navigate("/enthusiast/settings"), children: [(0, jsx_runtime_1.jsx)(icons_1.CogSixTooth, {}), "Settings"] })] }), (0, jsx_runtime_1.jsx)("div", { className: "overflow-auto min-h-0 max-h-[calc(100vh-16rem)]", onWheel: (e) => {
                            const container = e.currentTarget;
                            container.scrollTop += e.deltaY;
                        }, children: (0, jsx_runtime_1.jsx)(ui_1.DataTable.Table, { emptyState: {
                                empty: {
                                    heading: "No agents available",
                                    description: "You can configure available agents in Enthusiast's admin panel",
                                },
                            } }) })] }) }) }));
};
exports.AgentTable = AgentTable;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWdlbnQtdGFibGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvY29tcG9uZW50cy9hZG1pbi9hZ2VudC10YWJsZS50c3giXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBLHFDQVFzQjtBQUN0Qix1REFBK0M7QUFDL0MsaUNBQTRDO0FBQzVDLCtEQUE4RDtBQUM5RCw2RUFBd0U7QUFFeEUsNERBQWdFO0FBQ2hFLDJDQUEwRDtBQUMxRCx5RkFBaUU7QUFFakUsTUFBTSxZQUFZLEdBQUcsSUFBQSxnQ0FBMkIsR0FBZ0IsQ0FBQztBQUVqRSxNQUFNLE9BQU8sR0FBRyxDQUFDLFFBQWdDLEVBQUUsRUFBRSxDQUFDO0lBQ3BELFlBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFO1FBQzVCLE1BQU0sRUFBRSxNQUFNO1FBQ2QsYUFBYSxFQUFFLElBQUk7UUFDbkIsU0FBUyxFQUFFLE1BQU07S0FDbEIsQ0FBQztJQUNGLFlBQVksQ0FBQyxRQUFRLENBQUMsYUFBYSxFQUFFO1FBQ25DLE1BQU0sRUFBRSxhQUFhO0tBQ3RCLENBQUM7SUFDRixZQUFZLENBQUMsT0FBTyxDQUFDO1FBQ25CLEVBQUUsRUFBRSxTQUFTO1FBQ2IsTUFBTSxFQUFFLEVBQUU7UUFDVixJQUFJLEVBQUUsQ0FBQyxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUU7WUFDaEIsT0FBTyxDQUNMLGdDQUFLLFNBQVMsRUFBQyxrQkFBa0IsWUFDL0Isd0JBQUMsV0FBTSxJQUNMLE9BQU8sRUFBQyxXQUFXLEVBQ25CLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFO3dCQUNiLENBQUMsQ0FBQyxlQUFlLEVBQUUsQ0FBQzt3QkFDcEIsUUFBUSxDQUFDLDhCQUE4QixHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBQzVELENBQUMsYUFFRCx1QkFBQyxrQkFBVSxLQUFHLGtCQUVQLEdBQ0wsQ0FDUCxDQUFDO1FBQ0osQ0FBQztLQUNGLENBQUM7Q0FDSCxDQUFDO0FBRUssTUFBTSxVQUFVLEdBQUcsR0FBRyxFQUFFO0lBQzdCLE1BQU0sRUFBRSxPQUFPLEVBQUUsY0FBYyxFQUFFLFNBQVMsRUFBRSxnQkFBZ0IsRUFBRSxHQUFHLElBQUEscUNBQWdCLEdBQUUsQ0FBQztJQUNwRixNQUFNLFVBQVUsR0FBRyxDQUFDLGdCQUFnQixJQUFJLGNBQWMsS0FBSyxLQUFLLENBQUM7SUFDakUsTUFBTSxnQkFBZ0IsR0FBRyxDQUFDLGdCQUFnQixJQUFJLGNBQWMsS0FBSyxJQUFJLElBQUksT0FBTyxLQUFLLElBQUksQ0FBQztJQUMxRixNQUFNLENBQUMsU0FBUyxFQUFFLFlBQVksQ0FBQyxHQUFHLElBQUEsZ0JBQVEsRUFBQyxJQUFJLENBQUMsQ0FBQztJQUNqRCxNQUFNLENBQUMsTUFBTSxFQUFFLFNBQVMsQ0FBQyxHQUFHLElBQUEsZ0JBQVEsRUFBaUIsRUFBRSxDQUFDLENBQUM7SUFDekQsTUFBTSxRQUFRLEdBQUcsSUFBQSw4QkFBVyxHQUFFLENBQUM7SUFFL0IsSUFBQSxpQkFBUyxFQUFDLEdBQUcsRUFBRTtRQUNiLE1BQU0sa0JBQWtCLEdBQUcsS0FBSyxJQUFJLEVBQUU7WUFDcEMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUNiLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDZCxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ3BCLE9BQU87WUFDVCxDQUFDO1lBQ0QsSUFBSSxDQUFDO2dCQUNILFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDbkIsTUFBTSxHQUFHLEdBQUcsTUFBTSw2QkFBYyxDQUFDLE1BQU0sRUFBRSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDaEYsTUFBTSxlQUFlLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQ2hFLE1BQU0sc0JBQXNCLEdBQUcsTUFBTSxPQUFPLENBQUMsR0FBRyxDQUM5QyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxFQUFFLEVBQUU7b0JBQzVCLE9BQU8sNkJBQWMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUN4RCxDQUFDLENBQUMsQ0FDSCxDQUFDO2dCQUNGLFNBQVMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1lBQ3BDLENBQUM7b0JBQVMsQ0FBQztnQkFDVCxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDdEIsQ0FBQztRQUNILENBQUMsQ0FBQztRQUNGLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQ3RCLEtBQUssa0JBQWtCLEVBQUUsQ0FBQztRQUM1QixDQUFDO0lBQ0gsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLGdCQUFnQixDQUFDLENBQUMsQ0FBQztJQUVoQyxNQUFNLEtBQUssR0FBRyxJQUFBLGlCQUFZLEVBQUM7UUFDekIsT0FBTyxFQUFFLE9BQU8sQ0FBQyxRQUFRLENBQUM7UUFDMUIsSUFBSSxFQUFFLE1BQU0sSUFBSSxFQUFFO1FBQ2xCLFFBQVEsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxRQUFRLEVBQUU7UUFDcEMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxNQUFNO1FBQ3ZCLFVBQVUsQ0FBQyxLQUFLLEVBQUUsR0FBRztZQUNuQixRQUFRLENBQUMsOEJBQThCLEdBQUcsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ25ELENBQUM7S0FDRixDQUFDLENBQUM7SUFDSCxJQUFJLFNBQVMsRUFBRSxDQUFDO1FBQ2QsT0FBTyx1QkFBQyx3QkFBYyxLQUFHLENBQUM7SUFDNUIsQ0FBQztJQUNELElBQUksVUFBVSxFQUFFLENBQUM7UUFDZixPQUFPLENBQ0wsdUJBQUMsY0FBUyxjQUNSLGdDQUFLLFNBQVMsRUFBQyw0Q0FBNEMsWUFDekQsaUNBQUssU0FBUyxFQUFDLHFDQUFxQyxhQUNsRCxnQ0FBSyxTQUFTLEVBQUMsMEJBQTBCLFlBQ3ZDLGdDQUNFLEdBQUcsRUFBRSx5QkFBZSxFQUNwQixHQUFHLEVBQUMsNkJBQTZCLEVBQ2pDLFNBQVMsRUFBQyxhQUFhLEdBQ3ZCLEdBQ0UsRUFDTiwrQkFBSSxTQUFTLEVBQUMscUNBQXFDLG1EQUU5QyxFQUNMLDhCQUFHLFNBQVMsRUFBQyx1Q0FBdUMsd0VBRWhELEVBQ0osZ0NBQUssU0FBUyxFQUFDLE1BQU0sWUFDbkIsdUJBQUMsV0FBTSxJQUNMLE9BQU8sRUFBQyxXQUFXLEVBQ25CLElBQUksRUFBQyxPQUFPLEVBQ1osT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDLFFBQVEsQ0FBQywwQ0FBMEMsQ0FBQyxFQUNuRSxTQUFTLEVBQUMsd0JBQXdCLDhCQUczQixHQUNMLElBQ0YsR0FDRixHQUNJLENBQ2IsQ0FBQztJQUNKLENBQUM7SUFDRCxJQUFJLGdCQUFnQixFQUFFLENBQUM7UUFDckIsUUFBUSxDQUFDLHNCQUFzQixDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUNELE9BQU8sQ0FDTCx1QkFBQyxjQUFTLElBQUMsU0FBUyxFQUFDLEtBQUssWUFDeEIsZ0NBQUssU0FBUyxFQUFDLHVCQUF1QixZQUNwQyx3QkFBQyxjQUFTLElBQUMsUUFBUSxFQUFFLEtBQUssYUFDeEIsd0JBQUMsY0FBUyxDQUFDLE9BQU8sSUFBQyxTQUFTLEVBQUMsMkZBQTJGLGFBQ3RILDRDQUNFLHVCQUFDLFlBQU8seUJBQWlCLEVBQ3pCLHVCQUFDLFNBQUksSUFBQyxTQUFTLEVBQUMsbUJBQW1CLEVBQUMsSUFBSSxFQUFDLE9BQU8sbURBRXpDLElBQ0gsRUFDTix3QkFBQyxXQUFNLElBQUMsT0FBTyxFQUFDLFdBQVcsRUFBQyxPQUFPLEVBQUUsR0FBRyxFQUFFLENBQUMsUUFBUSxDQUFDLHNCQUFzQixDQUFDLGFBQ3pFLHVCQUFDLG1CQUFXLEtBQUcsZ0JBRVIsSUFDUyxFQUNwQixnQ0FDRSxTQUFTLEVBQUMsaURBQWlELEVBQzNELE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFOzRCQUNiLE1BQU0sU0FBUyxHQUFHLENBQUMsQ0FBQyxhQUFhLENBQUM7NEJBQ2xDLFNBQVMsQ0FBQyxTQUFTLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQzt3QkFDbEMsQ0FBQyxZQUVELHVCQUFDLGNBQVMsQ0FBQyxLQUFLLElBQ2QsVUFBVSxFQUFFO2dDQUNWLEtBQUssRUFBRTtvQ0FDTCxPQUFPLEVBQUUscUJBQXFCO29DQUM5QixXQUFXLEVBQUUsZ0VBQWdFO2lDQUM5RTs2QkFDRixHQUNELEdBQ0UsSUFDSSxHQUNSLEdBQ0ksQ0FDYixDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBdEhXLFFBQUEsVUFBVSxjQXNIckIifQ==