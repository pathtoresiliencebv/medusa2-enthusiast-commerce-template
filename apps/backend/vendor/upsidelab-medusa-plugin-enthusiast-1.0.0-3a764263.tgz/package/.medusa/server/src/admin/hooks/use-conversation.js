"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.useConversation = useConversation;
const react_1 = require("react");
const react_router_dom_1 = require("react-router-dom");
const ui_1 = require("@medusajs/ui");
const admin_client_1 = require("../lib/admin-client");
const sdk_1 = require("../lib/sdk");
function useConversation(dataSetId) {
    const { chatId } = (0, react_router_dom_1.useParams)();
    const location = (0, react_router_dom_1.useLocation)();
    const navigate = (0, react_router_dom_1.useNavigate)();
    const isNew = chatId === "new";
    const conversationId = !isNew && chatId ? parseInt(chatId, 10) : undefined;
    const queryParams = new URLSearchParams(location.search);
    const agentIdFromUrl = queryParams.get("agent")
        ? parseInt(queryParams.get("agent"), 10)
        : undefined;
    const locationState = location.state;
    const pendingMessage = locationState?.pendingMessage;
    const [conversation, setConversation] = (0, react_1.useState)(null);
    const [isContentLoading, setIsContentLoading] = (0, react_1.useState)(!isNew);
    const [isLoading, setIsLoading] = (0, react_1.useState)(false);
    const [isAgentLoading, setIsAgentLoading] = (0, react_1.useState)(false);
    const [agentAction, setAgentAction] = (0, react_1.useState)("Thinking...");
    const [messages, setMessages] = (0, react_1.useState)([]);
    const [agentId, setAgentId] = (0, react_1.useState)(agentIdFromUrl);
    const [agentDetails, setAgentDetails] = (0, react_1.useState)();
    const usePolling = (0, react_1.useRef)(true);
    const streamingEnabled = (0, react_1.useRef)(false);
    const initialized = (0, react_1.useRef)(false);
    const currentTaskHandleRef = (0, react_1.useRef)(null);
    const lastAddedMessageIdRef = (0, react_1.useRef)(null);
    const lastMessageRef = (0, react_1.useRef)(null);
    const abortStreamRef = (0, react_1.useRef)(null);
    const isAgentDeleted = !!conversation?.agent.deleted_at;
    const isAgentCorrupted = !!conversation?.agent.corrupted;
    const scrollToLastMessage = (timeout = 0) => {
        setTimeout(() => {
            lastMessageRef.current?.scrollIntoView({ behavior: "smooth" });
        }, timeout);
    };
    // Cleanup SSE stream on unmount
    (0, react_1.useEffect)(() => {
        return () => {
            if (abortStreamRef.current) {
                abortStreamRef.current();
                abortStreamRef.current = null;
            }
        };
    }, []);
    // Reset and load when chatId changes
    (0, react_1.useEffect)(() => {
        if (abortStreamRef.current) {
            abortStreamRef.current();
            abortStreamRef.current = null;
        }
        initialized.current = false;
        currentTaskHandleRef.current = null;
        lastAddedMessageIdRef.current = null;
        setMessages([]);
        setConversation(null);
        setAgentDetails(undefined);
        if (isNew) {
            setAgentId(agentIdFromUrl);
            setIsContentLoading(false);
            return;
        }
        setIsContentLoading(true);
        const checkStream = async () => {
            try {
                const streamStatus = await admin_client_1.adminApiClient.conversations().getStreamStatus();
                streamingEnabled.current = streamStatus.active;
            }
            catch {
                streamingEnabled.current = false;
            }
        };
        const loadMessages = async () => {
            const conv = await admin_client_1.adminApiClient.conversations().getConversation(conversationId);
            // Guard: only allow access to conversations that belong to the active dataset.
            // The sidebar already filters by dataset, but a user could manually type a URL
            // with a conversation ID from a different dataset. This is a frontend-only check, since
            // Enthusiast itself does not restrict access to conversations besides the active dataset.
            if (String(conv.agent.dataset) !== String(dataSetId)) {
                ui_1.toast.error("Conversation not found.", {
                    description: "This conversation does not belong to the active dataset.",
                    position: "top-right",
                });
                navigate("/enthusiast", { replace: true });
                return;
            }
            setConversation(conv);
            setAgentId(conv.agent?.id);
            if (pendingMessage && !initialized.current) {
                initialized.current = true;
                setIsContentLoading(false);
                // Send the pending message in the background — do NOT await it here,
                // as createSseConnection blocks until the entire stream completes.
                void onMessageComposerSubmit(pendingMessage);
                return;
            }
            const initialMessages = conv.history;
            setMessages(initialMessages);
            setIsContentLoading(false);
            scrollToLastMessage(100);
        };
        void (async () => {
            await checkStream();
            await loadMessages();
        })();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [chatId]);
    // When switching agents on the 'new' chat, only the query param changes (chatId stays 'new')
    // so the main chatId effect won't fire — update agentId explicitly here
    (0, react_1.useEffect)(() => {
        if (!isNew || agentIdFromUrl === undefined)
            return;
        setAgentId(agentIdFromUrl);
        setAgentDetails(undefined);
        setIsContentLoading(true);
    }, [isNew, agentIdFromUrl]);
    // Load agent details when agentId becomes available or changes
    (0, react_1.useEffect)(() => {
        if (!agentId || agentDetails)
            return;
        const loadAgentDetails = async () => {
            try {
                const details = await admin_client_1.adminApiClient.agents().getAgentById(agentId);
                setAgentDetails(details);
            }
            catch (error) {
                console.error("Failed to load agent details:", error);
            }
            finally {
                setIsContentLoading(false);
            }
        };
        void loadAgentDetails();
    }, [agentId, agentDetails]);
    const handleSseMessage = (eventType, payload) => {
        const handlers = {
            on_parser_start: () => {
                setIsAgentLoading(true);
            },
            on_parser_stream: () => {
                const chunk = payload?.chunk;
                if (chunk === undefined || chunk === null) {
                    console.warn("Missing chunk in payload:", payload);
                    return;
                }
                const chunkStr = String(chunk);
                setIsLoading(false);
                if (chunkStr.trim().length > 0) {
                    setIsAgentLoading(false);
                }
                setMessages((prevMessages) => {
                    const lastMessage = prevMessages[prevMessages.length - 1];
                    if (lastMessage && lastMessage.type === "ai" && lastMessage.id === null) {
                        return [
                            ...prevMessages.slice(0, -1),
                            { ...lastMessage, text: lastMessage.text + chunkStr },
                        ];
                    }
                    else {
                        return [...prevMessages, { type: "ai", text: chunkStr, id: null }];
                    }
                });
                scrollToLastMessage();
            },
            message_id: () => {
                setMessages((prevMessages) => {
                    const lastMessage = prevMessages[prevMessages.length - 1];
                    lastMessage.id = payload.output;
                    return [...prevMessages.slice(0, -1), lastMessage];
                });
            },
            action: () => {
                setAgentAction(payload.output || "Thinking...");
                setIsAgentLoading(true);
            },
            error: () => {
                setIsLoading(false);
                setIsAgentLoading(false);
                setMessages((prevMessages) => [
                    ...prevMessages,
                    { type: "system", text: payload.output || "An error occurred", id: null },
                ]);
            },
        };
        const handler = handlers[eventType];
        if (handler) {
            handler();
        }
    };
    const createSseConnection = async (convId) => {
        try {
            if (abortStreamRef.current) {
                abortStreamRef.current();
                abortStreamRef.current = null;
            }
            const { stream, abort } = await sdk_1.enthusiastAdminSdk.client.fetchStream(`/enthusiast/conversations/${convId}/stream`);
            if (!stream) {
                usePolling.current = true;
                return false;
            }
            abortStreamRef.current = abort;
            const processEvent = async (stream) => {
                try {
                    for await (const chunk of stream) {
                        const eventType = chunk.event;
                        const eventData = chunk.data;
                        if (!eventType || !eventData || eventData.length === 0) {
                            continue;
                        }
                        const dataObj = JSON.parse(eventData);
                        handleSseMessage(eventType, dataObj);
                    }
                }
                catch (error) {
                    if (error instanceof Error && error.name !== "AbortError") {
                        console.error("SSE stream error:", error);
                        usePolling.current = true;
                    }
                }
                finally {
                    abortStreamRef.current = null;
                }
            };
            await processEvent(stream);
            return true;
        }
        catch (error) {
            console.error("Failed to create SSE connection:", error);
            usePolling.current = true;
            return false;
        }
    };
    const updateTaskStatus = async (convId, taskHandle, streaming) => {
        if (streaming)
            return;
        if (currentTaskHandleRef.current?.task_id !== taskHandle.task_id)
            return;
        try {
            const response = await admin_client_1.adminApiClient
                .conversations()
                .fetchResponseMessage(convId, taskHandle);
            if (response) {
                if (response.id && response.id === lastAddedMessageIdRef.current) {
                    setIsAgentLoading(false);
                    setIsLoading(false);
                    return;
                }
                setIsAgentLoading(false);
                setMessages((prev) => {
                    const messageExists = prev.some((msg) => msg.type === "ai" && msg.id === response.id);
                    if (messageExists)
                        return prev;
                    return [...prev, { type: "ai", text: response.text, id: response.id }];
                });
                if (response.id) {
                    lastAddedMessageIdRef.current = response.id;
                }
                setIsLoading(false);
                scrollToLastMessage();
            }
            else {
                setTimeout(() => {
                    void updateTaskStatus(convId, taskHandle, streaming);
                }, 2000);
            }
        }
        catch {
            setIsLoading(false);
            setIsAgentLoading(false);
        }
    };
    const onMessageComposerSubmit = async (message) => {
        const convId = conversationId;
        setIsLoading(true);
        setIsAgentLoading(true);
        setMessages((prev) => {
            const messageExists = prev.some((msg) => msg.type === "human" && msg.text === message.text && msg.id === null);
            if (!messageExists) {
                const fileMessages = message.files.map((file) => ({
                    id: null,
                    type: "file",
                    file_name: file.name,
                    file_type: file.type,
                }));
                return [
                    ...prev,
                    ...fileMessages,
                    { type: "human", text: message.text, id: null },
                ];
            }
            return prev;
        });
        scrollToLastMessage(100);
        const taskHandle = await admin_client_1.adminApiClient.conversations().sendMessage(convId, dataSetId, message.text, streamingEnabled.current, message.files.map((f) => f.id));
        currentTaskHandleRef.current = taskHandle;
        usePolling.current = !taskHandle.streaming;
        if (pendingMessage && message.text === pendingMessage.text) {
            navigate(`/enthusiast/chat/${convId}`, { replace: true, state: {} });
        }
        if (taskHandle.streaming) {
            const connected = await createSseConnection(convId);
            if (!connected) {
                usePolling.current = true;
            }
        }
        try {
            void updateTaskStatus(convId, taskHandle, !usePolling);
        }
        catch {
            setIsLoading(false);
            setIsAgentLoading(false);
        }
    };
    const onSubmitNewChat = (message, createdConversationId) => {
        void (async () => {
            const newConversationId = createdConversationId ??
                (await admin_client_1.adminApiClient.conversations().createConversation(agentId));
            navigate(`/enthusiast/chat/${newConversationId}`, {
                state: { pendingMessage: message },
                replace: true,
            });
        })();
    };
    return {
        isNew,
        conversationId,
        agentIdFromUrl,
        agentId,
        agentDetails,
        conversation,
        messages,
        isContentLoading,
        isLoading,
        isAgentLoading,
        agentAction,
        isAgentDeleted,
        isAgentCorrupted,
        lastMessageRef,
        onMessageComposerSubmit,
        onSubmitNewChat,
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNlLWNvbnZlcnNhdGlvbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9hZG1pbi9ob29rcy91c2UtY29udmVyc2F0aW9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBYUEsMENBbVlDO0FBaFpELGlDQUFvRDtBQUNwRCx1REFBdUU7QUFDdkUscUNBQXFDO0FBQ3JDLHNEQUFxRDtBQUNyRCxvQ0FBZ0Q7QUFTaEQsU0FBZ0IsZUFBZSxDQUFDLFNBQWlCO0lBQy9DLE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRyxJQUFBLDRCQUFTLEdBQUUsQ0FBQztJQUMvQixNQUFNLFFBQVEsR0FBRyxJQUFBLDhCQUFXLEdBQUUsQ0FBQztJQUMvQixNQUFNLFFBQVEsR0FBRyxJQUFBLDhCQUFXLEdBQUUsQ0FBQztJQUUvQixNQUFNLEtBQUssR0FBRyxNQUFNLEtBQUssS0FBSyxDQUFDO0lBQy9CLE1BQU0sY0FBYyxHQUFHLENBQUMsS0FBSyxJQUFJLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0lBRTNFLE1BQU0sV0FBVyxHQUFHLElBQUksZUFBZSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUN6RCxNQUFNLGNBQWMsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQztRQUM3QyxDQUFDLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFFLEVBQUUsRUFBRSxDQUFDO1FBQ3pDLENBQUMsQ0FBQyxTQUFTLENBQUM7SUFFZCxNQUFNLGFBQWEsR0FBRyxRQUFRLENBQUMsS0FBNEMsQ0FBQztJQUM1RSxNQUFNLGNBQWMsR0FBRyxhQUFhLEVBQUUsY0FBYyxDQUFDO0lBRXJELE1BQU0sQ0FBQyxZQUFZLEVBQUUsZUFBZSxDQUFDLEdBQUcsSUFBQSxnQkFBUSxFQUE0QixJQUFJLENBQUMsQ0FBQztJQUNsRixNQUFNLENBQUMsZ0JBQWdCLEVBQUUsbUJBQW1CLENBQUMsR0FBRyxJQUFBLGdCQUFRLEVBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNqRSxNQUFNLENBQUMsU0FBUyxFQUFFLFlBQVksQ0FBQyxHQUFHLElBQUEsZ0JBQVEsRUFBQyxLQUFLLENBQUMsQ0FBQztJQUNsRCxNQUFNLENBQUMsY0FBYyxFQUFFLGlCQUFpQixDQUFDLEdBQUcsSUFBQSxnQkFBUSxFQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzVELE1BQU0sQ0FBQyxXQUFXLEVBQUUsY0FBYyxDQUFDLEdBQUcsSUFBQSxnQkFBUSxFQUFTLGFBQWEsQ0FBQyxDQUFDO0lBQ3RFLE1BQU0sQ0FBQyxRQUFRLEVBQUUsV0FBVyxDQUFDLEdBQUcsSUFBQSxnQkFBUSxFQUFpQixFQUFFLENBQUMsQ0FBQztJQUM3RCxNQUFNLENBQUMsT0FBTyxFQUFFLFVBQVUsQ0FBQyxHQUFHLElBQUEsZ0JBQVEsRUFBcUIsY0FBYyxDQUFDLENBQUM7SUFDM0UsTUFBTSxDQUFDLFlBQVksRUFBRSxlQUFlLENBQUMsR0FBRyxJQUFBLGdCQUFRLEdBQTRCLENBQUM7SUFFN0UsTUFBTSxVQUFVLEdBQUcsSUFBQSxjQUFNLEVBQVUsSUFBSSxDQUFDLENBQUM7SUFDekMsTUFBTSxnQkFBZ0IsR0FBRyxJQUFBLGNBQU0sRUFBVSxLQUFLLENBQUMsQ0FBQztJQUNoRCxNQUFNLFdBQVcsR0FBRyxJQUFBLGNBQU0sRUFBQyxLQUFLLENBQUMsQ0FBQztJQUNsQyxNQUFNLG9CQUFvQixHQUFHLElBQUEsY0FBTSxFQUFvQixJQUFJLENBQUMsQ0FBQztJQUM3RCxNQUFNLHFCQUFxQixHQUFHLElBQUEsY0FBTSxFQUFnQixJQUFJLENBQUMsQ0FBQztJQUMxRCxNQUFNLGNBQWMsR0FBRyxJQUFBLGNBQU0sRUFBd0IsSUFBSSxDQUFDLENBQUM7SUFDM0QsTUFBTSxjQUFjLEdBQUcsSUFBQSxjQUFNLEVBQXNCLElBQUksQ0FBQyxDQUFDO0lBRXpELE1BQU0sY0FBYyxHQUFHLENBQUMsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLFVBQVUsQ0FBQztJQUN4RCxNQUFNLGdCQUFnQixHQUFHLENBQUMsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLFNBQVMsQ0FBQztJQUV6RCxNQUFNLG1CQUFtQixHQUFHLENBQUMsT0FBTyxHQUFHLENBQUMsRUFBRSxFQUFFO1FBQzFDLFVBQVUsQ0FBQyxHQUFHLEVBQUU7WUFDZCxjQUFjLENBQUMsT0FBTyxFQUFFLGNBQWMsQ0FBQyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO1FBQ2pFLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUNkLENBQUMsQ0FBQztJQUVGLGdDQUFnQztJQUNoQyxJQUFBLGlCQUFTLEVBQUMsR0FBRyxFQUFFO1FBQ2IsT0FBTyxHQUFHLEVBQUU7WUFDVixJQUFJLGNBQWMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDM0IsY0FBYyxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUN6QixjQUFjLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztZQUNoQyxDQUFDO1FBQ0gsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBRVAscUNBQXFDO0lBQ3JDLElBQUEsaUJBQVMsRUFBQyxHQUFHLEVBQUU7UUFDYixJQUFJLGNBQWMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUMzQixjQUFjLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDekIsY0FBYyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFDaEMsQ0FBQztRQUVELFdBQVcsQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO1FBQzVCLG9CQUFvQixDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFDcEMscUJBQXFCLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztRQUNyQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDaEIsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3RCLGVBQWUsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUUzQixJQUFJLEtBQUssRUFBRSxDQUFDO1lBQ1YsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1lBQzNCLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQzNCLE9BQU87UUFDVCxDQUFDO1FBRUQsbUJBQW1CLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFMUIsTUFBTSxXQUFXLEdBQUcsS0FBSyxJQUFJLEVBQUU7WUFDN0IsSUFBSSxDQUFDO2dCQUNILE1BQU0sWUFBWSxHQUFHLE1BQU0sNkJBQWMsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxlQUFlLEVBQUUsQ0FBQztnQkFDNUUsZ0JBQWdCLENBQUMsT0FBTyxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUM7WUFDakQsQ0FBQztZQUFDLE1BQU0sQ0FBQztnQkFDUCxnQkFBZ0IsQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO1lBQ25DLENBQUM7UUFDSCxDQUFDLENBQUM7UUFFRixNQUFNLFlBQVksR0FBRyxLQUFLLElBQUksRUFBRTtZQUM5QixNQUFNLElBQUksR0FBRyxNQUFNLDZCQUFjLENBQUMsYUFBYSxFQUFFLENBQUMsZUFBZSxDQUFDLGNBQWUsQ0FBQyxDQUFDO1lBRW5GLCtFQUErRTtZQUMvRSwrRUFBK0U7WUFDL0Usd0ZBQXdGO1lBQ3hGLDBGQUEwRjtZQUMxRixJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLE1BQU0sQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDO2dCQUNyRCxVQUFLLENBQUMsS0FBSyxDQUFDLHlCQUF5QixFQUFFO29CQUNyQyxXQUFXLEVBQUUsMERBQTBEO29CQUN2RSxRQUFRLEVBQUUsV0FBVztpQkFDdEIsQ0FBQyxDQUFDO2dCQUNILFFBQVEsQ0FBQyxhQUFhLEVBQUUsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztnQkFDM0MsT0FBTztZQUNULENBQUM7WUFFRCxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDdEIsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFFM0IsSUFBSSxjQUFjLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQzNDLFdBQVcsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO2dCQUMzQixtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDM0IscUVBQXFFO2dCQUNyRSxtRUFBbUU7Z0JBQ25FLEtBQUssdUJBQXVCLENBQUMsY0FBYyxDQUFDLENBQUM7Z0JBQzdDLE9BQU87WUFDVCxDQUFDO1lBRUQsTUFBTSxlQUFlLEdBQUcsSUFBSSxDQUFDLE9BQXlCLENBQUM7WUFDdkQsV0FBVyxDQUFDLGVBQWUsQ0FBQyxDQUFDO1lBQzdCLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQzNCLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzNCLENBQUMsQ0FBQztRQUVGLEtBQUssQ0FBQyxLQUFLLElBQUksRUFBRTtZQUNmLE1BQU0sV0FBVyxFQUFFLENBQUM7WUFDcEIsTUFBTSxZQUFZLEVBQUUsQ0FBQztRQUN2QixDQUFDLENBQUMsRUFBRSxDQUFDO1FBQ0wsdURBQXVEO0lBQ3pELENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFFYiw2RkFBNkY7SUFDN0Ysd0VBQXdFO0lBQ3hFLElBQUEsaUJBQVMsRUFBQyxHQUFHLEVBQUU7UUFDYixJQUFJLENBQUMsS0FBSyxJQUFJLGNBQWMsS0FBSyxTQUFTO1lBQUUsT0FBTztRQUNuRCxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDM0IsZUFBZSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzNCLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzVCLENBQUMsRUFBRSxDQUFDLEtBQUssRUFBRSxjQUFjLENBQUMsQ0FBQyxDQUFDO0lBRTVCLCtEQUErRDtJQUMvRCxJQUFBLGlCQUFTLEVBQUMsR0FBRyxFQUFFO1FBQ2IsSUFBSSxDQUFDLE9BQU8sSUFBSSxZQUFZO1lBQUUsT0FBTztRQUVyQyxNQUFNLGdCQUFnQixHQUFHLEtBQUssSUFBSSxFQUFFO1lBQ2xDLElBQUksQ0FBQztnQkFDSCxNQUFNLE9BQU8sR0FBRyxNQUFNLDZCQUFjLENBQUMsTUFBTSxFQUFFLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUNwRSxlQUFlLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDM0IsQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQywrQkFBK0IsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUN4RCxDQUFDO29CQUFTLENBQUM7Z0JBQ1QsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDN0IsQ0FBQztRQUNILENBQUMsQ0FBQztRQUVGLEtBQUssZ0JBQWdCLEVBQUUsQ0FBQztJQUMxQixDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQztJQUU1QixNQUFNLGdCQUFnQixHQUFHLENBQUMsU0FBaUIsRUFBRSxPQUE4QyxFQUFFLEVBQUU7UUFDN0YsTUFBTSxRQUFRLEdBQStCO1lBQzNDLGVBQWUsRUFBRSxHQUFHLEVBQUU7Z0JBQ3BCLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzFCLENBQUM7WUFDRCxnQkFBZ0IsRUFBRSxHQUFHLEVBQUU7Z0JBQ3JCLE1BQU0sS0FBSyxHQUFHLE9BQU8sRUFBRSxLQUFLLENBQUM7Z0JBRTdCLElBQUksS0FBSyxLQUFLLFNBQVMsSUFBSSxLQUFLLEtBQUssSUFBSSxFQUFFLENBQUM7b0JBQzFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsMkJBQTJCLEVBQUUsT0FBTyxDQUFDLENBQUM7b0JBQ25ELE9BQU87Z0JBQ1QsQ0FBQztnQkFFRCxNQUFNLFFBQVEsR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBRS9CLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDcEIsSUFBSSxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO29CQUMvQixpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDM0IsQ0FBQztnQkFFRCxXQUFXLENBQUMsQ0FBQyxZQUFZLEVBQUUsRUFBRTtvQkFDM0IsTUFBTSxXQUFXLEdBQUcsWUFBWSxDQUFDLFlBQVksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7b0JBRTFELElBQUksV0FBVyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEtBQUssSUFBSSxJQUFJLFdBQVcsQ0FBQyxFQUFFLEtBQUssSUFBSSxFQUFFLENBQUM7d0JBQ3hFLE9BQU87NEJBQ0wsR0FBRyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDNUIsRUFBRSxHQUFHLFdBQVcsRUFBRSxJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksR0FBRyxRQUFRLEVBQUU7eUJBQ3RELENBQUM7b0JBQ0osQ0FBQzt5QkFBTSxDQUFDO3dCQUNOLE9BQU8sQ0FBQyxHQUFHLFlBQVksRUFBRSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztvQkFDckUsQ0FBQztnQkFDSCxDQUFDLENBQUMsQ0FBQztnQkFFSCxtQkFBbUIsRUFBRSxDQUFDO1lBQ3hCLENBQUM7WUFDRCxVQUFVLEVBQUUsR0FBRyxFQUFFO2dCQUNmLFdBQVcsQ0FBQyxDQUFDLFlBQVksRUFBRSxFQUFFO29CQUMzQixNQUFNLFdBQVcsR0FBRyxZQUFZLENBQUMsWUFBWSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztvQkFDMUQsV0FBVyxDQUFDLEVBQUUsR0FBRyxPQUFPLENBQUMsTUFBdUIsQ0FBQztvQkFDakQsT0FBTyxDQUFDLEdBQUcsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxXQUFXLENBQUMsQ0FBQztnQkFDckQsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDO1lBQ0QsTUFBTSxFQUFFLEdBQUcsRUFBRTtnQkFDWCxjQUFjLENBQUUsT0FBTyxDQUFDLE1BQWlCLElBQUksYUFBYSxDQUFDLENBQUM7Z0JBQzVELGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzFCLENBQUM7WUFDRCxLQUFLLEVBQUUsR0FBRyxFQUFFO2dCQUNWLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDcEIsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ3pCLFdBQVcsQ0FBQyxDQUFDLFlBQVksRUFBRSxFQUFFLENBQUM7b0JBQzVCLEdBQUcsWUFBWTtvQkFDZixFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFHLE9BQU8sQ0FBQyxNQUFpQixJQUFJLG1CQUFtQixFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQUU7aUJBQ3RGLENBQUMsQ0FBQztZQUNMLENBQUM7U0FDRixDQUFDO1FBRUYsTUFBTSxPQUFPLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3BDLElBQUksT0FBTyxFQUFFLENBQUM7WUFDWixPQUFPLEVBQUUsQ0FBQztRQUNaLENBQUM7SUFDSCxDQUFDLENBQUM7SUFFRixNQUFNLG1CQUFtQixHQUFHLEtBQUssRUFBRSxNQUFjLEVBQW9CLEVBQUU7UUFDckUsSUFBSSxDQUFDO1lBQ0gsSUFBSSxjQUFjLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQzNCLGNBQWMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDekIsY0FBYyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7WUFDaEMsQ0FBQztZQUVELE1BQU0sRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUcsTUFBTSx3QkFBa0IsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUNuRSw2QkFBNkIsTUFBTSxTQUFTLENBQzdDLENBQUM7WUFFRixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ1osVUFBVSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7Z0JBQzFCLE9BQU8sS0FBSyxDQUFDO1lBQ2YsQ0FBQztZQUVELGNBQWMsQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO1lBRS9CLE1BQU0sWUFBWSxHQUFHLEtBQUssRUFBRSxNQUF3RCxFQUFFLEVBQUU7Z0JBQ3RGLElBQUksQ0FBQztvQkFDSCxJQUFJLEtBQUssRUFBRSxNQUFNLEtBQUssSUFBSSxNQUFNLEVBQUUsQ0FBQzt3QkFDakMsTUFBTSxTQUFTLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQzt3QkFDOUIsTUFBTSxTQUFTLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQzt3QkFDN0IsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLFNBQVMsSUFBSSxTQUFTLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDOzRCQUN2RCxTQUFTO3dCQUNYLENBQUM7d0JBQ0QsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQTBDLENBQUM7d0JBQy9FLGdCQUFnQixDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQztvQkFDdkMsQ0FBQztnQkFDSCxDQUFDO2dCQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7b0JBQ2YsSUFBSSxLQUFLLFlBQVksS0FBSyxJQUFJLEtBQUssQ0FBQyxJQUFJLEtBQUssWUFBWSxFQUFFLENBQUM7d0JBQzFELE9BQU8sQ0FBQyxLQUFLLENBQUMsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLENBQUM7d0JBQzFDLFVBQVUsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO29CQUM1QixDQUFDO2dCQUNILENBQUM7d0JBQVMsQ0FBQztvQkFDVCxjQUFjLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztnQkFDaEMsQ0FBQztZQUNILENBQUMsQ0FBQztZQUVGLE1BQU0sWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzNCLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLGtDQUFrQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ3pELFVBQVUsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1lBQzFCLE9BQU8sS0FBSyxDQUFDO1FBQ2YsQ0FBQztJQUNILENBQUMsQ0FBQztJQUVGLE1BQU0sZ0JBQWdCLEdBQUcsS0FBSyxFQUFFLE1BQWMsRUFBRSxVQUFzQixFQUFFLFNBQWtCLEVBQUUsRUFBRTtRQUM1RixJQUFJLFNBQVM7WUFBRSxPQUFPO1FBQ3RCLElBQUksb0JBQW9CLENBQUMsT0FBTyxFQUFFLE9BQU8sS0FBSyxVQUFVLENBQUMsT0FBTztZQUFFLE9BQU87UUFFekUsSUFBSSxDQUFDO1lBQ0gsTUFBTSxRQUFRLEdBQUcsTUFBTSw2QkFBYztpQkFDbEMsYUFBYSxFQUFFO2lCQUNmLG9CQUFvQixDQUFDLE1BQU0sRUFBRSxVQUFVLENBQUMsQ0FBQztZQUU1QyxJQUFJLFFBQVEsRUFBRSxDQUFDO2dCQUNiLElBQUksUUFBUSxDQUFDLEVBQUUsSUFBSSxRQUFRLENBQUMsRUFBRSxLQUFLLHFCQUFxQixDQUFDLE9BQU8sRUFBRSxDQUFDO29CQUNqRSxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDekIsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO29CQUNwQixPQUFPO2dCQUNULENBQUM7Z0JBRUQsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ3pCLFdBQVcsQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFO29CQUNuQixNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsSUFBSSxLQUFLLElBQUksSUFBSSxHQUFHLENBQUMsRUFBRSxLQUFLLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQztvQkFDdEYsSUFBSSxhQUFhO3dCQUFFLE9BQU8sSUFBSSxDQUFDO29CQUMvQixPQUFPLENBQUMsR0FBRyxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxRQUFRLENBQUMsSUFBSSxFQUFFLEVBQUUsRUFBRSxRQUFRLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDekUsQ0FBQyxDQUFDLENBQUM7Z0JBRUgsSUFBSSxRQUFRLENBQUMsRUFBRSxFQUFFLENBQUM7b0JBQ2hCLHFCQUFxQixDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUMsRUFBRSxDQUFDO2dCQUM5QyxDQUFDO2dCQUNELFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDcEIsbUJBQW1CLEVBQUUsQ0FBQztZQUN4QixDQUFDO2lCQUFNLENBQUM7Z0JBQ04sVUFBVSxDQUFDLEdBQUcsRUFBRTtvQkFDZCxLQUFLLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxVQUFVLEVBQUUsU0FBUyxDQUFDLENBQUM7Z0JBQ3ZELENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztZQUNYLENBQUM7UUFDSCxDQUFDO1FBQUMsTUFBTSxDQUFDO1lBQ1AsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3BCLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzNCLENBQUM7SUFDSCxDQUFDLENBQUM7SUFFRixNQUFNLHVCQUF1QixHQUFHLEtBQUssRUFBRSxPQUFnQixFQUFFLEVBQUU7UUFDekQsTUFBTSxNQUFNLEdBQUcsY0FBZSxDQUFDO1FBRS9CLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNuQixpQkFBaUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN4QixXQUFXLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRTtZQUNuQixNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUM3QixDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLElBQUksS0FBSyxPQUFPLElBQUksR0FBRyxDQUFDLElBQUksS0FBSyxPQUFPLENBQUMsSUFBSSxJQUFJLEdBQUcsQ0FBQyxFQUFFLEtBQUssSUFBSSxDQUM5RSxDQUFDO1lBRUYsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUNuQixNQUFNLFlBQVksR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBbUIsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBQ2xFLEVBQUUsRUFBRSxJQUFJO29CQUNSLElBQUksRUFBRSxNQUFNO29CQUNaLFNBQVMsRUFBRSxJQUFJLENBQUMsSUFBSTtvQkFDcEIsU0FBUyxFQUFFLElBQUksQ0FBQyxJQUFJO2lCQUNyQixDQUFDLENBQUMsQ0FBQztnQkFDSixPQUFPO29CQUNMLEdBQUcsSUFBSTtvQkFDUCxHQUFHLFlBQVk7b0JBQ2YsRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLEVBQUUsRUFBRSxJQUFJLEVBQWtCO2lCQUNoRSxDQUFDO1lBQ0osQ0FBQztZQUNELE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQyxDQUFDLENBQUM7UUFFSCxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUV6QixNQUFNLFVBQVUsR0FBRyxNQUFNLDZCQUFjLENBQUMsYUFBYSxFQUFFLENBQUMsV0FBVyxDQUNqRSxNQUFNLEVBQ04sU0FBUyxFQUNULE9BQU8sQ0FBQyxJQUFJLEVBQ1osZ0JBQWdCLENBQUMsT0FBTyxFQUN4QixPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUMvQixDQUFDO1FBQ0Ysb0JBQW9CLENBQUMsT0FBTyxHQUFHLFVBQVUsQ0FBQztRQUMxQyxVQUFVLENBQUMsT0FBTyxHQUFHLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQztRQUUzQyxJQUFJLGNBQWMsSUFBSSxPQUFPLENBQUMsSUFBSSxLQUFLLGNBQWMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUMzRCxRQUFRLENBQUMsb0JBQW9CLE1BQU0sRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUN2RSxDQUFDO1FBRUQsSUFBSSxVQUFVLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDekIsTUFBTSxTQUFTLEdBQUcsTUFBTSxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNwRCxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7Z0JBQ2YsVUFBVSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7WUFDNUIsQ0FBQztRQUNILENBQUM7UUFFRCxJQUFJLENBQUM7WUFDSCxLQUFLLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxVQUFVLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUN6RCxDQUFDO1FBQUMsTUFBTSxDQUFDO1lBQ1AsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3BCLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzNCLENBQUM7SUFDSCxDQUFDLENBQUM7SUFFRixNQUFNLGVBQWUsR0FBYSxDQUFDLE9BQU8sRUFBRSxxQkFBcUIsRUFBRSxFQUFFO1FBQ25FLEtBQUssQ0FBQyxLQUFLLElBQUksRUFBRTtZQUNmLE1BQU0saUJBQWlCLEdBQ3JCLHFCQUFxQjtnQkFDckIsQ0FBQyxNQUFNLDZCQUFjLENBQUMsYUFBYSxFQUFFLENBQUMsa0JBQWtCLENBQUMsT0FBUSxDQUFDLENBQUMsQ0FBQztZQUN0RSxRQUFRLENBQUMsb0JBQW9CLGlCQUFpQixFQUFFLEVBQUU7Z0JBQ2hELEtBQUssRUFBRSxFQUFFLGNBQWMsRUFBRSxPQUFPLEVBQUU7Z0JBQ2xDLE9BQU8sRUFBRSxJQUFJO2FBQ2QsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLEVBQUUsQ0FBQztJQUNQLENBQUMsQ0FBQztJQUVGLE9BQU87UUFDTCxLQUFLO1FBQ0wsY0FBYztRQUNkLGNBQWM7UUFDZCxPQUFPO1FBQ1AsWUFBWTtRQUNaLFlBQVk7UUFDWixRQUFRO1FBQ1IsZ0JBQWdCO1FBQ2hCLFNBQVM7UUFDVCxjQUFjO1FBQ2QsV0FBVztRQUNYLGNBQWM7UUFDZCxnQkFBZ0I7UUFDaEIsY0FBYztRQUNkLHVCQUF1QjtRQUN2QixlQUFlO0tBQ2hCLENBQUM7QUFDSixDQUFDIn0=