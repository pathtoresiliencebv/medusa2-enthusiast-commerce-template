"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NewChat = NewChat;
const jsx_runtime_1 = require("react/jsx-runtime");
const react_1 = require("react");
const react_router_dom_1 = require("react-router-dom");
const page_main_1 = require("../utils/page-main");
const page_heading_1 = require("../utils/page-heading");
const chat_window_1 = require("./chat-window");
const chat_sidebar_1 = require("./chat-sidebar");
const admin_client_1 = require("../../admin/lib/admin-client");
const spinner_1 = require("../../components/utils/spinner");
const ui_1 = require("@medusajs/ui");
function NewChat({ datasetId, onPendingMessage }) {
    const location = (0, react_router_dom_1.useLocation)();
    const queryParams = new URLSearchParams(location.search);
    const agent = queryParams.get("agent");
    const agentId = agent ? parseInt(agent, 10) : null;
    const [isLoading, setIsLoading] = (0, react_1.useState)(true);
    const [agents, setAgents] = (0, react_1.useState)([]);
    const [agentDetails, setAgentDetails] = (0, react_1.useState)(null);
    (0, react_1.useEffect)(() => {
        if (!datasetId)
            return;
        const fetchDatasetAgents = async () => {
            try {
                setIsLoading(true);
                const res = await admin_client_1.adminApiClient.agents().getDatasetAgents(datasetId);
                setAgents(res);
            }
            finally {
                setIsLoading(false);
            }
        };
        const fetchAgentDetails = async () => {
            if (!agentId) {
                return;
            }
            try {
                setIsLoading(true);
                const res = await admin_client_1.adminApiClient.agents().getAgentById(agentId);
                setAgentDetails(res);
            }
            finally {
                setIsLoading(false);
            }
        };
        void fetchDatasetAgents();
        void fetchAgentDetails();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [datasetId]);
    if (!agent) {
        ui_1.toast.info("No agent.", {
            description: "Choose an agent to start a chat.",
        });
        return (0, jsx_runtime_1.jsx)(react_router_dom_1.Navigate, { to: "/enthusiast", replace: true });
    }
    const selectedAgent = agentId ? agents.find((agentObj) => agentObj.id === agentId) : null;
    const emptyState = (() => {
        if (agents.length === 0) {
            return {
                title: "No Agents Available",
                description: "There are currently no agents available for this dataset.",
                pageTitle: "No Agents Available",
                pageDescription: "There are currently no agents for this dataset.",
            };
        }
        if (!agentId) {
            return {
                title: "No Agent Selected",
                description: "Please choose an agent from the sidebar to start a new conversation.",
                pageTitle: "Choose Agent",
                pageDescription: "Select an agent to start a conversation.",
            };
        }
        if (!selectedAgent) {
            return {
                title: "Agent Not Found",
                description: "The selected agent could not be found or may have been removed.",
                pageTitle: "Agent Not Found",
                pageDescription: "The requested agent is not available.",
            };
        }
        return false;
    })();
    const onSubmit = (message, createdConversationId) => {
        void (async () => {
            const conversationId = createdConversationId ||
                (await admin_client_1.adminApiClient.conversations().createConversation(selectedAgent.id));
            onPendingMessage(message, conversationId);
        })();
    };
    if (isLoading) {
        return (0, jsx_runtime_1.jsx)(spinner_1.LoadingSpinner, {});
    }
    return ((0, jsx_runtime_1.jsxs)("div", { className: "flex h-screen overflow-hidden", children: [(0, jsx_runtime_1.jsx)("div", { className: "flex-1 flex flex-col min-w-0 overflow-hidden px-1 py-2", children: (0, jsx_runtime_1.jsxs)(page_main_1.PageMain, { className: "h-full", children: [(0, jsx_runtime_1.jsx)(page_heading_1.PageHeading, { title: (emptyState && emptyState.title) || selectedAgent.name, description: (emptyState && emptyState.description) || "Start a new conversation.", className: "flex-shrink-0 bg-background z-[1] px-8" }), emptyState ? ((0, jsx_runtime_1.jsx)("div", { className: "flex flex-col flex-1 overflow-y-auto px-4 pt-4", children: (0, jsx_runtime_1.jsx)("div", { className: "grow flex items-center justify-center", children: (0, jsx_runtime_1.jsxs)("div", { className: "text-center space-y-4", children: [(0, jsx_runtime_1.jsx)("h2", { className: "text-xl font-semibold text-gray-900", children: emptyState.title }), (0, jsx_runtime_1.jsx)("p", { className: "text-gray-600 max-w-md", children: emptyState.description })] }) }) })) : ((0, jsx_runtime_1.jsx)(chat_window_1.ChatWindow, { className: "flex-1 min-h-0 pt-4", onSubmit: onSubmit, isLoading: false, agentId: agentId ?? undefined, fileUploadEnabled: agentDetails?.file_upload, children: (0, jsx_runtime_1.jsx)("div", { className: "grow flex items-start justify-center pt-16", children: agentDetails?.description && ((0, jsx_runtime_1.jsx)("div", { className: "text-center space-y-4 max-w-2xl px-6", children: (0, jsx_runtime_1.jsx)("div", { className: "bg-background rounded-lg p-6", children: (0, jsx_runtime_1.jsx)("p", { className: "text-gray-500 text-base leading-relaxed", children: agentDetails.description }) }) })) }) }))] }) }), (0, jsx_runtime_1.jsx)(chat_sidebar_1.ChatSidebar, { currentAgentId: agentId })] }));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmV3LWNoYXQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvY29tcG9uZW50cy9jaGF0L25ldy1jaGF0LnRzeCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQWlCQSwwQkF1SUM7O0FBeEpELGlDQUE0QztBQUM1Qyx1REFBeUQ7QUFHekQsa0RBQThDO0FBQzlDLHdEQUFvRDtBQUNwRCwrQ0FBMkM7QUFDM0MsaURBQTZDO0FBQzdDLCtEQUE4RDtBQUM5RCw0REFBZ0U7QUFDaEUscUNBQXFDO0FBT3JDLFNBQWdCLE9BQU8sQ0FBQyxFQUFFLFNBQVMsRUFBRSxnQkFBZ0IsRUFBZ0I7SUFDbkUsTUFBTSxRQUFRLEdBQUcsSUFBQSw4QkFBVyxHQUFFLENBQUM7SUFFL0IsTUFBTSxXQUFXLEdBQUcsSUFBSSxlQUFlLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ3pELE1BQU0sS0FBSyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDdkMsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7SUFFbkQsTUFBTSxDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsR0FBRyxJQUFBLGdCQUFRLEVBQUMsSUFBSSxDQUFDLENBQUM7SUFDakQsTUFBTSxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUMsR0FBRyxJQUFBLGdCQUFRLEVBQVUsRUFBRSxDQUFDLENBQUM7SUFDbEQsTUFBTSxDQUFDLFlBQVksRUFBRSxlQUFlLENBQUMsR0FBRyxJQUFBLGdCQUFRLEVBQXNCLElBQUksQ0FBQyxDQUFDO0lBRTVFLElBQUEsaUJBQVMsRUFBQyxHQUFHLEVBQUU7UUFDYixJQUFJLENBQUMsU0FBUztZQUFFLE9BQU87UUFFdkIsTUFBTSxrQkFBa0IsR0FBRyxLQUFLLElBQUksRUFBRTtZQUNwQyxJQUFJLENBQUM7Z0JBQ0gsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNuQixNQUFNLEdBQUcsR0FBRyxNQUFNLDZCQUFjLENBQUMsTUFBTSxFQUFFLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQ3RFLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNqQixDQUFDO29CQUFTLENBQUM7Z0JBQ1QsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3RCLENBQUM7UUFDSCxDQUFDLENBQUM7UUFDRixNQUFNLGlCQUFpQixHQUFHLEtBQUssSUFBSSxFQUFFO1lBQ25DLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDYixPQUFPO1lBQ1QsQ0FBQztZQUNELElBQUksQ0FBQztnQkFDSCxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ25CLE1BQU0sR0FBRyxHQUFHLE1BQU0sNkJBQWMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQ2hFLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN2QixDQUFDO29CQUFTLENBQUM7Z0JBQ1QsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3RCLENBQUM7UUFDSCxDQUFDLENBQUM7UUFDRixLQUFLLGtCQUFrQixFQUFFLENBQUM7UUFDMUIsS0FBSyxpQkFBaUIsRUFBRSxDQUFDO1FBQ3pCLHVEQUF1RDtJQUN6RCxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0lBQ2hCLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNYLFVBQUssQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFO1lBQ3RCLFdBQVcsRUFBRSxrQ0FBa0M7U0FDaEQsQ0FBQyxDQUFDO1FBRUgsT0FBTyx1QkFBQywyQkFBUSxJQUFDLEVBQUUsRUFBQyxhQUFhLEVBQUMsT0FBTyxTQUFHLENBQUM7SUFDL0MsQ0FBQztJQUNELE1BQU0sYUFBYSxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUUsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0lBRTFGLE1BQU0sVUFBVSxHQUFHLENBQUMsR0FBRyxFQUFFO1FBQ3ZCLElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUN4QixPQUFPO2dCQUNMLEtBQUssRUFBRSxxQkFBcUI7Z0JBQzVCLFdBQVcsRUFBRSwyREFBMkQ7Z0JBQ3hFLFNBQVMsRUFBRSxxQkFBcUI7Z0JBQ2hDLGVBQWUsRUFBRSxpREFBaUQ7YUFDbkUsQ0FBQztRQUNKLENBQUM7UUFFRCxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDYixPQUFPO2dCQUNMLEtBQUssRUFBRSxtQkFBbUI7Z0JBQzFCLFdBQVcsRUFBRSxzRUFBc0U7Z0JBQ25GLFNBQVMsRUFBRSxjQUFjO2dCQUN6QixlQUFlLEVBQUUsMENBQTBDO2FBQzVELENBQUM7UUFDSixDQUFDO1FBRUQsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ25CLE9BQU87Z0JBQ0wsS0FBSyxFQUFFLGlCQUFpQjtnQkFDeEIsV0FBVyxFQUFFLGlFQUFpRTtnQkFDOUUsU0FBUyxFQUFFLGlCQUFpQjtnQkFDNUIsZUFBZSxFQUFFLHVDQUF1QzthQUN6RCxDQUFDO1FBQ0osQ0FBQztRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQyxDQUFDLEVBQUUsQ0FBQztJQUVMLE1BQU0sUUFBUSxHQUFhLENBQUMsT0FBTyxFQUFFLHFCQUFxQixFQUFFLEVBQUU7UUFDNUQsS0FBSyxDQUFDLEtBQUssSUFBSSxFQUFFO1lBQ2YsTUFBTSxjQUFjLEdBQ2xCLHFCQUFxQjtnQkFDckIsQ0FBQyxNQUFNLDZCQUFjLENBQUMsYUFBYSxFQUFFLENBQUMsa0JBQWtCLENBQUMsYUFBYyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDL0UsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLGNBQWMsQ0FBQyxDQUFDO1FBQzVDLENBQUMsQ0FBQyxFQUFFLENBQUM7SUFDUCxDQUFDLENBQUM7SUFDRixJQUFJLFNBQVMsRUFBRSxDQUFDO1FBQ2QsT0FBTyx1QkFBQyx3QkFBYyxLQUFHLENBQUM7SUFDNUIsQ0FBQztJQUVELE9BQU8sQ0FDTCxpQ0FBSyxTQUFTLEVBQUMsK0JBQStCLGFBQzVDLGdDQUFLLFNBQVMsRUFBQyx3REFBd0QsWUFDckUsd0JBQUMsb0JBQVEsSUFBQyxTQUFTLEVBQUMsUUFBUSxhQUMxQix1QkFBQywwQkFBVyxJQUNWLEtBQUssRUFBRSxDQUFDLFVBQVUsSUFBSSxVQUFVLENBQUMsS0FBSyxDQUFDLElBQUksYUFBYyxDQUFDLElBQUksRUFDOUQsV0FBVyxFQUFFLENBQUMsVUFBVSxJQUFJLFVBQVUsQ0FBQyxXQUFXLENBQUMsSUFBSSwyQkFBMkIsRUFDbEYsU0FBUyxFQUFDLHdDQUF3QyxHQUNsRCxFQUNELFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FDWixnQ0FBSyxTQUFTLEVBQUMsZ0RBQWdELFlBQzdELGdDQUFLLFNBQVMsRUFBQyx1Q0FBdUMsWUFDcEQsaUNBQUssU0FBUyxFQUFDLHVCQUF1QixhQUNwQywrQkFBSSxTQUFTLEVBQUMscUNBQXFDLFlBQUUsVUFBVSxDQUFDLEtBQUssR0FBTSxFQUMzRSw4QkFBRyxTQUFTLEVBQUMsd0JBQXdCLFlBQUUsVUFBVSxDQUFDLFdBQVcsR0FBSyxJQUM5RCxHQUNGLEdBQ0YsQ0FDUCxDQUFDLENBQUMsQ0FBQyxDQUNGLHVCQUFDLHdCQUFVLElBQ1QsU0FBUyxFQUFDLHFCQUFxQixFQUMvQixRQUFRLEVBQUUsUUFBUSxFQUNsQixTQUFTLEVBQUUsS0FBSyxFQUNoQixPQUFPLEVBQUUsT0FBTyxJQUFJLFNBQVMsRUFDN0IsaUJBQWlCLEVBQUUsWUFBWSxFQUFFLFdBQVcsWUFFNUMsZ0NBQUssU0FBUyxFQUFDLDRDQUE0QyxZQUN4RCxZQUFZLEVBQUUsV0FBVyxJQUFJLENBQzVCLGdDQUFLLFNBQVMsRUFBQyxzQ0FBc0MsWUFDbkQsZ0NBQUssU0FBUyxFQUFDLDhCQUE4QixZQUMzQyw4QkFBRyxTQUFTLEVBQUMseUNBQXlDLFlBQ25ELFlBQVksQ0FBQyxXQUFXLEdBQ3ZCLEdBQ0EsR0FDRixDQUNQLEdBQ0csR0FDSyxDQUNkLElBQ1EsR0FDUCxFQUNOLHVCQUFDLDBCQUFXLElBQUMsY0FBYyxFQUFFLE9BQVEsR0FBSSxJQUNyQyxDQUNQLENBQUM7QUFDSixDQUFDIn0=