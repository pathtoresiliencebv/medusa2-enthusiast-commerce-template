"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = POST;
const enthusiast_1 = require("../../../../../../modules/enthusiast");
const utils_1 = require("@medusajs/utils");
async function POST(req, res) {
    const enthusiastService = req.scope.resolve(enthusiast_1.ENTHUSIAST_MODULE);
    const conversationId = parseInt(req.params.id);
    const file = req.file;
    if (!file) {
        throw new utils_1.MedusaError(utils_1.MedusaError.Types.INVALID_DATA, "No file was uploaded");
    }
    const uploadResponse = await enthusiastService.uploadFile(conversationId, file);
    res.status(200).json(uploadResponse);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2VudGh1c2lhc3QvY29udmVyc2F0aW9ucy9baWRdL3VwbG9hZC9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUtBLG9CQVlDO0FBaEJELHFFQUF5RTtBQUV6RSwyQ0FBOEM7QUFFdkMsS0FBSyxVQUFVLElBQUksQ0FBQyxHQUFrQixFQUFFLEdBQW1CO0lBQ2hFLE1BQU0saUJBQWlCLEdBQXNCLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLDhCQUFpQixDQUFDLENBQUM7SUFDbEYsTUFBTSxjQUFjLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDL0MsTUFBTSxJQUFJLEdBQUcsR0FBRyxDQUFDLElBQTJCLENBQUM7SUFFN0MsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ1YsTUFBTSxJQUFJLG1CQUFXLENBQUMsbUJBQVcsQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUFFLHNCQUFzQixDQUFDLENBQUM7SUFDaEYsQ0FBQztJQUVELE1BQU0sY0FBYyxHQUFHLE1BQU0saUJBQWlCLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUVoRixHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztBQUN2QyxDQUFDIn0=