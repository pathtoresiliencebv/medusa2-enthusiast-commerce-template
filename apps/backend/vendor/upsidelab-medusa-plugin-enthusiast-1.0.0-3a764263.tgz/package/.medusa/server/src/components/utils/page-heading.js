"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PageHeading = PageHeading;
const jsx_runtime_1 = require("react/jsx-runtime");
const utils_1 = require("../../admin/lib/utils");
function PageHeading({ title, description, className, children }) {
    return ((0, jsx_runtime_1.jsx)("div", { className: (0, utils_1.cn)("pb-4", className), children: (0, jsx_runtime_1.jsxs)("div", { className: "flex", children: [(0, jsx_runtime_1.jsxs)("div", { children: [(0, jsx_runtime_1.jsx)("h3", { className: "text-lg font-medium", children: title }), description && (0, jsx_runtime_1.jsx)("p", { className: "text-sm text-muted-foreground", children: description })] }), children] }) }));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZS1oZWFkaW5nLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL2NvbXBvbmVudHMvdXRpbHMvcGFnZS1oZWFkaW5nLnRzeCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQVVBLGtDQVlDOztBQXJCRCxpREFBMkM7QUFTM0MsU0FBZ0IsV0FBVyxDQUFDLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFvQjtJQUN2RixPQUFPLENBQ0wsZ0NBQUssU0FBUyxFQUFFLElBQUEsVUFBRSxFQUFDLE1BQU0sRUFBRSxTQUFTLENBQUMsWUFDbkMsaUNBQUssU0FBUyxFQUFDLE1BQU0sYUFDbkIsNENBQ0UsK0JBQUksU0FBUyxFQUFDLHFCQUFxQixZQUFFLEtBQUssR0FBTSxFQUMvQyxXQUFXLElBQUksOEJBQUcsU0FBUyxFQUFDLCtCQUErQixZQUFFLFdBQVcsR0FBSyxJQUMxRSxFQUNMLFFBQVEsSUFDTCxHQUNGLENBQ1AsQ0FBQztBQUNKLENBQUMifQ==