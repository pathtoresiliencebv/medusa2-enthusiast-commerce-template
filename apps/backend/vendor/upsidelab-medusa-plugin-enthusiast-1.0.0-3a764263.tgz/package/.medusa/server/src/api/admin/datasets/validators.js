"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostCreateDatasetSchema = void 0;
const zod_1 = require("zod");
exports.PostCreateDatasetSchema = zod_1.z.object({
    name: zod_1.z.string().nonempty(),
    language_model_provider: zod_1.z.string(),
    language_model: zod_1.z.string(),
    embedding_provider: zod_1.z.string(),
    embedding_model: zod_1.z.string(),
    embedding_vector_dimensions: zod_1.z.number(),
    preconfigure_agents: zod_1.z.boolean(),
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdG9ycy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcGkvYWRtaW4vZGF0YXNldHMvdmFsaWRhdG9ycy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSw2QkFBd0I7QUFFWCxRQUFBLHVCQUF1QixHQUFHLE9BQUMsQ0FBQyxNQUFNLENBQUM7SUFDOUMsSUFBSSxFQUFFLE9BQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDM0IsdUJBQXVCLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRTtJQUNuQyxjQUFjLEVBQUUsT0FBQyxDQUFDLE1BQU0sRUFBRTtJQUMxQixrQkFBa0IsRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFO0lBQzlCLGVBQWUsRUFBRSxPQUFDLENBQUMsTUFBTSxFQUFFO0lBQzNCLDJCQUEyQixFQUFFLE9BQUMsQ0FBQyxNQUFNLEVBQUU7SUFDdkMsbUJBQW1CLEVBQUUsT0FBQyxDQUFDLE9BQU8sRUFBRTtDQUNqQyxDQUFDLENBQUMifQ==