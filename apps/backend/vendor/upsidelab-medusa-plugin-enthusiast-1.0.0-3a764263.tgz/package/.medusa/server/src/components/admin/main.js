"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnthusiastMain = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
const react_1 = require("react");
const admin_client_1 = require("../../admin/lib/admin-client");
const agent_table_1 = require("./agent-table");
const spinner_1 = require("../../components/utils/spinner");
const error_1 = require("../../components/ui/error");
const EnthusiastMain = () => {
    const [isConnected, setIsConnected] = (0, react_1.useState)(null);
    const [isLoading, setIsLoading] = (0, react_1.useState)(true);
    (0, react_1.useEffect)(() => {
        let mounted = true;
        const fetchStatus = async () => {
            try {
                setIsLoading(true);
                await admin_client_1.adminApiClient.getStatus();
                if (mounted) {
                    setIsConnected(true);
                }
            }
            catch (err) {
                if (mounted) {
                    setIsConnected(false);
                }
            }
            finally {
                if (mounted) {
                    setIsLoading(false);
                }
            }
        };
        void fetchStatus();
        return () => {
            mounted = false;
        };
    }, []);
    if (isLoading) {
        return (0, jsx_runtime_1.jsx)(spinner_1.LoadingSpinner, {});
    }
    if (!isConnected) {
        return ((0, jsx_runtime_1.jsx)(error_1.Error, { heading: "Something went wrong.", content: "Please check your Enthusiast integration." }));
    }
    return (0, jsx_runtime_1.jsx)(agent_table_1.AgentTable, {});
};
exports.EnthusiastMain = EnthusiastMain;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFpbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9jb21wb25lbnRzL2FkbWluL21haW4udHN4Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7QUFBQSxpQ0FBNEM7QUFDNUMsK0RBQThEO0FBQzlELCtDQUEyQztBQUMzQyw0REFBZ0U7QUFDaEUscURBQWtEO0FBRTNDLE1BQU0sY0FBYyxHQUFHLEdBQUcsRUFBRTtJQUNqQyxNQUFNLENBQUMsV0FBVyxFQUFFLGNBQWMsQ0FBQyxHQUFHLElBQUEsZ0JBQVEsRUFBaUIsSUFBSSxDQUFDLENBQUM7SUFDckUsTUFBTSxDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsR0FBRyxJQUFBLGdCQUFRLEVBQUMsSUFBSSxDQUFDLENBQUM7SUFFakQsSUFBQSxpQkFBUyxFQUFDLEdBQUcsRUFBRTtRQUNiLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQztRQUNuQixNQUFNLFdBQVcsR0FBRyxLQUFLLElBQUksRUFBRTtZQUM3QixJQUFJLENBQUM7Z0JBQ0gsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNuQixNQUFNLDZCQUFjLENBQUMsU0FBUyxFQUFFLENBQUM7Z0JBQ2pDLElBQUksT0FBTyxFQUFFLENBQUM7b0JBQ1osY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUN2QixDQUFDO1lBQ0gsQ0FBQztZQUFDLE9BQU8sR0FBUSxFQUFFLENBQUM7Z0JBQ2xCLElBQUksT0FBTyxFQUFFLENBQUM7b0JBQ1osY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUN4QixDQUFDO1lBQ0gsQ0FBQztvQkFBUyxDQUFDO2dCQUNULElBQUksT0FBTyxFQUFFLENBQUM7b0JBQ1osWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUN0QixDQUFDO1lBQ0gsQ0FBQztRQUNILENBQUMsQ0FBQztRQUVGLEtBQUssV0FBVyxFQUFFLENBQUM7UUFFbkIsT0FBTyxHQUFHLEVBQUU7WUFDVixPQUFPLEdBQUcsS0FBSyxDQUFDO1FBQ2xCLENBQUMsQ0FBQztJQUNKLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUVQLElBQUksU0FBUyxFQUFFLENBQUM7UUFDZCxPQUFPLHVCQUFDLHdCQUFjLEtBQUcsQ0FBQztJQUM1QixDQUFDO0lBQ0QsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ2pCLE9BQU8sQ0FDTCx1QkFBQyxhQUFLLElBQUMsT0FBTyxFQUFDLHVCQUF1QixFQUFDLE9BQU8sRUFBQywyQ0FBMkMsR0FBRyxDQUM5RixDQUFDO0lBQ0osQ0FBQztJQUNELE9BQU8sdUJBQUMsd0JBQVUsS0FBRyxDQUFDO0FBQ3hCLENBQUMsQ0FBQztBQXhDVyxRQUFBLGNBQWMsa0JBd0N6QiJ9