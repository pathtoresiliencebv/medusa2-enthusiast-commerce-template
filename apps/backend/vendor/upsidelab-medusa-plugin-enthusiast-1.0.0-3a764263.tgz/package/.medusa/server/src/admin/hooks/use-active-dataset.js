"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.useActiveDataset = useActiveDataset;
const react_1 = require("react");
const admin_client_1 = require("../lib/admin-client");
function useActiveDataset() {
    const [dataset, setDataset] = (0, react_1.useState)(null);
    const [hasAnyDatasets, setHasAnyDatasets] = (0, react_1.useState)(null);
    const [isLoading, setIsLoading] = (0, react_1.useState)(true);
    (0, react_1.useEffect)(() => {
        const fetchDataset = async () => {
            try {
                setIsLoading(true);
                const res = await admin_client_1.adminApiClient.dataSets().getInternalDataSets();
                setHasAnyDatasets(res.length > 0);
                const activeDataset = res.find((d) => d.is_active) ?? null;
                setDataset(activeDataset);
            }
            finally {
                setIsLoading(false);
            }
        };
        void fetchDataset();
    }, []);
    const datasetId = (0, react_1.useMemo)(() => dataset?.external_id ?? null, [dataset]);
    return { dataset, datasetId, hasAnyDatasets, isLoading };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNlLWFjdGl2ZS1kYXRhc2V0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL2FkbWluL2hvb2tzL3VzZS1hY3RpdmUtZGF0YXNldC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUlBLDRDQXVCQztBQTNCRCxpQ0FBcUQ7QUFDckQsc0RBQXFEO0FBR3JELFNBQWdCLGdCQUFnQjtJQUM5QixNQUFNLENBQUMsT0FBTyxFQUFFLFVBQVUsQ0FBQyxHQUFHLElBQUEsZ0JBQVEsRUFBK0IsSUFBSSxDQUFDLENBQUM7SUFDM0UsTUFBTSxDQUFDLGNBQWMsRUFBRSxpQkFBaUIsQ0FBQyxHQUFHLElBQUEsZ0JBQVEsRUFBaUIsSUFBSSxDQUFDLENBQUM7SUFDM0UsTUFBTSxDQUFDLFNBQVMsRUFBRSxZQUFZLENBQUMsR0FBRyxJQUFBLGdCQUFRLEVBQUMsSUFBSSxDQUFDLENBQUM7SUFFakQsSUFBQSxpQkFBUyxFQUFDLEdBQUcsRUFBRTtRQUNiLE1BQU0sWUFBWSxHQUFHLEtBQUssSUFBSSxFQUFFO1lBQzlCLElBQUksQ0FBQztnQkFDSCxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ25CLE1BQU0sR0FBRyxHQUFHLE1BQU0sNkJBQWMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO2dCQUNsRSxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUNsQyxNQUFNLGFBQWEsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksSUFBSSxDQUFDO2dCQUMzRCxVQUFVLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDNUIsQ0FBQztvQkFBUyxDQUFDO2dCQUNULFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN0QixDQUFDO1FBQ0gsQ0FBQyxDQUFDO1FBQ0YsS0FBSyxZQUFZLEVBQUUsQ0FBQztJQUN0QixDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFFUCxNQUFNLFNBQVMsR0FBRyxJQUFBLGVBQU8sRUFBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLEVBQUUsV0FBVyxJQUFJLElBQUksRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7SUFFekUsT0FBTyxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsY0FBYyxFQUFFLFNBQVMsRUFBRSxDQUFDO0FBQzNELENBQUMifQ==