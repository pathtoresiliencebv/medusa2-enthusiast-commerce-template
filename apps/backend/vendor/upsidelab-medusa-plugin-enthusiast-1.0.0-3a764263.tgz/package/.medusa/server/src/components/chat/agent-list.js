"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentList = AgentList;
const jsx_runtime_1 = require("react/jsx-runtime");
const ui_1 = require("@medusajs/ui");
const icons_1 = require("@medusajs/icons");
const utils_1 = require("../../admin/lib/utils");
function AgentList({ agents, currentAgentId, onAgentClick }) {
    return ((0, jsx_runtime_1.jsxs)(ui_1.Container, { className: "h-full flex flex-col", children: [(0, jsx_runtime_1.jsx)(ui_1.Heading, { level: "h3", className: "text-lg font-medium", children: "List of Agents" }), (0, jsx_runtime_1.jsx)("div", { className: "space-y-1 flex-1 overflow-y-auto min-h-0 [&::-webkit-scrollbar]:hidden pt-4", style: {
                    scrollbarWidth: "none",
                    msOverflowStyle: "none",
                }, children: agents.map((agent) => {
                    const isSelected = currentAgentId === agent.id;
                    return ((0, jsx_runtime_1.jsxs)("button", { className: (0, utils_1.cn)("w-full flex items-center gap-2 px-2 py-1.5 rounded text-sm hover:bg-ui-bg-base-hover transition-colors", isSelected && "bg-muted"), onClick: () => onAgentClick(agent.id), children: [isSelected && (0, jsx_runtime_1.jsx)(icons_1.Check, { className: "w-4 h-4" }), !isSelected && (0, jsx_runtime_1.jsx)("div", { className: "w-4 h-4" }), (0, jsx_runtime_1.jsx)("span", { className: "flex-1 text-left", children: agent.name })] }, agent.id));
                }) })] }));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWdlbnQtbGlzdC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9jb21wb25lbnRzL2NoYXQvYWdlbnQtbGlzdC50c3giXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFXQSw4QkFrQ0M7O0FBN0NELHFDQUFrRDtBQUNsRCwyQ0FBd0M7QUFFeEMsaURBQTJDO0FBUTNDLFNBQWdCLFNBQVMsQ0FBQyxFQUFFLE1BQU0sRUFBRSxjQUFjLEVBQUUsWUFBWSxFQUFrQjtJQUNoRixPQUFPLENBQ0wsd0JBQUMsY0FBUyxJQUFDLFNBQVMsRUFBQyxzQkFBc0IsYUFDekMsdUJBQUMsWUFBTyxJQUFDLEtBQUssRUFBQyxJQUFJLEVBQUMsU0FBUyxFQUFDLHFCQUFxQiwrQkFFekMsRUFDVixnQ0FDRSxTQUFTLEVBQUMsNkVBQTZFLEVBQ3ZGLEtBQUssRUFBRTtvQkFDTCxjQUFjLEVBQUUsTUFBTTtvQkFDdEIsZUFBZSxFQUFFLE1BQU07aUJBQ3hCLFlBRUEsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBRSxFQUFFO29CQUNwQixNQUFNLFVBQVUsR0FBRyxjQUFjLEtBQUssS0FBSyxDQUFDLEVBQUUsQ0FBQztvQkFFL0MsT0FBTyxDQUNMLG9DQUVFLFNBQVMsRUFBRSxJQUFBLFVBQUUsRUFDWCx3R0FBd0csRUFDeEcsVUFBVSxJQUFJLFVBQVUsQ0FDekIsRUFDRCxPQUFPLEVBQUUsR0FBRyxFQUFFLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsYUFFcEMsVUFBVSxJQUFJLHVCQUFDLGFBQUssSUFBQyxTQUFTLEVBQUMsU0FBUyxHQUFHLEVBQzNDLENBQUMsVUFBVSxJQUFJLGdDQUFLLFNBQVMsRUFBQyxTQUFTLEdBQUcsRUFDM0MsaUNBQU0sU0FBUyxFQUFDLGtCQUFrQixZQUFFLEtBQUssQ0FBQyxJQUFJLEdBQVEsS0FUakQsS0FBSyxDQUFDLEVBQUUsQ0FVTixDQUNWLENBQUM7Z0JBQ0osQ0FBQyxDQUFDLEdBQ0UsSUFDSSxDQUNiLENBQUM7QUFDSixDQUFDIn0=