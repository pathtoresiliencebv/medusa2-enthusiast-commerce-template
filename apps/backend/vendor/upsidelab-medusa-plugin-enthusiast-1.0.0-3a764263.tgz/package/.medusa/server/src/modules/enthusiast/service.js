"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnthusiastServiceError = void 0;
const utils_1 = require("@medusajs/framework/utils");
const client_1 = require("./api/client");
const enthusiast_dataset_1 = __importDefault(require("./models/enthusiast-dataset"));
const types_1 = require("./types");
const check_sync_status_1 = __importDefault(require("../../workflows/check-sync-status"));
const websocket_1 = require("../../modules/enthusiast/websocket");
class EnthusiastServiceError extends Error {
    constructor(message) {
        super(message);
        this.message = message;
    }
}
exports.EnthusiastServiceError = EnthusiastServiceError;
class EnthusiastService extends (0, utils_1.MedusaService)({ EnthusiastDataset: enthusiast_dataset_1.default }) {
    constructor({ logger, configModule, options }) {
        super(...arguments);
        this.apiClient = () => {
            return new client_1.ApiClient(this.options_.enthusiastApiUrl, this.options_.enthusiastServiceAccountToken);
        };
        this.isConnected = async () => {
            await this.apiClient().accounts().me();
            const availablePlugins = await this.apiClient().config().getAvailableIntegrations();
            const integrationExists = availablePlugins.choices.some((plugin) => plugin.name === this.options_.enthusiastMedusaIntegrationName);
            if (!integrationExists) {
                throw new EnthusiastServiceError(`Integration ${this.options_.enthusiastMedusaIntegrationName} does not exist.`);
            }
        };
        this.listAgents = async (dataSetId) => {
            return await this.apiClient().agents().getDatasetAvailableAgents(dataSetId);
        };
        this.listDatasets = async () => {
            return await this.apiClient().dataSets().getDataSets();
        };
        this.getAgentById = async (agentId) => {
            return await this.apiClient().agents().getAgentById(agentId);
        };
        this.getConversations = async (dataSetId, agentId = undefined, page = 1) => {
            return await this.apiClient().conversations().getConversations(dataSetId, agentId, page);
        };
        this.conversationCreate = async (agentId) => {
            return await this.apiClient().conversations().createConversation(agentId);
        };
        this.getConversation = async (conversationId) => {
            return await this.apiClient().conversations().getConversation(conversationId);
        };
        this.sendMessage = async (conversationId, dataSetId, message, streaming, fileIds) => {
            return await this.apiClient()
                .conversations()
                .sendMessage(conversationId, dataSetId, message, streaming, fileIds);
        };
        this.getTaskStatus = async (taskHandle) => {
            return await this.apiClient().conversations().getTaskStatus(taskHandle);
        };
        this.fetchResponseMessage = async (conversationId, taskHandle) => {
            return await this.apiClient().conversations().fetchResponseMessage(conversationId, taskHandle);
        };
        this.messageFeedbackUpdate = async (messageId, feedbackData) => {
            return await this.apiClient().conversations().updateMessageFeedback(messageId, feedbackData);
        };
        this.getSupportedFileTypes = async () => {
            return await this.apiClient().conversations().getSupportedFileTypes();
        };
        this.uploadFile = async (conversationId, file) => {
            const fileObj = new File([file.buffer], file.originalname, { type: file.mimetype });
            return await this.apiClient().conversations().uploadFile(conversationId, fileObj);
        };
        this.getFileUploadStatus = async (taskId) => {
            return await this.apiClient().conversations().getFileUploadStatus(taskId);
        };
        this.listInternalDatasets = async (req) => {
            const container = req.scope;
            const apiKeyModuleService = container.resolve(utils_1.Modules.API_KEY);
            const userModuleService = container.resolve(utils_1.Modules.USER);
            const enthusiastDatasets = await this.apiClient().dataSets().getDataSets();
            const enthusiastDatasetsIds = enthusiastDatasets.map((d) => d.id);
            const internalDatasets = await this.listEnthusiastDatasets();
            const user = await userModuleService.retrieveUser(req.auth_context.actor_id);
            const notRelevantDatasets = await this.listEnthusiastDatasets({
                external_id: { $nin: enthusiastDatasetsIds },
            });
            const notRelevantApiKeyIds = notRelevantDatasets
                .map((dataset) => dataset.api_key_id)
                .filter((id) => id != null);
            await apiKeyModuleService.revoke({
                id: notRelevantApiKeyIds,
            }, {
                revoked_by: user.email,
            });
            await apiKeyModuleService.deleteApiKeys(notRelevantApiKeyIds);
            await this.deleteEnthusiastDatasets({
                external_id: {
                    $nin: enthusiastDatasetsIds,
                },
            });
            const internalDatasetsMap = internalDatasets.reduce((acc, item) => {
                acc[item.external_id] = item;
                return acc;
            }, {});
            const upsert = enthusiastDatasets.reduce((acc, enthusiastDataset) => {
                const found = internalDatasetsMap[enthusiastDataset.id];
                if (found) {
                    acc.update.push({
                        id: found.id.toString(),
                        external_id: enthusiastDataset.id,
                        name: enthusiastDataset.name,
                    });
                }
                else {
                    acc.create.push({
                        external_id: enthusiastDataset.id,
                        name: enthusiastDataset.name,
                    });
                }
                return acc;
            }, { create: [], update: [] });
            await this.createEnthusiastDatasets(upsert.create);
            await this.updateEnthusiastDatasets(upsert.update);
            return await this.listEnthusiastDatasets();
        };
        this.synchronizeDatasets = async (datasetId, container) => {
            const datasets = await this.listEnthusiastDatasets({
                id: datasetId,
                is_connected: true,
                plugin_id: { $ne: null },
            });
            if (!datasets || !datasets.length) {
                return;
            }
            const dataset = datasets[0];
            const { task_id } = await this.apiClient()
                .dataSets()
                .syncDataSetIntegration(dataset.external_id);
            await this.updateEnthusiastDatasets({
                id: dataset.id,
                task_id: task_id,
                sync_status: types_1.SyncStatus.PROCESSING,
            });
            await (0, check_sync_status_1.default)(container).run({ input: { datasetId: dataset.id } });
        };
        this.checkDataset = async (datasetId) => {
            const dataset = await this.retrieveEnthusiastDataset(datasetId);
            if (!dataset.is_connected) {
                throw new EnthusiastServiceError(`Dataset not connected.`);
            }
            if (!dataset.plugin_id) {
                throw new EnthusiastServiceError(`Dataset has not plugin id assigned.`);
            }
            if (!dataset.api_key_id) {
                throw new EnthusiastServiceError(`Dataset has not api key id assigned.`);
            }
            await this.apiClient().dataSets().getDataSet(dataset.external_id);
        };
        this.datasetCreate = async (dataset) => {
            const externalId = await this.apiClient().dataSets().createDataSet(dataset);
            return await this.createEnthusiastDatasets({ name: dataset.name, external_id: externalId });
        };
        this.getConfig = async () => {
            return await this.apiClient().config().getAvailableProviders();
        };
        this.listLanguageModels = async (name) => {
            return await this.apiClient().config().getLanguageModelsForProvider(name);
        };
        this.listEmbeddingProviders = async (name) => {
            return await this.apiClient().config().getEmbeddingModelsForProvider(name);
        };
        this.buildWebsocketHandler = () => {
            if (this.options_.enthusiastWSUrl) {
                return new websocket_1.WebsocketHandler(this.options_.enthusiastWSUrl);
            }
            return;
        };
        this.getStreamStatus = async () => {
            return { active: !!this.options_.enthusiastWSUrl };
        };
        this.logger_ = logger;
        this.configModule_ = configModule;
        this.options_ = options;
    }
    async connectDatasets_(datasetId, container, _sharedContext) {
        const apiKeyModuleService = container.resolve(utils_1.Modules.API_KEY);
        const datasets = await this.listEnthusiastDatasets({ id: datasetId, is_connected: false });
        if (!datasets || !datasets.length) {
            return;
        }
        const dataset = datasets[0];
        const apiKey = await apiKeyModuleService.createApiKeys({
            title: `Enthusiast API Key dataset(${dataset.id})`,
            type: "secret",
            created_by: "enthusiast-plugin",
        });
        const plugin = await this.apiClient()
            .dataSets()
            .addDataSetIntegration(dataset.external_id, this.options_.enthusiastMedusaIntegrationName, {
            api_key: apiKey.token,
            base_url: this.options_.medusaBackendUrl,
            admin_base_url: this.options_.medusaAdminUrl,
        });
        await this.updateEnthusiastDatasets({
            id: dataset.id,
            is_connected: true,
            plugin_id: plugin.id,
            task_id: plugin.task_id,
            sync_status: types_1.SyncStatus.PROCESSING,
            api_key_id: apiKey.id,
        });
        await (0, check_sync_status_1.default)(container).run({ input: { datasetId: dataset.id } });
    }
    async connectDatasets(datasetId, container, sharedContext) {
        return await this.connectDatasets_(datasetId, container, sharedContext);
    }
    async activateDataset_(datasetId, container, sharedContext) {
        await this.updateEnthusiastDatasets({ selector: {}, data: { is_active: false } }, sharedContext);
        await this.updateEnthusiastDatasets({ id: datasetId, is_active: true }, sharedContext);
    }
    async activateDataset(datasetId, container, sharedContext) {
        const dataset = await this.retrieveEnthusiastDataset(datasetId);
        if (!dataset.is_connected) {
            await this.connectDatasets(datasetId, container);
        }
        await this.checkDataset(datasetId);
        return await this.activateDataset_(datasetId, container, sharedContext);
    }
}
exports.default = EnthusiastService;
__decorate([
    (0, utils_1.InjectTransactionManager)(),
    __param(2, (0, utils_1.MedusaContext)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], EnthusiastService.prototype, "connectDatasets_", null);
__decorate([
    (0, utils_1.InjectManager)(),
    __param(2, (0, utils_1.MedusaContext)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], EnthusiastService.prototype, "connectDatasets", null);
__decorate([
    (0, utils_1.InjectTransactionManager)(),
    __param(2, (0, utils_1.MedusaContext)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], EnthusiastService.prototype, "activateDataset_", null);
__decorate([
    (0, utils_1.InjectManager)(),
    __param(2, (0, utils_1.MedusaContext)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], EnthusiastService.prototype, "activateDataset", null);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9tb2R1bGVzL2VudGh1c2lhc3Qvc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxxREFNbUM7QUFHbkMseUNBQXlDO0FBV3pDLHFGQUE0RDtBQUc1RCxtQ0FBcUM7QUFDckMsMEZBQTBFO0FBSTFFLGtFQUFzRTtBQVN0RSxNQUFhLHNCQUF1QixTQUFRLEtBQUs7SUFDL0MsWUFBbUIsT0FBZTtRQUNoQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7UUFERSxZQUFPLEdBQVAsT0FBTyxDQUFRO0lBRWxDLENBQUM7Q0FDRjtBQUpELHdEQUlDO0FBRUQsTUFBcUIsaUJBQWtCLFNBQVEsSUFBQSxxQkFBYSxFQUFDLEVBQUUsaUJBQWlCLEVBQWpCLDRCQUFpQixFQUFFLENBQUM7SUFLakYsWUFBWSxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsT0FBTyxFQUF3QjtRQUNqRSxLQUFLLENBQUMsR0FBRyxTQUFTLENBQUMsQ0FBQztRQU10QixjQUFTLEdBQUcsR0FBRyxFQUFFO1lBQ2YsT0FBTyxJQUFJLGtCQUFTLENBQ2xCLElBQUksQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLEVBQzlCLElBQUksQ0FBQyxRQUFRLENBQUMsNkJBQTZCLENBQzVDLENBQUM7UUFDSixDQUFDLENBQUM7UUFFRixnQkFBVyxHQUFHLEtBQUssSUFBSSxFQUFFO1lBQ3ZCLE1BQU0sSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO1lBQ3ZDLE1BQU0sZ0JBQWdCLEdBQUcsTUFBTSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsTUFBTSxFQUFFLENBQUMsd0JBQXdCLEVBQUUsQ0FBQztZQUNwRixNQUFNLGlCQUFpQixHQUFHLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQ3JELENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxRQUFRLENBQUMsK0JBQStCLENBQzFFLENBQUM7WUFDRixJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztnQkFDdkIsTUFBTSxJQUFJLHNCQUFzQixDQUM5QixlQUFlLElBQUksQ0FBQyxRQUFRLENBQUMsK0JBQStCLGtCQUFrQixDQUMvRSxDQUFDO1lBQ0osQ0FBQztRQUNILENBQUMsQ0FBQztRQUNGLGVBQVUsR0FBRyxLQUFLLEVBQUUsU0FBaUIsRUFBRSxFQUFFO1lBQ3ZDLE9BQU8sTUFBTSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsTUFBTSxFQUFFLENBQUMseUJBQXlCLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDOUUsQ0FBQyxDQUFDO1FBRUYsaUJBQVksR0FBRyxLQUFLLElBQUksRUFBRTtZQUN4QixPQUFPLE1BQU0sSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3pELENBQUMsQ0FBQztRQUVGLGlCQUFZLEdBQUcsS0FBSyxFQUFFLE9BQWUsRUFBeUIsRUFBRTtZQUM5RCxPQUFPLE1BQU0sSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMvRCxDQUFDLENBQUM7UUFFRixxQkFBZ0IsR0FBRyxLQUFLLEVBQ3RCLFNBQWlCLEVBQ2pCLFVBQThCLFNBQVMsRUFDdkMsT0FBZSxDQUFDLEVBQ3dCLEVBQUU7WUFDMUMsT0FBTyxNQUFNLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzNGLENBQUMsQ0FBQztRQUVGLHVCQUFrQixHQUFHLEtBQUssRUFBRSxPQUFlLEVBQW1CLEVBQUU7WUFDOUQsT0FBTyxNQUFNLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUM1RSxDQUFDLENBQUM7UUFFRixvQkFBZSxHQUFHLEtBQUssRUFBRSxjQUFzQixFQUF5QixFQUFFO1lBQ3hFLE9BQU8sTUFBTSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsYUFBYSxFQUFFLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBQ2hGLENBQUMsQ0FBQztRQUVGLGdCQUFXLEdBQUcsS0FBSyxFQUNqQixjQUFzQixFQUN0QixTQUFpQixFQUNqQixPQUFlLEVBQ2YsU0FBa0IsRUFDbEIsT0FBa0IsRUFDRyxFQUFFO1lBQ3ZCLE9BQU8sTUFBTSxJQUFJLENBQUMsU0FBUyxFQUFFO2lCQUMxQixhQUFhLEVBQUU7aUJBQ2YsV0FBVyxDQUFDLGNBQWMsRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQztRQUN6RSxDQUFDLENBQUM7UUFFRixrQkFBYSxHQUFHLEtBQUssRUFBRSxVQUFzQixFQUFtQixFQUFFO1lBQ2hFLE9BQU8sTUFBTSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsYUFBYSxFQUFFLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQzFFLENBQUMsQ0FBQztRQUVGLHlCQUFvQixHQUFHLEtBQUssRUFBRSxjQUFzQixFQUFFLFVBQXNCLEVBQUUsRUFBRTtZQUM5RSxPQUFPLE1BQU0sSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLGFBQWEsRUFBRSxDQUFDLG9CQUFvQixDQUFDLGNBQWMsRUFBRSxVQUFVLENBQUMsQ0FBQztRQUNqRyxDQUFDLENBQUM7UUFFRiwwQkFBcUIsR0FBRyxLQUFLLEVBQUUsU0FBaUIsRUFBRSxZQUEwQixFQUFpQixFQUFFO1lBQzdGLE9BQU8sTUFBTSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsYUFBYSxFQUFFLENBQUMscUJBQXFCLENBQUMsU0FBUyxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBQy9GLENBQUMsQ0FBQztRQUVGLDBCQUFxQixHQUFHLEtBQUssSUFBaUMsRUFBRTtZQUM5RCxPQUFPLE1BQU0sSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLGFBQWEsRUFBRSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDeEUsQ0FBQyxDQUFDO1FBRUYsZUFBVSxHQUFHLEtBQUssRUFDaEIsY0FBc0IsRUFDdEIsSUFBeUIsRUFDSSxFQUFFO1lBQy9CLE1BQU0sT0FBTyxHQUFHLElBQUksSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLElBQUksQ0FBQyxZQUFZLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7WUFDcEYsT0FBTyxNQUFNLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3BGLENBQUMsQ0FBQztRQUVGLHdCQUFtQixHQUFHLEtBQUssRUFBRSxNQUFjLEVBQXFDLEVBQUU7WUFDaEYsT0FBTyxNQUFNLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUM1RSxDQUFDLENBQUM7UUFFRix5QkFBb0IsR0FBRyxLQUFLLEVBQzFCLEdBQStCLEVBQ0csRUFBRTtZQUNwQyxNQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDO1lBQzVCLE1BQU0sbUJBQW1CLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDL0QsTUFBTSxpQkFBaUIsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLGVBQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUMxRCxNQUFNLGtCQUFrQixHQUFHLE1BQU0sSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzNFLE1BQU0scUJBQXFCLEdBQUcsa0JBQWtCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDbEUsTUFBTSxnQkFBZ0IsR0FBRyxNQUFNLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1lBRTdELE1BQU0sSUFBSSxHQUFHLE1BQU0saUJBQWlCLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUM7WUFFN0UsTUFBTSxtQkFBbUIsR0FBRyxNQUFNLElBQUksQ0FBQyxzQkFBc0IsQ0FBQztnQkFDNUQsV0FBVyxFQUFFLEVBQUUsSUFBSSxFQUFFLHFCQUFxQixFQUFFO2FBQzdDLENBQUMsQ0FBQztZQUNILE1BQU0sb0JBQW9CLEdBQUcsbUJBQW1CO2lCQUM3QyxHQUFHLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUM7aUJBQ3BDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsRUFBZ0IsRUFBRSxDQUFDLEVBQUUsSUFBSSxJQUFJLENBQUMsQ0FBQztZQUM1QyxNQUFNLG1CQUFtQixDQUFDLE1BQU0sQ0FDOUI7Z0JBQ0UsRUFBRSxFQUFFLG9CQUFvQjthQUN6QixFQUNEO2dCQUNFLFVBQVUsRUFBRSxJQUFJLENBQUMsS0FBSzthQUN2QixDQUNGLENBQUM7WUFDRixNQUFNLG1CQUFtQixDQUFDLGFBQWEsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1lBQzlELE1BQU0sSUFBSSxDQUFDLHdCQUF3QixDQUFDO2dCQUNsQyxXQUFXLEVBQUU7b0JBQ1gsSUFBSSxFQUFFLHFCQUFxQjtpQkFDNUI7YUFDRixDQUFDLENBQUM7WUFDSCxNQUFNLG1CQUFtQixHQUFHLGdCQUFnQixDQUFDLE1BQU0sQ0FDakQsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUU7Z0JBQ1osR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxJQUFJLENBQUM7Z0JBQzdCLE9BQU8sR0FBRyxDQUFDO1lBQ2IsQ0FBQyxFQUNELEVBQXlELENBQzFELENBQUM7WUFDRixNQUFNLE1BQU0sR0FBRyxrQkFBa0IsQ0FBQyxNQUFNLENBQ3RDLENBQUMsR0FBRyxFQUFFLGlCQUFpQixFQUFFLEVBQUU7Z0JBQ3pCLE1BQU0sS0FBSyxHQUFHLG1CQUFtQixDQUFDLGlCQUFpQixDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUN4RCxJQUFJLEtBQUssRUFBRSxDQUFDO29CQUNWLEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO3dCQUNkLEVBQUUsRUFBRSxLQUFLLENBQUMsRUFBRSxDQUFDLFFBQVEsRUFBRTt3QkFDdkIsV0FBVyxFQUFFLGlCQUFpQixDQUFDLEVBQUU7d0JBQ2pDLElBQUksRUFBRSxpQkFBaUIsQ0FBQyxJQUFJO3FCQUM3QixDQUFDLENBQUM7Z0JBQ0wsQ0FBQztxQkFBTSxDQUFDO29CQUNOLEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO3dCQUNkLFdBQVcsRUFBRSxpQkFBaUIsQ0FBQyxFQUFFO3dCQUNqQyxJQUFJLEVBQUUsaUJBQWlCLENBQUMsSUFBSTtxQkFDN0IsQ0FBQyxDQUFDO2dCQUNMLENBQUM7Z0JBRUQsT0FBTyxHQUFHLENBQUM7WUFDYixDQUFDLEVBQ0QsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBR3ZCLENBQ0YsQ0FBQztZQUNGLE1BQU0sSUFBSSxDQUFDLHdCQUF3QixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNuRCxNQUFNLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDbkQsT0FBTyxNQUFNLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQzdDLENBQUMsQ0FBQztRQStDRix3QkFBbUIsR0FBRyxLQUFLLEVBQUUsU0FBaUIsRUFBRSxTQUEwQixFQUFpQixFQUFFO1lBQzNGLE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLHNCQUFzQixDQUFDO2dCQUNqRCxFQUFFLEVBQUUsU0FBUztnQkFDYixZQUFZLEVBQUUsSUFBSTtnQkFDbEIsU0FBUyxFQUFFLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRTthQUN6QixDQUFDLENBQUM7WUFDSCxJQUFJLENBQUMsUUFBUSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUNsQyxPQUFPO1lBQ1QsQ0FBQztZQUNELE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUM1QixNQUFNLEVBQUUsT0FBTyxFQUFFLEdBQUcsTUFBTSxJQUFJLENBQUMsU0FBUyxFQUFFO2lCQUN2QyxRQUFRLEVBQUU7aUJBQ1Ysc0JBQXNCLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBRS9DLE1BQU0sSUFBSSxDQUFDLHdCQUF3QixDQUFDO2dCQUNsQyxFQUFFLEVBQUUsT0FBTyxDQUFDLEVBQUU7Z0JBQ2QsT0FBTyxFQUFFLE9BQU87Z0JBQ2hCLFdBQVcsRUFBRSxrQkFBVSxDQUFDLFVBQVU7YUFDbkMsQ0FBQyxDQUFDO1lBQ0gsTUFBTSxJQUFBLDJCQUF5QixFQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLEtBQUssRUFBRSxFQUFFLFNBQVMsRUFBRSxPQUFPLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ3ZGLENBQUMsQ0FBQztRQUVGLGlCQUFZLEdBQUcsS0FBSyxFQUFFLFNBQWlCLEVBQWlCLEVBQUU7WUFDeEQsTUFBTSxPQUFPLEdBQUcsTUFBTSxJQUFJLENBQUMseUJBQXlCLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDaEUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDMUIsTUFBTSxJQUFJLHNCQUFzQixDQUFDLHdCQUF3QixDQUFDLENBQUM7WUFDN0QsQ0FBQztZQUNELElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLENBQUM7Z0JBQ3ZCLE1BQU0sSUFBSSxzQkFBc0IsQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO1lBQzFFLENBQUM7WUFDRCxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUN4QixNQUFNLElBQUksc0JBQXNCLENBQUMsc0NBQXNDLENBQUMsQ0FBQztZQUMzRSxDQUFDO1lBQ0QsTUFBTSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsUUFBUSxFQUFFLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUNwRSxDQUFDLENBQUM7UUFFRixrQkFBYSxHQUFHLEtBQUssRUFBRSxPQUE2QixFQUFFLEVBQUU7WUFDdEQsTUFBTSxVQUFVLEdBQUcsTUFBTSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsUUFBUSxFQUFFLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQzVFLE9BQU8sTUFBTSxJQUFJLENBQUMsd0JBQXdCLENBQUMsRUFBRSxJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxXQUFXLEVBQUUsVUFBVSxFQUFFLENBQUMsQ0FBQztRQUM5RixDQUFDLENBQUM7UUFDRixjQUFTLEdBQUcsS0FBSyxJQUFJLEVBQUU7WUFDckIsT0FBTyxNQUFNLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQ2pFLENBQUMsQ0FBQztRQUNGLHVCQUFrQixHQUFHLEtBQUssRUFBRSxJQUFZLEVBQUUsRUFBRTtZQUMxQyxPQUFPLE1BQU0sSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDLDRCQUE0QixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzVFLENBQUMsQ0FBQztRQUNGLDJCQUFzQixHQUFHLEtBQUssRUFBRSxJQUFZLEVBQUUsRUFBRTtZQUM5QyxPQUFPLE1BQU0sSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDLDZCQUE2QixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzdFLENBQUMsQ0FBQztRQUNGLDBCQUFxQixHQUFHLEdBQUcsRUFBRTtZQUMzQixJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsZUFBZSxFQUFFLENBQUM7Z0JBQ2xDLE9BQU8sSUFBSSw0QkFBZ0IsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1lBQzdELENBQUM7WUFDRCxPQUFPO1FBQ1QsQ0FBQyxDQUFDO1FBQ0Ysb0JBQWUsR0FBRyxLQUFLLElBQUksRUFBRTtZQUMzQixPQUFPLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQ3JELENBQUMsQ0FBQztRQXBRQSxJQUFJLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQztRQUN0QixJQUFJLENBQUMsYUFBYSxHQUFHLFlBQVksQ0FBQztRQUNsQyxJQUFJLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQztJQUMxQixDQUFDO0lBNEplLEFBQU4sS0FBSyxDQUFDLGdCQUFnQixDQUM5QixTQUFpQixFQUNqQixTQUEwQixFQUNULGNBQXVDO1FBRXhELE1BQU0sbUJBQW1CLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxlQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDL0QsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsc0JBQXNCLENBQUMsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLFlBQVksRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO1FBQzNGLElBQUksQ0FBQyxRQUFRLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDbEMsT0FBTztRQUNULENBQUM7UUFDRCxNQUFNLE9BQU8sR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDNUIsTUFBTSxNQUFNLEdBQUcsTUFBTSxtQkFBbUIsQ0FBQyxhQUFhLENBQUM7WUFDckQsS0FBSyxFQUFFLDhCQUE4QixPQUFPLENBQUMsRUFBRSxHQUFHO1lBQ2xELElBQUksRUFBRSxRQUFRO1lBQ2QsVUFBVSxFQUFFLG1CQUFtQjtTQUNoQyxDQUFDLENBQUM7UUFFSCxNQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQyxTQUFTLEVBQUU7YUFDbEMsUUFBUSxFQUFFO2FBQ1YscUJBQXFCLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLCtCQUErQixFQUFFO1lBQ3pGLE9BQU8sRUFBRSxNQUFNLENBQUMsS0FBSztZQUNyQixRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0I7WUFDeEMsY0FBYyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsY0FBYztTQUM3QyxDQUFDLENBQUM7UUFDTCxNQUFNLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztZQUNsQyxFQUFFLEVBQUUsT0FBTyxDQUFDLEVBQUU7WUFDZCxZQUFZLEVBQUUsSUFBSTtZQUNsQixTQUFTLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDcEIsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPO1lBQ3ZCLFdBQVcsRUFBRSxrQkFBVSxDQUFDLFVBQVU7WUFDbEMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1NBQ3RCLENBQUMsQ0FBQztRQUNILE1BQU0sSUFBQSwyQkFBeUIsRUFBQyxTQUFTLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUN2RixDQUFDO0lBR0ssQUFBTixLQUFLLENBQUMsZUFBZSxDQUNuQixTQUFpQixFQUNqQixTQUEwQixFQUNULGFBQXNDO1FBRXZELE9BQU8sTUFBTSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxhQUFhLENBQUMsQ0FBQztJQUMxRSxDQUFDO0lBOERlLEFBQU4sS0FBSyxDQUFDLGdCQUFnQixDQUM5QixTQUFpQixFQUNqQixTQUEwQixFQUNULGFBQXNDO1FBRXZELE1BQU0sSUFBSSxDQUFDLHdCQUF3QixDQUNqQyxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQzVDLGFBQWEsQ0FDZCxDQUFDO1FBQ0YsTUFBTSxJQUFJLENBQUMsd0JBQXdCLENBQUMsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsRUFBRSxhQUFhLENBQUMsQ0FBQztJQUN6RixDQUFDO0lBR0ssQUFBTixLQUFLLENBQUMsZUFBZSxDQUNuQixTQUFpQixFQUNqQixTQUEwQixFQUNULGFBQXNDO1FBRXZELE1BQU0sT0FBTyxHQUFHLE1BQU0sSUFBSSxDQUFDLHlCQUF5QixDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ2hFLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDMUIsTUFBTSxJQUFJLENBQUMsZUFBZSxDQUFDLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUNuRCxDQUFDO1FBQ0QsTUFBTSxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ25DLE9BQU8sTUFBTSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRSxhQUFhLENBQUMsQ0FBQztJQUMxRSxDQUFDO0NBQ0Y7QUF4U0Qsb0NBd1NDO0FBaklpQjtJQURmLElBQUEsZ0NBQXdCLEdBQUU7SUFJeEIsV0FBQSxJQUFBLHFCQUFhLEdBQUUsQ0FBQTs7Ozt5REE4QmpCO0FBR0s7SUFETCxJQUFBLHFCQUFhLEdBQUU7SUFJYixXQUFBLElBQUEscUJBQWEsR0FBRSxDQUFBOzs7O3dEQUdqQjtBQThEZTtJQURmLElBQUEsZ0NBQXdCLEdBQUU7SUFJeEIsV0FBQSxJQUFBLHFCQUFhLEdBQUUsQ0FBQTs7Ozt5REFPakI7QUFHSztJQURMLElBQUEscUJBQWEsR0FBRTtJQUliLFdBQUEsSUFBQSxxQkFBYSxHQUFFLENBQUE7Ozs7d0RBUWpCIn0=