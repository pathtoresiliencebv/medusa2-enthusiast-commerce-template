"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Migration20251212151929 = void 0;
const migrations_1 = require("@mikro-orm/migrations");
class Migration20251212151929 extends migrations_1.Migration {
    async up() {
        this.addSql(`alter table if exists "enthusiast_dataset" drop constraint if exists "enthusiast_dataset_is_used_unique";`);
        this.addSql(`create table if not exists "enthusiast_dataset" ("id" text not null, "external_id" integer not null, "name" text not null default 'Dataset', "is_connected" boolean not null default false, "last_synced" timestamptz null, "plugin_id" integer null, "task_id" text null, "sync_status" text check ("sync_status" in ('processing', 'success', 'failed')) null, "api_key_id" text null, "is_used" boolean not null default false, "created_at" timestamptz not null default now(), "updated_at" timestamptz not null default now(), "deleted_at" timestamptz null, constraint "enthusiast_dataset_pkey" primary key ("id"));`);
        this.addSql(`CREATE INDEX IF NOT EXISTS "IDX_enthusiast_dataset_deleted_at" ON "enthusiast_dataset" (deleted_at) WHERE deleted_at IS NULL;`);
        this.addSql(`CREATE UNIQUE INDEX IF NOT EXISTS "IDX_enthusiast_dataset_is_used_unique" ON "enthusiast_dataset" (is_used) WHERE is_used IS TRUE AND deleted_at IS NULL;`);
    }
    async down() {
        this.addSql(`drop table if exists "enthusiast_dataset" cascade;`);
    }
}
exports.Migration20251212151929 = Migration20251212151929;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTWlncmF0aW9uMjAyNTEyMTIxNTE5MjkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9lbnRodXNpYXN0L21pZ3JhdGlvbnMvTWlncmF0aW9uMjAyNTEyMTIxNTE5MjkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsc0RBQWtEO0FBRWxELE1BQWEsdUJBQXdCLFNBQVEsc0JBQVM7SUFDM0MsS0FBSyxDQUFDLEVBQUU7UUFDZixJQUFJLENBQUMsTUFBTSxDQUNULDJHQUEyRyxDQUM1RyxDQUFDO1FBQ0YsSUFBSSxDQUFDLE1BQU0sQ0FDVCwrbEJBQStsQixDQUNobUIsQ0FBQztRQUNGLElBQUksQ0FBQyxNQUFNLENBQ1QsK0hBQStILENBQ2hJLENBQUM7UUFDRixJQUFJLENBQUMsTUFBTSxDQUNULDJKQUEySixDQUM1SixDQUFDO0lBQ0osQ0FBQztJQUVRLEtBQUssQ0FBQyxJQUFJO1FBQ2pCLElBQUksQ0FBQyxNQUFNLENBQUMsb0RBQW9ELENBQUMsQ0FBQztJQUNwRSxDQUFDO0NBQ0Y7QUFuQkQsMERBbUJDIn0=