"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileUpload = FileUpload;
const jsx_runtime_1 = require("react/jsx-runtime");
const react_1 = require("react");
const react_dropzone_1 = require("react-dropzone");
const lucide_react_1 = require("lucide-react");
const button_1 = require("../../components/ui/button");
const utils_1 = require("../../admin/lib/utils");
const admin_client_1 = require("../../admin/lib/admin-client");
function FileUpload({ onFilesChange, uploadedFiles, onClose, disabled = false, showUploadArea = true, onUploadError, }) {
    const [dragActive, setDragActive] = (0, react_1.useState)(false);
    const [supportedExtensions, setSupportedExtensions] = (0, react_1.useState)([]);
    const [isLoadingExtensions, setIsLoadingExtensions] = (0, react_1.useState)(true);
    (0, react_1.useEffect)(() => {
        const fetchSupportedFileTypes = async () => {
            try {
                setIsLoadingExtensions(true);
                const result = await admin_client_1.adminApiClient.conversations().getSupportedFileTypes();
                setSupportedExtensions(result.supported_extensions || []);
            }
            catch (error) {
                console.error("Failed to fetch supported file types:", error);
            }
            finally {
                setIsLoadingExtensions(false);
            }
        };
        void fetchSupportedFileTypes();
    }, []);
    const onDrop = (0, react_1.useCallback)((acceptedFiles, rejectedFiles) => {
        if (disabled)
            return;
        if (rejectedFiles.length > 0) {
            const errors = rejectedFiles.map(({ file, errors }) => ({
                file: file.name,
                errors: errors.map((e) => e.message),
            }));
            if (onUploadError) {
                const errorMessages = errors
                    .map(({ file, errors }) => `${file}: ${errors.join(", ")}`)
                    .join("; ");
                onUploadError(errorMessages);
            }
        }
        const newFiles = acceptedFiles.map((file) => ({
            id: Math.random().toString(36).substr(2, 9),
            file,
            preview: file.type.startsWith("image/") ? URL.createObjectURL(file) : undefined,
        }));
        onClose();
        onFilesChange([...uploadedFiles, ...newFiles]);
    }, [uploadedFiles, onFilesChange, disabled, onUploadError, onClose]);
    const acceptObject = supportedExtensions.reduce((acc, ext) => {
        if (ext === ".txt")
            acc["text/plain"] = [];
        else if (ext === ".pdf")
            acc["application/pdf"] = [];
        else if (ext === ".jpg" || ext === ".jpeg")
            acc["image/jpeg"] = [];
        else if (ext === ".png")
            acc["image/png"] = [];
        return acc;
    }, {});
    const { getRootProps, getInputProps, isDragActive, open } = (0, react_dropzone_1.useDropzone)({
        onDrop,
        disabled: disabled || isLoadingExtensions,
        accept: isLoadingExtensions ? undefined : acceptObject,
    });
    return ((0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [(0, jsx_runtime_1.jsxs)(button_1.Button, { type: "button", variant: "ghost", size: "icon", onClick: open, disabled: disabled, className: "shrink-0 left-2 bottom-2 absolute", children: [(0, jsx_runtime_1.jsx)(lucide_react_1.Paperclip, { className: "h-4 w-4" }), (0, jsx_runtime_1.jsx)("span", { className: "sr-only", children: "Attach files" })] }), (0, jsx_runtime_1.jsx)("input", { ...getInputProps() }), showUploadArea && ((0, jsx_runtime_1.jsx)("div", { className: "space-y-3 absolute w-full h-full bg-background rounded-lg z-10", children: (0, jsx_runtime_1.jsxs)("div", { ...getRootProps(), className: (0, utils_1.cn)("relative h-full text-center flex flex-col justify-center transition-colors cursor-pointer", "hover:bg-muted focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2", isDragActive && "border-primary bg-primary/10", disabled && "opacity-50 cursor-not-allowed", dragActive && "border-primary bg-primary/10"), onDragEnter: () => setDragActive(true), onDragLeave: () => setDragActive(false), children: [(0, jsx_runtime_1.jsx)(lucide_react_1.Upload, { className: "mx-auto h-6 w-6 text-muted-foreground mb-2" }), (0, jsx_runtime_1.jsx)("div", { className: "text-sm text-foreground", children: "Drag and drop files here" }), (0, jsx_runtime_1.jsx)("div", { className: "text-xs text-muted-foreground mt-1", children: isLoadingExtensions
                                ? "Loading supported file types..."
                                : `Supported types: ${supportedExtensions.join(", ")}` })] }) }))] }));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmlsZS11cGxvYWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvY29tcG9uZW50cy9jaGF0L2ZpbGUtdXBsb2FkLnRzeCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQTJCQSxnQ0FxSEM7O0FBaEpELGlDQUF5RDtBQUN6RCxtREFBNEQ7QUFDNUQsK0NBQWlEO0FBQ2pELHVEQUFvRDtBQUNwRCxpREFBMkM7QUFDM0MsK0RBQThEO0FBc0I5RCxTQUFnQixVQUFVLENBQUMsRUFDekIsYUFBYSxFQUNiLGFBQWEsRUFDYixPQUFPLEVBQ1AsUUFBUSxHQUFHLEtBQUssRUFDaEIsY0FBYyxHQUFHLElBQUksRUFDckIsYUFBYSxHQUNHO0lBQ2hCLE1BQU0sQ0FBQyxVQUFVLEVBQUUsYUFBYSxDQUFDLEdBQUcsSUFBQSxnQkFBUSxFQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3BELE1BQU0sQ0FBQyxtQkFBbUIsRUFBRSxzQkFBc0IsQ0FBQyxHQUFHLElBQUEsZ0JBQVEsRUFBVyxFQUFFLENBQUMsQ0FBQztJQUM3RSxNQUFNLENBQUMsbUJBQW1CLEVBQUUsc0JBQXNCLENBQUMsR0FBRyxJQUFBLGdCQUFRLEVBQUMsSUFBSSxDQUFDLENBQUM7SUFFckUsSUFBQSxpQkFBUyxFQUFDLEdBQUcsRUFBRTtRQUNiLE1BQU0sdUJBQXVCLEdBQUcsS0FBSyxJQUFJLEVBQUU7WUFDekMsSUFBSSxDQUFDO2dCQUNILHNCQUFzQixDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUM3QixNQUFNLE1BQU0sR0FBRyxNQUFNLDZCQUFjLENBQUMsYUFBYSxFQUFFLENBQUMscUJBQXFCLEVBQUUsQ0FBQztnQkFDNUUsc0JBQXNCLENBQUMsTUFBTSxDQUFDLG9CQUFvQixJQUFJLEVBQUUsQ0FBQyxDQUFDO1lBQzVELENBQUM7WUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO2dCQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsdUNBQXVDLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDaEUsQ0FBQztvQkFBUyxDQUFDO2dCQUNULHNCQUFzQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ2hDLENBQUM7UUFDSCxDQUFDLENBQUM7UUFFRixLQUFLLHVCQUF1QixFQUFFLENBQUM7SUFDakMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBRVAsTUFBTSxNQUFNLEdBQUcsSUFBQSxtQkFBVyxFQUN4QixDQUFDLGFBQXFCLEVBQUUsYUFBOEIsRUFBRSxFQUFFO1FBQ3hELElBQUksUUFBUTtZQUFFLE9BQU87UUFFckIsSUFBSSxhQUFhLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQzdCLE1BQU0sTUFBTSxHQUFHLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDdEQsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO2dCQUNmLE1BQU0sRUFBRSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBc0IsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQzthQUMxRCxDQUFDLENBQUMsQ0FBQztZQUVKLElBQUksYUFBYSxFQUFFLENBQUM7Z0JBQ2xCLE1BQU0sYUFBYSxHQUFHLE1BQU07cUJBQ3pCLEdBQUcsQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUUsQ0FBQyxHQUFHLElBQUksS0FBSyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7cUJBQzFELElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDZCxhQUFhLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDL0IsQ0FBQztRQUNILENBQUM7UUFFRCxNQUFNLFFBQVEsR0FBbUIsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQztZQUM1RCxFQUFFLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUMzQyxJQUFJO1lBQ0osT0FBTyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTO1NBQ2hGLENBQUMsQ0FBQyxDQUFDO1FBRUosT0FBTyxFQUFFLENBQUM7UUFDVixhQUFhLENBQUMsQ0FBQyxHQUFHLGFBQWEsRUFBRSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFDakQsQ0FBQyxFQUNELENBQUMsYUFBYSxFQUFFLGFBQWEsRUFBRSxRQUFRLEVBQUUsYUFBYSxFQUFFLE9BQU8sQ0FBQyxDQUNqRSxDQUFDO0lBRUYsTUFBTSxZQUFZLEdBQUcsbUJBQW1CLENBQUMsTUFBTSxDQUM3QyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRTtRQUNYLElBQUksR0FBRyxLQUFLLE1BQU07WUFBRSxHQUFHLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxDQUFDO2FBQ3RDLElBQUksR0FBRyxLQUFLLE1BQU07WUFBRSxHQUFHLENBQUMsaUJBQWlCLENBQUMsR0FBRyxFQUFFLENBQUM7YUFDaEQsSUFBSSxHQUFHLEtBQUssTUFBTSxJQUFJLEdBQUcsS0FBSyxPQUFPO1lBQUUsR0FBRyxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsQ0FBQzthQUM5RCxJQUFJLEdBQUcsS0FBSyxNQUFNO1lBQUUsR0FBRyxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUMvQyxPQUFPLEdBQUcsQ0FBQztJQUNiLENBQUMsRUFDRCxFQUE4QixDQUMvQixDQUFDO0lBRUYsTUFBTSxFQUFFLFlBQVksRUFBRSxhQUFhLEVBQUUsWUFBWSxFQUFFLElBQUksRUFBRSxHQUFHLElBQUEsNEJBQVcsRUFBQztRQUN0RSxNQUFNO1FBQ04sUUFBUSxFQUFFLFFBQVEsSUFBSSxtQkFBbUI7UUFDekMsTUFBTSxFQUFFLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFlBQVk7S0FDdkQsQ0FBQyxDQUFDO0lBRUgsT0FBTyxDQUNMLDZEQUNFLHdCQUFDLGVBQU0sSUFDTCxJQUFJLEVBQUMsUUFBUSxFQUNiLE9BQU8sRUFBQyxPQUFPLEVBQ2YsSUFBSSxFQUFDLE1BQU0sRUFDWCxPQUFPLEVBQUUsSUFBSSxFQUNiLFFBQVEsRUFBRSxRQUFRLEVBQ2xCLFNBQVMsRUFBQyxtQ0FBbUMsYUFFN0MsdUJBQUMsd0JBQVMsSUFBQyxTQUFTLEVBQUMsU0FBUyxHQUFHLEVBQ2pDLGlDQUFNLFNBQVMsRUFBQyxTQUFTLDZCQUFvQixJQUN0QyxFQUVULHFDQUFXLGFBQWEsRUFBRSxHQUFJLEVBRTdCLGNBQWMsSUFBSSxDQUNqQixnQ0FBSyxTQUFTLEVBQUMsZ0VBQWdFLFlBQzdFLG9DQUNNLFlBQVksRUFBRSxFQUNsQixTQUFTLEVBQUUsSUFBQSxVQUFFLEVBQ1gsMkZBQTJGLEVBQzNGLG9GQUFvRixFQUNwRixZQUFZLElBQUksOEJBQThCLEVBQzlDLFFBQVEsSUFBSSwrQkFBK0IsRUFDM0MsVUFBVSxJQUFJLDhCQUE4QixDQUM3QyxFQUNELFdBQVcsRUFBRSxHQUFHLEVBQUUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEVBQ3RDLFdBQVcsRUFBRSxHQUFHLEVBQUUsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLGFBRXZDLHVCQUFDLHFCQUFNLElBQUMsU0FBUyxFQUFDLDRDQUE0QyxHQUFHLEVBQ2pFLGdDQUFLLFNBQVMsRUFBQyx5QkFBeUIseUNBQStCLEVBQ3ZFLGdDQUFLLFNBQVMsRUFBQyxvQ0FBb0MsWUFDaEQsbUJBQW1CO2dDQUNsQixDQUFDLENBQUMsaUNBQWlDO2dDQUNuQyxDQUFDLENBQUMsb0JBQW9CLG1CQUFtQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxHQUNwRCxJQUNGLEdBQ0YsQ0FDUCxJQUNBLENBQ0osQ0FBQztBQUNKLENBQUMifQ==