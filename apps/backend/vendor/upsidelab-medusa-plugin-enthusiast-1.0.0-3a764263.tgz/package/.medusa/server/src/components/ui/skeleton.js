"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Skeleton = Skeleton;
const jsx_runtime_1 = require("react/jsx-runtime");
const utils_1 = require("../../admin/lib/utils");
function Skeleton({ className, ...props }) {
    return (0, jsx_runtime_1.jsx)("div", { className: (0, utils_1.cn)("animate-pulse rounded-md bg-primary/10", className), ...props });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2tlbGV0b24uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvY29tcG9uZW50cy91aS9za2VsZXRvbi50c3giXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFNUyw0QkFBUTs7QUFOakIsaURBQTJDO0FBRTNDLFNBQVMsUUFBUSxDQUFDLEVBQUUsU0FBUyxFQUFFLEdBQUcsS0FBSyxFQUF3QztJQUM3RSxPQUFPLGdDQUFLLFNBQVMsRUFBRSxJQUFBLFVBQUUsRUFBQyx3Q0FBd0MsRUFBRSxTQUFTLENBQUMsS0FBTSxLQUFLLEdBQUksQ0FBQztBQUNoRyxDQUFDIn0=