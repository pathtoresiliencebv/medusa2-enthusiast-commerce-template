"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = void 0;
const enthusiast_1 = require("../../../../../modules/enthusiast");
const wrappers_1 = require("../../../../../api/wrappers");
exports.GET = (0, wrappers_1.withErrorHandler)(async (req, res) => {
    const enthusiastService = req.scope.resolve(enthusiast_1.ENTHUSIAST_MODULE);
    const taskId = req.params.id;
    const status = await enthusiastService.getFileUploadStatus(taskId);
    res.status(200).json(status);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2VudGh1c2lhc3QvZmlsZS11cGxvYWQtc3RhdHVzL1tpZF0vcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQ0Esa0VBQXNFO0FBRXRFLDBEQUErRDtBQUVsRCxRQUFBLEdBQUcsR0FBRyxJQUFBLDJCQUFnQixFQUFDLEtBQUssRUFBRSxHQUFrQixFQUFFLEdBQW1CLEVBQUUsRUFBRTtJQUNwRixNQUFNLGlCQUFpQixHQUFzQixHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyw4QkFBaUIsQ0FBQyxDQUFDO0lBQ2xGLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO0lBRTdCLE1BQU0sTUFBTSxHQUFHLE1BQU0saUJBQWlCLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLENBQUM7SUFFbkUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMifQ==