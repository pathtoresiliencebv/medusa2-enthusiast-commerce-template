"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileList = FileList;
const jsx_runtime_1 = require("react/jsx-runtime");
const lucide_react_1 = require("lucide-react");
const button_1 = require("../../components/ui/button");
const getFileIcon = (file) => {
    if (file.type.startsWith("image/")) {
        return (0, jsx_runtime_1.jsx)(lucide_react_1.Image, { className: "h-4 w-4 text-muted-foreground" });
    }
    if (file.type.includes("pdf") || file.type.includes("text")) {
        return (0, jsx_runtime_1.jsx)(lucide_react_1.FileText, { className: "h-4 w-4 text-muted-foreground" });
    }
    return (0, jsx_runtime_1.jsx)(lucide_react_1.File, { className: "h-4 w-4 text-muted-foreground" });
};
const formatFileSize = (bytes) => {
    if (bytes === 0)
        return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
};
const fileStatus = (file) => {
    if (file.uploaded) {
        return "Ready";
    }
    if (file.uploading) {
        return "Uploading...";
    }
    if (file.uploadError) {
        return "Upload failed";
    }
    return "";
};
function FileList({ uploadedFiles, handleFileRemove, disabled = false }) {
    return ((0, jsx_runtime_1.jsx)("div", { className: "flex w-full gap-2 flex-wrap", children: uploadedFiles.length > 0 &&
            uploadedFiles.map((uploadedFile) => ((0, jsx_runtime_1.jsxs)("div", { className: "flex items-center justify-between px-3 py-2 bg-muted rounded-lg border border-input w-[260px]", children: [(0, jsx_runtime_1.jsxs)("div", { className: "flex items-center space-x-3 flex-1 min-w-0", children: [uploadedFile.preview ? ((0, jsx_runtime_1.jsx)("img", { src: uploadedFile.preview, alt: uploadedFile.file.name, className: "h-8 w-8 object-cover rounded" })) : ((0, jsx_runtime_1.jsx)("div", { className: "h-8 w-8 bg-muted-foreground/20 rounded flex items-center justify-center", children: getFileIcon(uploadedFile.file) })), (0, jsx_runtime_1.jsxs)("div", { className: "flex-1 min-w-0", children: [(0, jsx_runtime_1.jsx)("div", { className: `text-sm font-medium truncate ${uploadedFile.uploadError ? "text-destructive" : "text-foreground"}`, children: uploadedFile.file.name }), (0, jsx_runtime_1.jsxs)("div", { className: "text-xs text-muted-foreground", children: [formatFileSize(uploadedFile.file.size), " \u2022 ", fileStatus(uploadedFile)] })] })] }), (0, jsx_runtime_1.jsx)(button_1.Button, { variant: "ghost", size: "sm", onClick: () => handleFileRemove(uploadedFile.id), disabled: disabled || uploadedFile.uploading, className: "h-8 w-8 p-0 hover:bg-destructive/10 hover:text-destructive ml-2", children: (0, jsx_runtime_1.jsx)(lucide_react_1.X, { className: "h-4 w-4" }) })] }, uploadedFile.id))) }));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmlsZS1saXN0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL2NvbXBvbmVudHMvY2hhdC9maWxlLWxpc3QudHN4Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBNkNBLDRCQTZDQzs7QUExRkQsK0NBQXdEO0FBQ3hELHVEQUFvRDtBQVlwRCxNQUFNLFdBQVcsR0FBRyxDQUFDLElBQVUsRUFBRSxFQUFFO0lBQ2pDLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQztRQUNuQyxPQUFPLHVCQUFDLG9CQUFLLElBQUMsU0FBUyxFQUFDLCtCQUErQixHQUFHLENBQUM7SUFDN0QsQ0FBQztJQUNELElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUM1RCxPQUFPLHVCQUFDLHVCQUFRLElBQUMsU0FBUyxFQUFDLCtCQUErQixHQUFHLENBQUM7SUFDaEUsQ0FBQztJQUNELE9BQU8sdUJBQUMsbUJBQUksSUFBQyxTQUFTLEVBQUMsK0JBQStCLEdBQUcsQ0FBQztBQUM1RCxDQUFDLENBQUM7QUFFRixNQUFNLGNBQWMsR0FBRyxDQUFDLEtBQWEsRUFBRSxFQUFFO0lBQ3ZDLElBQUksS0FBSyxLQUFLLENBQUM7UUFBRSxPQUFPLFNBQVMsQ0FBQztJQUNsQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUM7SUFDZixNQUFNLEtBQUssR0FBRyxDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQzFDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDcEQsT0FBTyxVQUFVLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFFLENBQUMsQ0FBQztBQUVGLE1BQU0sVUFBVSxHQUFHLENBQUMsSUFBa0IsRUFBRSxFQUFFO0lBQ3hDLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2xCLE9BQU8sT0FBTyxDQUFDO0lBQ2pCLENBQUM7SUFDRCxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNuQixPQUFPLGNBQWMsQ0FBQztJQUN4QixDQUFDO0lBQ0QsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDckIsT0FBTyxlQUFlLENBQUM7SUFDekIsQ0FBQztJQUVELE9BQU8sRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDO0FBRUYsU0FBZ0IsUUFBUSxDQUFDLEVBQUUsYUFBYSxFQUFFLGdCQUFnQixFQUFFLFFBQVEsR0FBRyxLQUFLLEVBQWlCO0lBQzNGLE9BQU8sQ0FDTCxnQ0FBSyxTQUFTLEVBQUMsNkJBQTZCLFlBQ3pDLGFBQWEsQ0FBQyxNQUFNLEdBQUcsQ0FBQztZQUN2QixhQUFhLENBQUMsR0FBRyxDQUFDLENBQUMsWUFBWSxFQUFFLEVBQUUsQ0FBQyxDQUNsQyxpQ0FFRSxTQUFTLEVBQUMsK0ZBQStGLGFBRXpHLGlDQUFLLFNBQVMsRUFBQyw0Q0FBNEMsYUFDeEQsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FDdEIsZ0NBQ0UsR0FBRyxFQUFFLFlBQVksQ0FBQyxPQUFPLEVBQ3pCLEdBQUcsRUFBRSxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksRUFDM0IsU0FBUyxFQUFDLDhCQUE4QixHQUN4QyxDQUNILENBQUMsQ0FBQyxDQUFDLENBQ0YsZ0NBQUssU0FBUyxFQUFDLHlFQUF5RSxZQUNyRixXQUFXLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxHQUMzQixDQUNQLEVBQ0QsaUNBQUssU0FBUyxFQUFDLGdCQUFnQixhQUM3QixnQ0FDRSxTQUFTLEVBQUUsZ0NBQWdDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxpQkFBaUIsRUFBRSxZQUU3RyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksR0FDbkIsRUFDTixpQ0FBSyxTQUFTLEVBQUMsK0JBQStCLGFBQzNDLGNBQWMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFLLFVBQVUsQ0FBQyxZQUFZLENBQUMsSUFDaEUsSUFDRixJQUNGLEVBQ04sdUJBQUMsZUFBTSxJQUNMLE9BQU8sRUFBQyxPQUFPLEVBQ2YsSUFBSSxFQUFDLElBQUksRUFDVCxPQUFPLEVBQUUsR0FBRyxFQUFFLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxFQUNoRCxRQUFRLEVBQUUsUUFBUSxJQUFJLFlBQVksQ0FBQyxTQUFTLEVBQzVDLFNBQVMsRUFBQyxpRUFBaUUsWUFFM0UsdUJBQUMsZ0JBQUMsSUFBQyxTQUFTLEVBQUMsU0FBUyxHQUFHLEdBQ2xCLEtBbENKLFlBQVksQ0FBQyxFQUFFLENBbUNoQixDQUNQLENBQUMsR0FDQSxDQUNQLENBQUM7QUFDSixDQUFDIn0=