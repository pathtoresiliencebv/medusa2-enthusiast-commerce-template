"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AttachmentBubble = AttachmentBubble;
const jsx_runtime_1 = require("react/jsx-runtime");
const base_bubble_1 = require("./base-bubble");
const lucide_react_1 = require("lucide-react");
const getFileIcon = (contentType) => {
    if (contentType.startsWith("image/")) {
        return (0, jsx_runtime_1.jsx)(lucide_react_1.Image, { className: "h-5 w-5 text-muted-foreground" });
    }
    if (contentType.includes("pdf") || contentType.includes("text")) {
        return (0, jsx_runtime_1.jsx)(lucide_react_1.FileText, { className: "h-5 w-5 text-muted-foreground" });
    }
    return (0, jsx_runtime_1.jsx)(lucide_react_1.File, { className: "h-5 w-5 text-muted-foreground" });
};
function AttachmentBubble({ variant, message, inMessageGroup }) {
    return ((0, jsx_runtime_1.jsx)(base_bubble_1.BaseBubble, { variant: variant, hasBackground: false, className: "px-0 py-0 min-w-[25%]", inMessageGroup: inMessageGroup, children: (0, jsx_runtime_1.jsxs)("div", { className: `flex items-center space-x-2 rounded-md border border-input bg-background shadow-sm px-3 py-2`, children: [(0, jsx_runtime_1.jsx)("div", { className: "h-8 w-8 bg-muted rounded flex items-center justify-center", children: getFileIcon(message.file_type) }), (0, jsx_runtime_1.jsxs)("div", { className: "flex-1 min-w-0", children: [(0, jsx_runtime_1.jsx)("div", { className: "text-sm font-medium truncate text-foreground", children: message.file_name }), (0, jsx_runtime_1.jsx)("div", { className: "text-xs text-muted-foreground", children: message.file_type })] })] }) }));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXR0YWNobWVudC1idWJibGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvY29tcG9uZW50cy9jaGF0L2F0dGFjaG1lbnQtYnViYmxlLnRzeCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQXFCQSw0Q0FxQkM7O0FBMUNELCtDQUEyQztBQUMzQywrQ0FBcUQ7QUFVckQsTUFBTSxXQUFXLEdBQUcsQ0FBQyxXQUFtQixFQUFFLEVBQUU7SUFDMUMsSUFBSSxXQUFXLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUM7UUFDckMsT0FBTyx1QkFBQyxvQkFBSyxJQUFDLFNBQVMsRUFBQywrQkFBK0IsR0FBRyxDQUFDO0lBQzdELENBQUM7SUFDRCxJQUFJLFdBQVcsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksV0FBVyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQ2hFLE9BQU8sdUJBQUMsdUJBQVEsSUFBQyxTQUFTLEVBQUMsK0JBQStCLEdBQUcsQ0FBQztJQUNoRSxDQUFDO0lBQ0QsT0FBTyx1QkFBQyxtQkFBSSxJQUFDLFNBQVMsRUFBQywrQkFBK0IsR0FBRyxDQUFDO0FBQzVELENBQUMsQ0FBQztBQUVGLFNBQWdCLGdCQUFnQixDQUFDLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxjQUFjLEVBQXlCO0lBQzFGLE9BQU8sQ0FDTCx1QkFBQyx3QkFBVSxJQUNULE9BQU8sRUFBRSxPQUFPLEVBQ2hCLGFBQWEsRUFBRSxLQUFLLEVBQ3BCLFNBQVMsRUFBQyx1QkFBdUIsRUFDakMsY0FBYyxFQUFFLGNBQWMsWUFFOUIsaUNBQ0UsU0FBUyxFQUFFLDhGQUE4RixhQUV6RyxnQ0FBSyxTQUFTLEVBQUMsMkRBQTJELFlBQ3ZFLFdBQVcsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEdBQzNCLEVBQ04saUNBQUssU0FBUyxFQUFDLGdCQUFnQixhQUM3QixnQ0FBSyxTQUFTLEVBQUMsOENBQThDLFlBQUUsT0FBTyxDQUFDLFNBQVMsR0FBTyxFQUN2RixnQ0FBSyxTQUFTLEVBQUMsK0JBQStCLFlBQUUsT0FBTyxDQUFDLFNBQVMsR0FBTyxJQUNwRSxJQUNGLEdBQ0ssQ0FDZCxDQUFDO0FBQ0osQ0FBQyJ9