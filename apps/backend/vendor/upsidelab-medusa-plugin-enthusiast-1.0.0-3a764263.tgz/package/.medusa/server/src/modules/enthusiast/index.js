"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ENTHUSIAST_MODULE = void 0;
const service_1 = __importDefault(require("./service"));
const utils_1 = require("@medusajs/framework/utils");
const check_options_1 = __importDefault(require("./loaders/check-options"));
exports.ENTHUSIAST_MODULE = "enthusiast";
exports.default = (0, utils_1.Module)(exports.ENTHUSIAST_MODULE, {
    service: service_1.default,
    loaders: [check_options_1.default],
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9lbnRodXNpYXN0L2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBLHdEQUEwQztBQUMxQyxxREFBbUQ7QUFDbkQsNEVBQXlEO0FBRTVDLFFBQUEsaUJBQWlCLEdBQUcsWUFBWSxDQUFDO0FBRTlDLGtCQUFlLElBQUEsY0FBTSxFQUFDLHlCQUFpQixFQUFFO0lBQ3ZDLE9BQU8sRUFBRSxpQkFBaUI7SUFDMUIsT0FBTyxFQUFFLENBQUMsdUJBQWtCLENBQUM7Q0FDOUIsQ0FBQyxDQUFDIn0=