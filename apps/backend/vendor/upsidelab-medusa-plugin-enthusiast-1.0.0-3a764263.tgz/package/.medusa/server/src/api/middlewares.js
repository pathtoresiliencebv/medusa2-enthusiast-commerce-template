"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const http_1 = require("@medusajs/framework/http");
const multer_1 = __importDefault(require("multer"));
const validators_1 = require("../api/admin/datasets/validators");
const upload = (0, multer_1.default)();
exports.default = (0, http_1.defineMiddlewares)({
    routes: [
        {
            matcher: "/admin/enthusiast/conversations/:id",
            middlewares: [
                // @ts-ignore
                upload.single("file"),
            ],
        },
        {
            matcher: "/admin/enthusiast/datasets",
            method: "POST",
            middlewares: [(0, http_1.validateAndTransformBody)(validators_1.PostCreateDatasetSchema)],
        },
    ],
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWlkZGxld2FyZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvYXBpL21pZGRsZXdhcmVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsbURBQXVGO0FBQ3ZGLG9EQUE0QjtBQUM1QixpRUFBMkU7QUFFM0UsTUFBTSxNQUFNLEdBQUcsSUFBQSxnQkFBTSxHQUFFLENBQUM7QUFFeEIsa0JBQWUsSUFBQSx3QkFBaUIsRUFBQztJQUMvQixNQUFNLEVBQUU7UUFDTjtZQUNFLE9BQU8sRUFBRSxxQ0FBcUM7WUFDOUMsV0FBVyxFQUFFO2dCQUNYLGFBQWE7Z0JBQ2IsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDdEI7U0FDRjtRQUNEO1lBQ0UsT0FBTyxFQUFFLDRCQUE0QjtZQUNyQyxNQUFNLEVBQUUsTUFBTTtZQUNkLFdBQVcsRUFBRSxDQUFDLElBQUEsK0JBQXdCLEVBQUMsb0NBQXVCLENBQUMsQ0FBQztTQUNqRTtLQUNGO0NBQ0YsQ0FBQyxDQUFDIn0=