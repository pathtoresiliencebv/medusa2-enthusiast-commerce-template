"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ApiError = void 0;
class ApiError extends Error {
    constructor(message, response) {
        super(message);
        this.response = response;
        this.name = "ApiError";
    }
}
exports.ApiError = ApiError;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXJyb3IuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9lbnRodXNpYXN0L2FwaS9lcnJvci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxNQUFhLFFBQVMsU0FBUSxLQUFLO0lBQ2pDLFlBQ0UsT0FBZSxFQUNSLFFBR047UUFFRCxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7UUFMUixhQUFRLEdBQVIsUUFBUSxDQUdkO1FBR0QsSUFBSSxDQUFDLElBQUksR0FBRyxVQUFVLENBQUM7SUFDekIsQ0FBQztDQUNGO0FBWEQsNEJBV0MifQ==