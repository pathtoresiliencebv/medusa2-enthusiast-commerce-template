"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CopyToClipboardButton = CopyToClipboardButton;
const jsx_runtime_1 = require("react/jsx-runtime");
const react_1 = require("react");
const button_1 = require("../../components/ui/button");
const lucide_react_1 = require("lucide-react");
function CopyToClipboardButton({ message, variant }) {
    const [isCopied, setIsCopied] = (0, react_1.useState)(false);
    const handleCopyClick = async () => {
        await navigator.clipboard.writeText(message);
        setIsCopied(true);
        setTimeout(() => {
            setIsCopied(false);
        }, 2000);
    };
    return ((0, jsx_runtime_1.jsxs)(button_1.Button, { onClick: () => {
            void handleCopyClick();
        }, variant: variant, children: [(0, jsx_runtime_1.jsx)(lucide_react_1.CopyIcon, {}), isCopied ? "Copied!" : "Copy"] }));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29weS10by1jbGlwYm9hcmQtYnV0dG9uLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL2NvbXBvbmVudHMvY2hhdC9jb3B5LXRvLWNsaXBib2FyZC1idXR0b24udHN4Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBU0Esc0RBdUJDOztBQWhDRCxpQ0FBaUM7QUFDakMsdURBQW9EO0FBQ3BELCtDQUF3QztBQU94QyxTQUFnQixxQkFBcUIsQ0FBQyxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQThCO0lBQ3BGLE1BQU0sQ0FBQyxRQUFRLEVBQUUsV0FBVyxDQUFDLEdBQUcsSUFBQSxnQkFBUSxFQUFDLEtBQUssQ0FBQyxDQUFDO0lBRWhELE1BQU0sZUFBZSxHQUFHLEtBQUssSUFBSSxFQUFFO1FBQ2pDLE1BQU0sU0FBUyxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDN0MsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRWxCLFVBQVUsQ0FBQyxHQUFHLEVBQUU7WUFDZCxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDckIsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ1gsQ0FBQyxDQUFDO0lBRUYsT0FBTyxDQUNMLHdCQUFDLGVBQU0sSUFDTCxPQUFPLEVBQUUsR0FBRyxFQUFFO1lBQ1osS0FBSyxlQUFlLEVBQUUsQ0FBQztRQUN6QixDQUFDLEVBQ0QsT0FBTyxFQUFFLE9BQU8sYUFFaEIsdUJBQUMsdUJBQVEsS0FBRyxFQUNYLFFBQVEsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLElBQ3ZCLENBQ1YsQ0FBQztBQUNKLENBQUMifQ==