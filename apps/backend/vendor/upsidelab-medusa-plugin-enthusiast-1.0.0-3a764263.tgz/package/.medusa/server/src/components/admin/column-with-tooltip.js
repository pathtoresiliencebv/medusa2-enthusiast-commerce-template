"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ColumnHeaderWithTooltip = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
const ui_1 = require("@medusajs/ui");
const icons_1 = require("@medusajs/icons");
const ColumnHeaderWithTooltip = ({ name, tooltip }) => {
    return ((0, jsx_runtime_1.jsxs)("div", { className: "flex items-center gap-x-1", children: [(0, jsx_runtime_1.jsx)("span", { children: name }), tooltip && ((0, jsx_runtime_1.jsx)(ui_1.Tooltip, { content: tooltip, children: (0, jsx_runtime_1.jsx)("button", { type: "button", className: "text-ui-fg-subtle hover:text-ui-fg-base", children: (0, jsx_runtime_1.jsx)(icons_1.InformationCircle, {}) }) }))] }));
};
exports.ColumnHeaderWithTooltip = ColumnHeaderWithTooltip;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29sdW1uLXdpdGgtdG9vbHRpcC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9jb21wb25lbnRzL2FkbWluL2NvbHVtbi13aXRoLXRvb2x0aXAudHN4Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7QUFBQSxxQ0FBdUM7QUFDdkMsMkNBQW9EO0FBTzdDLE1BQU0sdUJBQXVCLEdBQUcsQ0FBQyxFQUFFLElBQUksRUFBRSxPQUFPLEVBQWdDLEVBQUUsRUFBRTtJQUN6RixPQUFPLENBQ0wsaUNBQUssU0FBUyxFQUFDLDJCQUEyQixhQUN4QywyQ0FBTyxJQUFJLEdBQVEsRUFFbEIsT0FBTyxJQUFJLENBQ1YsdUJBQUMsWUFBTyxJQUFDLE9BQU8sRUFBRSxPQUFPLFlBQ3ZCLG1DQUFRLElBQUksRUFBQyxRQUFRLEVBQUMsU0FBUyxFQUFDLHlDQUF5QyxZQUN2RSx1QkFBQyx5QkFBaUIsS0FBRyxHQUNkLEdBQ0QsQ0FDWCxJQUNHLENBQ1AsQ0FBQztBQUNKLENBQUMsQ0FBQztBQWRXLFFBQUEsdUJBQXVCLDJCQWNsQyJ9