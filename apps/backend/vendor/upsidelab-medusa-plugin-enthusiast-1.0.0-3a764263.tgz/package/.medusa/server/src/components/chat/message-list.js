"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageList = MessageList;
const jsx_runtime_1 = require("react/jsx-runtime");
const message_bubble_1 = require("./message-bubble");
const attachment_bubble_1 = require("./attachment-bubble");
const message_error_1 = require("./message-error");
const message_bubble_typing_1 = require("./message-bubble-typing");
const isUserMessage = (message) => message.type === "human" || message.type === "file";
function MessageList({ messages, agentAction, isAgentLoading, lastMessageRef, }) {
    return ((0, jsx_runtime_1.jsxs)("div", { className: "grow flex-1 space-y-4", children: [messages.map((message, index) => {
                const inMessageGroup = isUserMessage(message) && index > 0 && isUserMessage(messages[index - 1]);
                if (message.type === "system") {
                    return (0, jsx_runtime_1.jsx)(message_error_1.MessageError, { text: message.text }, index);
                }
                if (message.type === "file") {
                    return ((0, jsx_runtime_1.jsx)(attachment_bubble_1.AttachmentBubble, { variant: "primary", message: message, inMessageGroup: inMessageGroup }, index));
                }
                if (message.type === "ai" && message.text === "") {
                    return (0, jsx_runtime_1.jsx)(message_bubble_typing_1.MessageBubbleTyping, { text: agentAction }, index);
                }
                return ((0, jsx_runtime_1.jsx)(message_bubble_1.MessageBubble, { text: message.text, variant: message.type === "human" ? "primary" : "secondary", questionId: message.id, inMessageGroup: inMessageGroup }, index));
            }), isAgentLoading && !messages.some((msg) => msg.type === "ai" && msg.text === "") && ((0, jsx_runtime_1.jsx)(message_bubble_typing_1.MessageBubbleTyping, { text: agentAction })), (0, jsx_runtime_1.jsx)("div", { className: "mb-4" }), (0, jsx_runtime_1.jsx)("div", { ref: lastMessageRef })] }));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVzc2FnZS1saXN0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL2NvbXBvbmVudHMvY2hhdC9tZXNzYWdlLWxpc3QudHN4Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBaUJBLGtDQWdEQzs7QUFoRUQscURBQWlEO0FBQ2pELDJEQUF1RDtBQUN2RCxtREFBK0M7QUFDL0MsbUVBQThEO0FBVTlELE1BQU0sYUFBYSxHQUFHLENBQUMsT0FBcUIsRUFBRSxFQUFFLENBQzlDLE9BQU8sQ0FBQyxJQUFJLEtBQUssT0FBTyxJQUFJLE9BQU8sQ0FBQyxJQUFJLEtBQUssTUFBTSxDQUFDO0FBRXRELFNBQWdCLFdBQVcsQ0FBQyxFQUMxQixRQUFRLEVBQ1IsV0FBVyxFQUNYLGNBQWMsRUFDZCxjQUFjLEdBQ0c7SUFDakIsT0FBTyxDQUNMLGlDQUFLLFNBQVMsRUFBQyx1QkFBdUIsYUFDbkMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRSxLQUFLLEVBQUUsRUFBRTtnQkFDL0IsTUFBTSxjQUFjLEdBQ2xCLGFBQWEsQ0FBQyxPQUFPLENBQUMsSUFBSSxLQUFLLEdBQUcsQ0FBQyxJQUFJLGFBQWEsQ0FBQyxRQUFRLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRTVFLElBQUksT0FBTyxDQUFDLElBQUksS0FBSyxRQUFRLEVBQUUsQ0FBQztvQkFDOUIsT0FBTyx1QkFBQyw0QkFBWSxJQUFhLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSSxJQUF6QixLQUFLLENBQXdCLENBQUM7Z0JBQzFELENBQUM7Z0JBRUQsSUFBSSxPQUFPLENBQUMsSUFBSSxLQUFLLE1BQU0sRUFBRSxDQUFDO29CQUM1QixPQUFPLENBQ0wsdUJBQUMsb0NBQWdCLElBRWYsT0FBTyxFQUFDLFNBQVMsRUFDakIsT0FBTyxFQUFFLE9BQU8sRUFDaEIsY0FBYyxFQUFFLGNBQWMsSUFIekIsS0FBSyxDQUlWLENBQ0gsQ0FBQztnQkFDSixDQUFDO2dCQUVELElBQUksT0FBTyxDQUFDLElBQUksS0FBSyxJQUFJLElBQUksT0FBTyxDQUFDLElBQUksS0FBSyxFQUFFLEVBQUUsQ0FBQztvQkFDakQsT0FBTyx1QkFBQywyQ0FBbUIsSUFBYSxJQUFJLEVBQUUsV0FBVyxJQUF4QixLQUFLLENBQXVCLENBQUM7Z0JBQ2hFLENBQUM7Z0JBRUQsT0FBTyxDQUNMLHVCQUFDLDhCQUFhLElBRVosSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQ2xCLE9BQU8sRUFBRSxPQUFPLENBQUMsSUFBSSxLQUFLLE9BQU8sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQzNELFVBQVUsRUFBRSxPQUFPLENBQUMsRUFBRSxFQUN0QixjQUFjLEVBQUUsY0FBYyxJQUp6QixLQUFLLENBS1YsQ0FDSCxDQUFDO1lBQ0osQ0FBQyxDQUFDLEVBQ0QsY0FBYyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLElBQUksS0FBSyxJQUFJLElBQUksR0FBRyxDQUFDLElBQUksS0FBSyxFQUFFLENBQUMsSUFBSSxDQUNsRix1QkFBQywyQ0FBbUIsSUFBQyxJQUFJLEVBQUUsV0FBVyxHQUFJLENBQzNDLEVBQ0QsZ0NBQUssU0FBUyxFQUFDLE1BQU0sR0FBRyxFQUN4QixnQ0FBSyxHQUFHLEVBQUUsY0FBYyxHQUFJLElBQ3hCLENBQ1AsQ0FBQztBQUNKLENBQUMifQ==