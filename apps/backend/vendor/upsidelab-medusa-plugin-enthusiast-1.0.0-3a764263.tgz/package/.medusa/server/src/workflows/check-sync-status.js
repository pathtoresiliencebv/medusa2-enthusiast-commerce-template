"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.syncDatasetStatusWorkflow = void 0;
const workflows_sdk_1 = require("@medusajs/framework/workflows-sdk");
const enthusiast_1 = require("../modules/enthusiast");
const types_1 = require("../modules/enthusiast/types");
const SUCCESS_STATUS = "SUCCESS";
const FAILURE_STATUS = "FAILURE";
const poolDatasetSyncStatusStep = (0, workflows_sdk_1.createStep)({
    name: "pool-sync-status",
    async: true,
    backgroundExecution: true,
    timeout: 5 * 60,
}, async ({ datasetId }, { container }) => {
    const enthusiastService = container.resolve(enthusiast_1.ENTHUSIAST_MODULE);
    const datasets = await enthusiastService.listEnthusiastDatasets({ id: datasetId });
    if (!datasets || !datasets.length) {
        return new workflows_sdk_1.StepResponse();
    }
    const dataset = datasets[0];
    if (!dataset.task_id) {
        return new workflows_sdk_1.StepResponse();
    }
    // eslint-disable-next-line no-constant-condition
    while (true) {
        const taskStatus = await enthusiastService.getTaskStatus({
            task_id: dataset.task_id,
            streaming: false,
        });
        if (taskStatus === SUCCESS_STATUS) {
            await enthusiastService.updateEnthusiastDatasets({
                id: dataset.id,
                last_synced: new Date(),
                sync_status: types_1.SyncStatus.SUCCESS,
                task_id: null,
            });
            return new workflows_sdk_1.StepResponse();
        }
        if (taskStatus === FAILURE_STATUS) {
            await enthusiastService.updateEnthusiastDatasets({
                id: dataset.id,
                last_synced: new Date(),
                sync_status: types_1.SyncStatus.FAILED,
                task_id: null,
            });
            return new workflows_sdk_1.StepResponse();
        }
        await new Promise((resolve) => setTimeout(resolve, 5000));
    }
});
exports.syncDatasetStatusWorkflow = (0, workflows_sdk_1.createWorkflow)({ name: "sync-dataset-status-workflow" }, function (input) {
    poolDatasetSyncStatusStep(input);
    return new workflows_sdk_1.WorkflowResponse({});
});
exports.default = exports.syncDatasetStatusWorkflow;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hlY2stc3luYy1zdGF0dXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvd29ya2Zsb3dzL2NoZWNrLXN5bmMtc3RhdHVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLHFFQUsyQztBQUUzQyxzREFBMEQ7QUFDMUQsdURBQXlEO0FBTXpELE1BQU0sY0FBYyxHQUFHLFNBQVMsQ0FBQztBQUNqQyxNQUFNLGNBQWMsR0FBRyxTQUFTLENBQUM7QUFFakMsTUFBTSx5QkFBeUIsR0FBRyxJQUFBLDBCQUFVLEVBQzFDO0lBQ0UsSUFBSSxFQUFFLGtCQUFrQjtJQUN4QixLQUFLLEVBQUUsSUFBSTtJQUNYLG1CQUFtQixFQUFFLElBQUk7SUFDekIsT0FBTyxFQUFFLENBQUMsR0FBRyxFQUFFO0NBQ2hCLEVBQ0QsS0FBSyxFQUFFLEVBQUUsU0FBUyxFQUFrQyxFQUFFLEVBQUUsU0FBUyxFQUFFLEVBQUUsRUFBRTtJQUNyRSxNQUFNLGlCQUFpQixHQUFzQixTQUFTLENBQUMsT0FBTyxDQUFDLDhCQUFpQixDQUFDLENBQUM7SUFDbEYsTUFBTSxRQUFRLEdBQUcsTUFBTSxpQkFBaUIsQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFLEVBQUUsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDO0lBQ25GLElBQUksQ0FBQyxRQUFRLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDbEMsT0FBTyxJQUFJLDRCQUFZLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBQ0QsTUFBTSxPQUFPLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzVCLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDckIsT0FBTyxJQUFJLDRCQUFZLEVBQUUsQ0FBQztJQUM1QixDQUFDO0lBQ0QsaURBQWlEO0lBQ2pELE9BQU8sSUFBSSxFQUFFLENBQUM7UUFDWixNQUFNLFVBQVUsR0FBRyxNQUFNLGlCQUFpQixDQUFDLGFBQWEsQ0FBQztZQUN2RCxPQUFPLEVBQUUsT0FBTyxDQUFDLE9BQU87WUFDeEIsU0FBUyxFQUFFLEtBQUs7U0FDakIsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxVQUFVLEtBQUssY0FBYyxFQUFFLENBQUM7WUFDbEMsTUFBTSxpQkFBaUIsQ0FBQyx3QkFBd0IsQ0FBQztnQkFDL0MsRUFBRSxFQUFFLE9BQU8sQ0FBQyxFQUFFO2dCQUNkLFdBQVcsRUFBRSxJQUFJLElBQUksRUFBRTtnQkFDdkIsV0FBVyxFQUFFLGtCQUFVLENBQUMsT0FBTztnQkFDL0IsT0FBTyxFQUFFLElBQUk7YUFDZCxDQUFDLENBQUM7WUFDSCxPQUFPLElBQUksNEJBQVksRUFBRSxDQUFDO1FBQzVCLENBQUM7UUFDRCxJQUFJLFVBQVUsS0FBSyxjQUFjLEVBQUUsQ0FBQztZQUNsQyxNQUFNLGlCQUFpQixDQUFDLHdCQUF3QixDQUFDO2dCQUMvQyxFQUFFLEVBQUUsT0FBTyxDQUFDLEVBQUU7Z0JBQ2QsV0FBVyxFQUFFLElBQUksSUFBSSxFQUFFO2dCQUN2QixXQUFXLEVBQUUsa0JBQVUsQ0FBQyxNQUFNO2dCQUM5QixPQUFPLEVBQUUsSUFBSTthQUNkLENBQUMsQ0FBQztZQUNILE9BQU8sSUFBSSw0QkFBWSxFQUFFLENBQUM7UUFDNUIsQ0FBQztRQUNELE1BQU0sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUM1RCxDQUFDO0FBQ0gsQ0FBQyxDQUNGLENBQUM7QUFFVyxRQUFBLHlCQUF5QixHQUFHLElBQUEsOEJBQWMsRUFDckQsRUFBRSxJQUFJLEVBQUUsOEJBQThCLEVBQUUsRUFDeEMsVUFBVSxLQUFxQztJQUM3Qyx5QkFBeUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNqQyxPQUFPLElBQUksZ0NBQWdCLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUNGLENBQUM7QUFFRixrQkFBZSxpQ0FBeUIsQ0FBQyJ9