"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebsocketHandler = void 0;
const events_1 = require("events");
const ws_1 = __importDefault(require("ws"));
class WebsocketHandler extends events_1.EventEmitter {
    constructor(wsBaseUrl) {
        super();
        this.handleWebSocketMessage = (data) => {
            try {
                // eslint-disable-next-line @typescript-eslint/no-base-to-string
                const parsed = JSON.parse(data.toString());
                this.emit("message", {
                    type: parsed.event || "",
                    payload: parsed.data,
                });
            }
            catch (err) {
                this.emit("error", err);
            }
        };
        this.handleWebSocketError = (err) => {
            this.emit("error", err);
        };
        this.handleWebSocketClose = (code, reason) => {
            const clean = code === 1000;
            if (!clean) {
                this.emit("close", { code, reason: reason.toString() });
            }
        };
        this.wsBaseUrl_ = wsBaseUrl;
    }
    createWsConnection(conversationId) {
        if (this.ws?.readyState === ws_1.default.OPEN)
            return;
        this.ws?.close();
        this.ws = new ws_1.default(`${this.wsBaseUrl_}/ws/chat/${conversationId}/`);
        this.ws.on("message", this.handleWebSocketMessage);
        this.ws.on("error", this.handleWebSocketError);
        this.ws.on("close", this.handleWebSocketClose);
    }
}
exports.WebsocketHandler = WebsocketHandler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoid2Vic29ja2V0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL21vZHVsZXMvZW50aHVzaWFzdC93ZWJzb2NrZXQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUEsbUNBQXNDO0FBQ3RDLDRDQUEyQjtBQUUzQixNQUFhLGdCQUFpQixTQUFRLHFCQUFZO0lBSWhELFlBQVksU0FBaUI7UUFDM0IsS0FBSyxFQUFFLENBQUM7UUFJRiwyQkFBc0IsR0FBRyxDQUFDLElBQXVCLEVBQUUsRUFBRTtZQUMzRCxJQUFJLENBQUM7Z0JBQ0gsZ0VBQWdFO2dCQUNoRSxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBdUMsQ0FBQztnQkFDakYsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUU7b0JBQ25CLElBQUksRUFBRSxNQUFNLENBQUMsS0FBSyxJQUFJLEVBQUU7b0JBQ3hCLE9BQU8sRUFBRSxNQUFNLENBQUMsSUFBSTtpQkFDckIsQ0FBQyxDQUFDO1lBQ0wsQ0FBQztZQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7Z0JBQ2IsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDMUIsQ0FBQztRQUNILENBQUMsQ0FBQztRQUVNLHlCQUFvQixHQUFHLENBQUMsR0FBVSxFQUFFLEVBQUU7WUFDNUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDMUIsQ0FBQyxDQUFDO1FBRU0seUJBQW9CLEdBQUcsQ0FBQyxJQUFZLEVBQUUsTUFBYyxFQUFFLEVBQUU7WUFDOUQsTUFBTSxLQUFLLEdBQUcsSUFBSSxLQUFLLElBQUksQ0FBQztZQUM1QixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7Z0JBQ1gsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDMUQsQ0FBQztRQUNILENBQUMsQ0FBQztRQXpCQSxJQUFJLENBQUMsVUFBVSxHQUFHLFNBQVMsQ0FBQztJQUM5QixDQUFDO0lBMEJELGtCQUFrQixDQUFDLGNBQXNCO1FBQ3ZDLElBQUksSUFBSSxDQUFDLEVBQUUsRUFBRSxVQUFVLEtBQUssWUFBUyxDQUFDLElBQUk7WUFBRSxPQUFPO1FBQ25ELElBQUksQ0FBQyxFQUFFLEVBQUUsS0FBSyxFQUFFLENBQUM7UUFFakIsSUFBSSxDQUFDLEVBQUUsR0FBRyxJQUFJLFlBQVMsQ0FBQyxHQUFHLElBQUksQ0FBQyxVQUFVLFlBQVksY0FBYyxHQUFHLENBQUMsQ0FBQztRQUV6RSxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLHNCQUFzQixDQUFDLENBQUM7UUFDbkQsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1FBQy9DLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQztJQUNqRCxDQUFDO0NBQ0Y7QUEzQ0QsNENBMkNDIn0=