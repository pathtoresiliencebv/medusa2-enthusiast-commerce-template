"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("@medusajs/framework/utils");
const types_1 = require("../types");
const EnthusiastDataset = utils_1.model
    .define("enthusiast_dataset", {
    id: utils_1.model.id().primaryKey(),
    external_id: utils_1.model.number(),
    name: utils_1.model.text().default("Dataset"),
    is_connected: utils_1.model.boolean().default(false),
    last_synced: utils_1.model.dateTime().nullable(),
    plugin_id: utils_1.model.number().nullable(),
    task_id: utils_1.model.text().nullable(),
    sync_status: utils_1.model.enum(types_1.SyncStatus).nullable(),
    api_key_id: utils_1.model.text().nullable(),
    is_active: utils_1.model.boolean().default(false),
})
    .indexes([
    {
        on: ["is_active"],
        where: {
            is_active: true,
        },
        unique: true,
    },
]);
exports.default = EnthusiastDataset;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW50aHVzaWFzdC1kYXRhc2V0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vc3JjL21vZHVsZXMvZW50aHVzaWFzdC9tb2RlbHMvZW50aHVzaWFzdC1kYXRhc2V0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEscURBQWtEO0FBQ2xELG9DQUFzQztBQUV0QyxNQUFNLGlCQUFpQixHQUFHLGFBQUs7S0FDNUIsTUFBTSxDQUFDLG9CQUFvQixFQUFFO0lBQzVCLEVBQUUsRUFBRSxhQUFLLENBQUMsRUFBRSxFQUFFLENBQUMsVUFBVSxFQUFFO0lBQzNCLFdBQVcsRUFBRSxhQUFLLENBQUMsTUFBTSxFQUFFO0lBQzNCLElBQUksRUFBRSxhQUFLLENBQUMsSUFBSSxFQUFFLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQztJQUNyQyxZQUFZLEVBQUUsYUFBSyxDQUFDLE9BQU8sRUFBRSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7SUFDNUMsV0FBVyxFQUFFLGFBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDeEMsU0FBUyxFQUFFLGFBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDcEMsT0FBTyxFQUFFLGFBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUU7SUFDaEMsV0FBVyxFQUFFLGFBQUssQ0FBQyxJQUFJLENBQUMsa0JBQVUsQ0FBQyxDQUFDLFFBQVEsRUFBRTtJQUM5QyxVQUFVLEVBQUUsYUFBSyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRTtJQUNuQyxTQUFTLEVBQUUsYUFBSyxDQUFDLE9BQU8sRUFBRSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7Q0FDMUMsQ0FBQztLQUNELE9BQU8sQ0FBQztJQUNQO1FBQ0UsRUFBRSxFQUFFLENBQUMsV0FBVyxDQUFDO1FBQ2pCLEtBQUssRUFBRTtZQUNMLFNBQVMsRUFBRSxJQUFJO1NBQ2hCO1FBQ0QsTUFBTSxFQUFFLElBQUk7S0FDYjtDQUNGLENBQUMsQ0FBQztBQUVMLGtCQUFlLGlCQUFpQixDQUFDIn0=