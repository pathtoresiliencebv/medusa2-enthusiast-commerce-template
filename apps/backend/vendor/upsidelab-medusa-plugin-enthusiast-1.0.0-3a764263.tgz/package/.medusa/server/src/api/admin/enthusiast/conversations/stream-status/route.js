"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = void 0;
const enthusiast_1 = require("../../../../../modules/enthusiast");
const wrappers_1 = require("../../../../../api/wrappers");
exports.GET = (0, wrappers_1.withErrorHandler)(async (req, res) => {
    const enthusiastService = req.scope.resolve(enthusiast_1.ENTHUSIAST_MODULE);
    const result = await enthusiastService.getStreamStatus();
    res.status(200).json(result);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2VudGh1c2lhc3QvY29udmVyc2F0aW9ucy9zdHJlYW0tc3RhdHVzL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUNBLGtFQUFzRTtBQUV0RSwwREFBK0Q7QUFFbEQsUUFBQSxHQUFHLEdBQUcsSUFBQSwyQkFBZ0IsRUFBQyxLQUFLLEVBQUUsR0FBa0IsRUFBRSxHQUFtQixFQUFFLEVBQUU7SUFDcEYsTUFBTSxpQkFBaUIsR0FBc0IsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsOEJBQWlCLENBQUMsQ0FBQztJQUNsRixNQUFNLE1BQU0sR0FBRyxNQUFNLGlCQUFpQixDQUFDLGVBQWUsRUFBRSxDQUFDO0lBRXpELEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDIn0=