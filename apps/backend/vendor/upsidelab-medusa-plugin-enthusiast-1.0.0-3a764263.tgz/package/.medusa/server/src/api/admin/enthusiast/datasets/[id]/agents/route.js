"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = void 0;
const enthusiast_1 = require("../../../../../../modules/enthusiast");
const wrappers_1 = require("../../../../../../api/wrappers");
exports.GET = (0, wrappers_1.withErrorHandler)(async (req, res) => {
    const enthusiastService = req.scope.resolve(enthusiast_1.ENTHUSIAST_MODULE);
    res.status(200).json(await enthusiastService.listAgents(parseInt(req.params.id)));
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2VudGh1c2lhc3QvZGF0YXNldHMvW2lkXS9hZ2VudHMvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQ0EscUVBQXlFO0FBRXpFLDZEQUFrRTtBQUVyRCxRQUFBLEdBQUcsR0FBRyxJQUFBLDJCQUFnQixFQUFDLEtBQUssRUFBRSxHQUFrQixFQUFFLEdBQW1CLEVBQUUsRUFBRTtJQUNwRixNQUFNLGlCQUFpQixHQUFzQixHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyw4QkFBaUIsQ0FBQyxDQUFDO0lBQ2xGLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0saUJBQWlCLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRixDQUFDLENBQUMsQ0FBQyJ9