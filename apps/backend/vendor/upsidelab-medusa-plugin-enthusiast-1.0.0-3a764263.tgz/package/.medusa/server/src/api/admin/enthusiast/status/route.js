"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = void 0;
const enthusiast_1 = require("../../../../modules/enthusiast");
const wrappers_1 = require("../../../../api/wrappers");
exports.GET = (0, wrappers_1.withErrorHandler)(async (req, res) => {
    const enthusiastService = req.scope.resolve(enthusiast_1.ENTHUSIAST_MODULE);
    await enthusiastService.isConnected();
    res.status(200).json({});
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2VudGh1c2lhc3Qvc3RhdHVzL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUNBLCtEQUFtRTtBQUVuRSx1REFBNEQ7QUFFL0MsUUFBQSxHQUFHLEdBQUcsSUFBQSwyQkFBZ0IsRUFBQyxLQUFLLEVBQUUsR0FBa0IsRUFBRSxHQUFtQixFQUFFLEVBQUU7SUFDcEYsTUFBTSxpQkFBaUIsR0FBc0IsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsOEJBQWlCLENBQUMsQ0FBQztJQUNsRixNQUFNLGlCQUFpQixDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ3RDLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDIn0=