"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Migration20251215080027 = void 0;
const migrations_1 = require("@mikro-orm/migrations");
class Migration20251215080027 extends migrations_1.Migration {
    async up() {
        this.addSql(`alter table if exists "enthusiast_dataset" drop constraint if exists "enthusiast_dataset_is_active_unique";`);
        this.addSql(`drop index if exists "IDX_enthusiast_dataset_is_used_unique";`);
        this.addSql(`alter table if exists "enthusiast_dataset" rename column "is_used" to "is_active";`);
        this.addSql(`CREATE UNIQUE INDEX IF NOT EXISTS "IDX_enthusiast_dataset_is_active_unique" ON "enthusiast_dataset" (is_active) WHERE is_active IS TRUE AND deleted_at IS NULL;`);
    }
    async down() {
        this.addSql(`drop index if exists "IDX_enthusiast_dataset_is_active_unique";`);
        this.addSql(`alter table if exists "enthusiast_dataset" rename column "is_active" to "is_used";`);
        this.addSql(`CREATE UNIQUE INDEX IF NOT EXISTS "IDX_enthusiast_dataset_is_used_unique" ON "enthusiast_dataset" (is_used) WHERE is_used IS TRUE AND deleted_at IS NULL;`);
    }
}
exports.Migration20251215080027 = Migration20251215080027;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTWlncmF0aW9uMjAyNTEyMTUwODAwMjcuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9lbnRodXNpYXN0L21pZ3JhdGlvbnMvTWlncmF0aW9uMjAyNTEyMTUwODAwMjcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsc0RBQWtEO0FBRWxELE1BQWEsdUJBQXdCLFNBQVEsc0JBQVM7SUFDM0MsS0FBSyxDQUFDLEVBQUU7UUFDZixJQUFJLENBQUMsTUFBTSxDQUNULDZHQUE2RyxDQUM5RyxDQUFDO1FBQ0YsSUFBSSxDQUFDLE1BQU0sQ0FBQywrREFBK0QsQ0FBQyxDQUFDO1FBRTdFLElBQUksQ0FBQyxNQUFNLENBQ1Qsb0ZBQW9GLENBQ3JGLENBQUM7UUFDRixJQUFJLENBQUMsTUFBTSxDQUNULGlLQUFpSyxDQUNsSyxDQUFDO0lBQ0osQ0FBQztJQUVRLEtBQUssQ0FBQyxJQUFJO1FBQ2pCLElBQUksQ0FBQyxNQUFNLENBQUMsaUVBQWlFLENBQUMsQ0FBQztRQUUvRSxJQUFJLENBQUMsTUFBTSxDQUNULG9GQUFvRixDQUNyRixDQUFDO1FBQ0YsSUFBSSxDQUFDLE1BQU0sQ0FDVCwySkFBMkosQ0FDNUosQ0FBQztJQUNKLENBQUM7Q0FDRjtBQXpCRCwwREF5QkMifQ==