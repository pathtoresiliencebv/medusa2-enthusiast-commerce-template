"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SingleColumnLayout = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
const SingleColumnLayout = ({ children }) => {
    return ((0, jsx_runtime_1.jsx)("div", { className: "flex flex-col gap-y-3", style: { height: `calc(100vh - 78px)` }, children: children }));
};
exports.SingleColumnLayout = SingleColumnLayout;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2luZ2xlLWNvbHVtbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9jb21wb25lbnRzL3VpL3NpbmdsZS1jb2x1bW4udHN4Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7QUFNTyxNQUFNLGtCQUFrQixHQUFHLENBQUMsRUFBRSxRQUFRLEVBQTJCLEVBQUUsRUFBRTtJQUMxRSxPQUFPLENBQ0wsZ0NBQUssU0FBUyxFQUFDLHVCQUF1QixFQUFDLEtBQUssRUFBRSxFQUFFLE1BQU0sRUFBRSxvQkFBb0IsRUFBRSxZQUMzRSxRQUFRLEdBQ0wsQ0FDUCxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBTlcsUUFBQSxrQkFBa0Isc0JBTTdCIn0=