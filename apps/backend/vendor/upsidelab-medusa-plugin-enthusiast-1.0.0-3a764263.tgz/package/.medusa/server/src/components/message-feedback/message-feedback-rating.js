"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageFeedbackRating = MessageFeedbackRating;
const jsx_runtime_1 = require("react/jsx-runtime");
const button_1 = require("../../components/ui/button");
const values = [
    { value: 1, label: "Poor" },
    { value: 2, label: "Fair" },
    { value: 3, label: "Good" },
    { value: 4, label: "Very Good" },
    { value: 5, label: "Excellent" },
];
function MessageFeedbackRating({ onRatingChange, rating, disabled, }) {
    const classNamesForButton = (value) => {
        if (value === rating) {
            return "border border-black";
        }
        return "";
    };
    return ((0, jsx_runtime_1.jsx)("div", { className: "flex space-x-2", children: values.map(({ value, label }) => ((0, jsx_runtime_1.jsx)(button_1.Button, { variant: "outline", disabled: disabled, type: "button", className: classNamesForButton(value), onClick: () => onRatingChange(value), children: label }, value))) }));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVzc2FnZS1mZWVkYmFjay1yYXRpbmcuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvY29tcG9uZW50cy9tZXNzYWdlLWZlZWRiYWNrL21lc3NhZ2UtZmVlZGJhY2stcmF0aW5nLnRzeCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQWdCQSxzREE0QkM7O0FBNUNELHVEQUFvRDtBQVFwRCxNQUFNLE1BQU0sR0FBRztJQUNiLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFO0lBQzNCLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFO0lBQzNCLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFO0lBQzNCLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFO0lBQ2hDLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFO0NBQ2pDLENBQUM7QUFFRixTQUFnQixxQkFBcUIsQ0FBQyxFQUNwQyxjQUFjLEVBQ2QsTUFBTSxFQUNOLFFBQVEsR0FDbUI7SUFDM0IsTUFBTSxtQkFBbUIsR0FBRyxDQUFDLEtBQWEsRUFBRSxFQUFFO1FBQzVDLElBQUksS0FBSyxLQUFLLE1BQU0sRUFBRSxDQUFDO1lBQ3JCLE9BQU8scUJBQXFCLENBQUM7UUFDL0IsQ0FBQztRQUNELE9BQU8sRUFBRSxDQUFDO0lBQ1osQ0FBQyxDQUFDO0lBRUYsT0FBTyxDQUNMLGdDQUFLLFNBQVMsRUFBQyxnQkFBZ0IsWUFDNUIsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUNoQyx1QkFBQyxlQUFNLElBQ0wsT0FBTyxFQUFDLFNBQVMsRUFFakIsUUFBUSxFQUFFLFFBQVEsRUFDbEIsSUFBSSxFQUFDLFFBQVEsRUFDYixTQUFTLEVBQUUsbUJBQW1CLENBQUMsS0FBSyxDQUFDLEVBQ3JDLE9BQU8sRUFBRSxHQUFHLEVBQUUsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLFlBRW5DLEtBQUssSUFORCxLQUFLLENBT0gsQ0FDVixDQUFDLEdBQ0UsQ0FDUCxDQUFDO0FBQ0osQ0FBQyJ9