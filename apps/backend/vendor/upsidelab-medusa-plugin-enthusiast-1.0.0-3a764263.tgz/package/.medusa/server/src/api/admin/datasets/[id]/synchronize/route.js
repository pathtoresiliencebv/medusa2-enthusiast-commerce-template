"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.POST = void 0;
const enthusiast_1 = require("../../../../../modules/enthusiast");
const wrappers_1 = require("../../../../wrappers");
exports.POST = (0, wrappers_1.withErrorHandler)(async (req, res) => {
    const { id } = req.params;
    const enthusiastService = req.scope.resolve(enthusiast_1.ENTHUSIAST_MODULE);
    await enthusiastService.synchronizeDatasets(id, req.scope);
    res.status(200).json({});
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL2RhdGFzZXRzL1tpZF0vc3luY2hyb25pemUvcm91dGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBRUEsa0VBQXNFO0FBQ3RFLG1EQUF3RDtBQUUzQyxRQUFBLElBQUksR0FBRyxJQUFBLDJCQUFnQixFQUFDLEtBQUssRUFBRSxHQUFrQixFQUFFLEdBQW1CLEVBQUUsRUFBRTtJQUNyRixNQUFNLEVBQUUsRUFBRSxFQUFFLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQztJQUMxQixNQUFNLGlCQUFpQixHQUFzQixHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyw4QkFBaUIsQ0FBQyxDQUFDO0lBQ2xGLE1BQU0saUJBQWlCLENBQUMsbUJBQW1CLENBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMzRCxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQyJ9