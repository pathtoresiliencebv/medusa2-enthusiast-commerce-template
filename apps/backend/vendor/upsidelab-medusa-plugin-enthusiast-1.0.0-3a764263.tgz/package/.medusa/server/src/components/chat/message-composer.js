"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageComposer = MessageComposer;
const jsx_runtime_1 = require("react/jsx-runtime");
const react_1 = require("react");
require("./message-composer.css");
const file_upload_1 = require("./file-upload");
const file_list_1 = require("./file-list");
const admin_client_1 = require("../../admin/lib/admin-client");
const utils_1 = require("../../admin/lib/utils");
const textarea_1 = require("../ui/textarea");
const button_1 = require("../ui/button");
const icons_1 = require("@medusajs/icons");
const lucide_react_1 = require("lucide-react");
const maxHeight = 300;
function MessageComposer({ onSubmit, isLoading, conversationLocked = false, conversationId, agentId, fileUploadEnabled, }) {
    const [input, setInput] = (0, react_1.useState)("");
    const [uploadedFiles, setUploadedFiles] = (0, react_1.useState)([]);
    const [showUploadArea, setShowUploadArea] = (0, react_1.useState)(false);
    const [uploadingFiles, setUploadingFiles] = (0, react_1.useState)(false);
    const [uploadError, setUploadError] = (0, react_1.useState)(null);
    const createdConversationIdRef = (0, react_1.useRef)(null);
    const inputRef = (0, react_1.useRef)(null);
    const inputLength = input.trim().length;
    (0, react_1.useEffect)(() => {
        const handleDragOver = (e) => {
            e.preventDefault();
            if (!fileUploadEnabled || isLoading || conversationLocked || showUploadArea) {
                return;
            }
            setShowUploadArea(true);
        };
        const handleDragEnd = () => {
            setShowUploadArea(false);
        };
        const handleDragLeave = (e) => {
            e.preventDefault();
            if (e.relatedTarget && e.relatedTarget !== document.documentElement) {
                return;
            }
            handleDragEnd();
        };
        document.body.addEventListener("dragover", handleDragOver);
        document.body.addEventListener("dragleave", handleDragLeave);
        document.body.addEventListener("dragend", handleDragEnd);
        window.addEventListener("blur", () => handleDragEnd);
        return () => {
            document.body.removeEventListener("dragover", handleDragOver);
            document.body.removeEventListener("dragleave", handleDragLeave);
            document.body.removeEventListener("dragend", handleDragEnd);
            window.removeEventListener("blur", handleDragEnd);
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    const resizeTextArea = (element) => {
        if (!element) {
            return;
        }
        element.style.height = "0px";
        element.style.height = `${Math.min(element.scrollHeight, maxHeight)}px`;
    };
    const uploadFile = async (file, conversationId) => {
        const uploadResponse = await admin_client_1.adminApiClient.conversations().uploadFile(conversationId, file);
        return uploadResponse.task_id;
    };
    const pollUploadStatus = async (taskId) => {
        const maxAttempts = 30;
        let attempts = 0;
        while (attempts < maxAttempts) {
            const statusData = await admin_client_1.adminApiClient.conversations().getFileUploadStatus(taskId);
            if (statusData.status === "SUCCESS") {
                return statusData.result.file_id;
            }
            else if (statusData.status === "FAILURE") {
                throw new Error(statusData.result?.error || "Upload failed");
            }
            await new Promise((resolve) => setTimeout(resolve, 1000));
            attempts++;
        }
        throw new Error("Upload timeout - please try again");
    };
    const resetComposer = () => {
        setInput("");
        setUploadedFiles([]);
        setShowUploadArea(false);
        setUploadError(null);
        createdConversationIdRef.current = null;
        setTimeout(() => {
            resizeTextArea(inputRef.current);
        });
    };
    const submitMessage = async () => {
        if (inputLength === 0)
            return;
        const allFilesReady = uploadedFiles.every((f) => f.uploaded && f.fileId);
        const hasUploadingFiles = uploadedFiles.some((f) => f.uploading);
        const hasErrors = uploadedFiles.some((f) => f.uploadError);
        if (uploadedFiles.length > 0 && !allFilesReady) {
            if (hasUploadingFiles) {
                setUploadError("Please wait for all files to finish uploading.");
            }
            else if (hasErrors) {
                setUploadError("Please fix upload errors before sending.");
            }
            return;
        }
        if (!uploadedFiles.length) {
            onSubmit({ text: input, files: [] }, createdConversationIdRef.current || undefined);
            resetComposer();
            return;
        }
        try {
            setUploadingFiles(true);
            const message = {
                text: input,
                files: uploadedFiles
                    .filter((f) => f.uploaded && f.fileId)
                    .map((f) => ({
                    id: f.fileId,
                    name: f.file.name,
                    type: f.file.name.includes(".") ? f.file.name.split(".").pop() : "",
                })),
            };
            onSubmit(message, createdConversationIdRef.current || undefined);
            resetComposer();
        }
        catch {
            setUploadError("Failed to send message. Please try again.");
        }
        finally {
            setUploadingFiles(false);
        }
    };
    const handleTextAreaInput = (event) => {
        setInput(event.target.value);
        resizeTextArea(event.target);
    };
    const handleTextAreaKeyDown = (event) => {
        if (event.shiftKey || event.key !== "Enter")
            return;
        event.preventDefault();
        void submitMessage();
    };
    const handleFilesChange = async (files) => {
        setUploadedFiles(files.map((f) => ({ ...f, uploading: true, uploadError: undefined })));
        let currentConversationId = conversationId || createdConversationIdRef.current;
        if (!currentConversationId && agentId) {
            currentConversationId = await admin_client_1.adminApiClient.conversations().createConversation(agentId);
            createdConversationIdRef.current = currentConversationId;
        }
        if (!currentConversationId) {
            throw new Error("No conversation ID available for file upload");
        }
        const uploadPromises = files.map(async (file) => {
            try {
                const taskId = await uploadFile(file.file, currentConversationId);
                setUploadedFiles((prev) => prev.map((f) => (f.id === file.id ? { ...f, taskId, uploading: true } : f)));
                const fileId = await pollUploadStatus(taskId);
                setUploadedFiles((prev) => prev.map((f) => f.id === file.id ? { ...f, uploaded: true, fileId, uploading: false } : f));
            }
            catch {
                setUploadedFiles((prev) => prev.map((f) => f.id === file.id ? { ...f, uploading: false, uploadError: "Upload failed" } : f));
            }
        });
        await Promise.all(uploadPromises);
    };
    const handleFileRemove = (fileId) => {
        setUploadedFiles((prev) => {
            const newFiles = prev.filter((f) => f.id !== fileId);
            if (newFiles.length === 0) {
                setShowUploadArea(false);
            }
            return newFiles;
        });
        setUploadError(null);
    };
    (0, react_1.useEffect)(() => {
        if (!isLoading) {
            inputRef.current?.focus();
        }
    }, [isLoading]);
    return ((0, jsx_runtime_1.jsxs)("div", { className: "space-y-3", children: [uploadError && ((0, jsx_runtime_1.jsx)("div", { className: "bg-red-50 border border-red-200 rounded-lg p-3", children: (0, jsx_runtime_1.jsx)("div", { className: "text-sm text-red-600", children: uploadError }) })), (0, jsx_runtime_1.jsx)(file_list_1.FileList, { uploadedFiles: uploadedFiles, handleFileRemove: handleFileRemove, disabled: isLoading || uploadingFiles || conversationLocked }), (0, jsx_runtime_1.jsx)("form", { onSubmit: (event) => {
                    event.preventDefault();
                    void submitMessage();
                }, className: "flex w-full items-center space-x-2 relative", children: (0, jsx_runtime_1.jsxs)("div", { className: (0, utils_1.cn)("relative flex-1 rounded-md border bg-background", showUploadArea && "border-dashed"), children: [fileUploadEnabled && ((0, jsx_runtime_1.jsx)(file_upload_1.FileUpload, { onFilesChange: (files) => {
                                void handleFilesChange(files);
                            }, uploadedFiles: uploadedFiles, disabled: isLoading || uploadingFiles || conversationLocked, onClose: () => setShowUploadArea(false), showUploadArea: showUploadArea, onUploadError: setUploadError })), (0, jsx_runtime_1.jsx)(textarea_1.Textarea, { id: "message", ref: inputRef, placeholder: conversationLocked ? "This agent is no longer available." : "Type your message...", className: "w-full resize-none border-0 focus-visible:ring-0 focus-visible:outline-none shadow-none pt-3", autoComplete: "off", value: input, onChange: handleTextAreaInput, onKeyDown: handleTextAreaKeyDown, disabled: isLoading || uploadingFiles || conversationLocked }), (0, jsx_runtime_1.jsx)("div", { className: "flex", children: (0, jsx_runtime_1.jsxs)(button_1.Button, { type: "submit", size: "icon", className: "ml-auto mr-2 mb-2", disabled: isLoading ||
                                    uploadingFiles ||
                                    inputLength === 0 ||
                                    conversationLocked ||
                                    uploadedFiles.some((f) => f.uploading || f.uploadError), children: [isLoading || uploadingFiles ? ((0, jsx_runtime_1.jsx)(icons_1.Loader, { className: "h-4 w-4 animate-spin text-muted-foreground" })) : ((0, jsx_runtime_1.jsx)(lucide_react_1.Send, { className: "h-4 w-4" })), (0, jsx_runtime_1.jsx)("span", { className: "sr-only", children: "Send" })] }) })] }) })] }));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVzc2FnZS1jb21wb3Nlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9jb21wb25lbnRzL2NoYXQvbWVzc2FnZS1jb21wb3Nlci50c3giXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFvQ0EsMENBbVNDOztBQXZVRCxpQ0FBZ0Y7QUFDaEYsa0NBQWdDO0FBQ2hDLCtDQUF5RDtBQUN6RCwyQ0FBdUM7QUFHdkMsK0RBQThEO0FBQzlELGlEQUEyQztBQUMzQyw2Q0FBMEM7QUFDMUMseUNBQXNDO0FBQ3RDLDJDQUF5QztBQUN6QywrQ0FBb0M7QUF1QnBDLE1BQU0sU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUV0QixTQUFnQixlQUFlLENBQUMsRUFDOUIsUUFBUSxFQUNSLFNBQVMsRUFDVCxrQkFBa0IsR0FBRyxLQUFLLEVBQzFCLGNBQWMsRUFDZCxPQUFPLEVBQ1AsaUJBQWlCLEdBQ0k7SUFDckIsTUFBTSxDQUFDLEtBQUssRUFBRSxRQUFRLENBQUMsR0FBRyxJQUFBLGdCQUFRLEVBQUMsRUFBRSxDQUFDLENBQUM7SUFDdkMsTUFBTSxDQUFDLGFBQWEsRUFBRSxnQkFBZ0IsQ0FBQyxHQUFHLElBQUEsZ0JBQVEsRUFBaUIsRUFBRSxDQUFDLENBQUM7SUFDdkUsTUFBTSxDQUFDLGNBQWMsRUFBRSxpQkFBaUIsQ0FBQyxHQUFHLElBQUEsZ0JBQVEsRUFBQyxLQUFLLENBQUMsQ0FBQztJQUM1RCxNQUFNLENBQUMsY0FBYyxFQUFFLGlCQUFpQixDQUFDLEdBQUcsSUFBQSxnQkFBUSxFQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzVELE1BQU0sQ0FBQyxXQUFXLEVBQUUsY0FBYyxDQUFDLEdBQUcsSUFBQSxnQkFBUSxFQUFnQixJQUFJLENBQUMsQ0FBQztJQUNwRSxNQUFNLHdCQUF3QixHQUFHLElBQUEsY0FBTSxFQUFnQixJQUFJLENBQUMsQ0FBQztJQUM3RCxNQUFNLFFBQVEsR0FBRyxJQUFBLGNBQU0sRUFBNkIsSUFBSSxDQUFDLENBQUM7SUFDMUQsTUFBTSxXQUFXLEdBQUcsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLE1BQU0sQ0FBQztJQUV4QyxJQUFBLGlCQUFTLEVBQUMsR0FBRyxFQUFFO1FBQ2IsTUFBTSxjQUFjLEdBQUcsQ0FBQyxDQUFZLEVBQUUsRUFBRTtZQUN0QyxDQUFDLENBQUMsY0FBYyxFQUFFLENBQUM7WUFFbkIsSUFBSSxDQUFDLGlCQUFpQixJQUFJLFNBQVMsSUFBSSxrQkFBa0IsSUFBSSxjQUFjLEVBQUUsQ0FBQztnQkFDNUUsT0FBTztZQUNULENBQUM7WUFFRCxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMxQixDQUFDLENBQUM7UUFFRixNQUFNLGFBQWEsR0FBRyxHQUFHLEVBQUU7WUFDekIsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDM0IsQ0FBQyxDQUFDO1FBRUYsTUFBTSxlQUFlLEdBQUcsQ0FBQyxDQUFZLEVBQUUsRUFBRTtZQUN2QyxDQUFDLENBQUMsY0FBYyxFQUFFLENBQUM7WUFFbkIsSUFBSSxDQUFDLENBQUMsYUFBYSxJQUFJLENBQUMsQ0FBQyxhQUFhLEtBQUssUUFBUSxDQUFDLGVBQWUsRUFBRSxDQUFDO2dCQUNwRSxPQUFPO1lBQ1QsQ0FBQztZQUVELGFBQWEsRUFBRSxDQUFDO1FBQ2xCLENBQUMsQ0FBQztRQUVGLFFBQVEsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxFQUFFLGNBQWMsQ0FBQyxDQUFDO1FBQzNELFFBQVEsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxFQUFFLGVBQWUsQ0FBQyxDQUFDO1FBQzdELFFBQVEsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBQ3pELE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsR0FBRyxFQUFFLENBQUMsYUFBYSxDQUFDLENBQUM7UUFFckQsT0FBTyxHQUFHLEVBQUU7WUFDVixRQUFRLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFVBQVUsRUFBRSxjQUFjLENBQUMsQ0FBQztZQUM5RCxRQUFRLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFdBQVcsRUFBRSxlQUFlLENBQUMsQ0FBQztZQUNoRSxRQUFRLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsRUFBRSxhQUFhLENBQUMsQ0FBQztZQUM1RCxNQUFNLENBQUMsbUJBQW1CLENBQUMsTUFBTSxFQUFFLGFBQWEsQ0FBQyxDQUFDO1FBQ3BELENBQUMsQ0FBQztRQUNGLHVEQUF1RDtJQUN6RCxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFFUCxNQUFNLGNBQWMsR0FBRyxDQUFDLE9BQTRCLEVBQUUsRUFBRTtRQUN0RCxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDYixPQUFPO1FBQ1QsQ0FBQztRQUVELE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztRQUM3QixPQUFPLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFlBQVksRUFBRSxTQUFTLENBQUMsSUFBSSxDQUFDO0lBQzFFLENBQUMsQ0FBQztJQUVGLE1BQU0sVUFBVSxHQUFHLEtBQUssRUFBRSxJQUFVLEVBQUUsY0FBc0IsRUFBbUIsRUFBRTtRQUMvRSxNQUFNLGNBQWMsR0FBRyxNQUFNLDZCQUFjLENBQUMsYUFBYSxFQUFFLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUM3RixPQUFPLGNBQWMsQ0FBQyxPQUFPLENBQUM7SUFDaEMsQ0FBQyxDQUFDO0lBRUYsTUFBTSxnQkFBZ0IsR0FBRyxLQUFLLEVBQUUsTUFBYyxFQUFtQixFQUFFO1FBQ2pFLE1BQU0sV0FBVyxHQUFHLEVBQUUsQ0FBQztRQUN2QixJQUFJLFFBQVEsR0FBRyxDQUFDLENBQUM7UUFFakIsT0FBTyxRQUFRLEdBQUcsV0FBVyxFQUFFLENBQUM7WUFDOUIsTUFBTSxVQUFVLEdBQUcsTUFBTSw2QkFBYyxDQUFDLGFBQWEsRUFBRSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRXBGLElBQUksVUFBVSxDQUFDLE1BQU0sS0FBSyxTQUFTLEVBQUUsQ0FBQztnQkFDcEMsT0FBTyxVQUFVLENBQUMsTUFBTyxDQUFDLE9BQVEsQ0FBQztZQUNyQyxDQUFDO2lCQUFNLElBQUksVUFBVSxDQUFDLE1BQU0sS0FBSyxTQUFTLEVBQUUsQ0FBQztnQkFDM0MsTUFBTSxJQUFJLEtBQUssQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLEtBQUssSUFBSSxlQUFlLENBQUMsQ0FBQztZQUMvRCxDQUFDO1lBRUQsTUFBTSxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQzFELFFBQVEsRUFBRSxDQUFDO1FBQ2IsQ0FBQztRQUVELE1BQU0sSUFBSSxLQUFLLENBQUMsbUNBQW1DLENBQUMsQ0FBQztJQUN2RCxDQUFDLENBQUM7SUFFRixNQUFNLGFBQWEsR0FBRyxHQUFHLEVBQUU7UUFDekIsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ2IsZ0JBQWdCLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDckIsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDekIsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3JCLHdCQUF3QixDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFFeEMsVUFBVSxDQUFDLEdBQUcsRUFBRTtZQUNkLGNBQWMsQ0FBQyxRQUFRLENBQUMsT0FBUSxDQUFDLENBQUM7UUFDcEMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUM7SUFDRixNQUFNLGFBQWEsR0FBRyxLQUFLLElBQUksRUFBRTtRQUMvQixJQUFJLFdBQVcsS0FBSyxDQUFDO1lBQUUsT0FBTztRQUU5QixNQUFNLGFBQWEsR0FBRyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN6RSxNQUFNLGlCQUFpQixHQUFHLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNqRSxNQUFNLFNBQVMsR0FBRyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFM0QsSUFBSSxhQUFhLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQy9DLElBQUksaUJBQWlCLEVBQUUsQ0FBQztnQkFDdEIsY0FBYyxDQUFDLGdEQUFnRCxDQUFDLENBQUM7WUFDbkUsQ0FBQztpQkFBTSxJQUFJLFNBQVMsRUFBRSxDQUFDO2dCQUNyQixjQUFjLENBQUMsMENBQTBDLENBQUMsQ0FBQztZQUM3RCxDQUFDO1lBQ0QsT0FBTztRQUNULENBQUM7UUFFRCxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQzFCLFFBQVEsQ0FBQyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLEVBQUUsRUFBRSxFQUFFLHdCQUF3QixDQUFDLE9BQU8sSUFBSSxTQUFTLENBQUMsQ0FBQztZQUNwRixhQUFhLEVBQUUsQ0FBQztZQUNoQixPQUFPO1FBQ1QsQ0FBQztRQUVELElBQUksQ0FBQztZQUNILGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDO1lBRXhCLE1BQU0sT0FBTyxHQUFHO2dCQUNkLElBQUksRUFBRSxLQUFLO2dCQUNYLEtBQUssRUFBRSxhQUFhO3FCQUNqQixNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQztxQkFDckMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO29CQUNYLEVBQUUsRUFBRSxDQUFDLENBQUMsTUFBTztvQkFDYixJQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJO29CQUNqQixJQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUU7aUJBQ3BFLENBQUMsQ0FBQzthQUNLLENBQUM7WUFFYixRQUFRLENBQUMsT0FBTyxFQUFFLHdCQUF3QixDQUFDLE9BQU8sSUFBSSxTQUFTLENBQUMsQ0FBQztZQUNqRSxhQUFhLEVBQUUsQ0FBQztRQUNsQixDQUFDO1FBQUMsTUFBTSxDQUFDO1lBQ1AsY0FBYyxDQUFDLDJDQUEyQyxDQUFDLENBQUM7UUFDOUQsQ0FBQztnQkFBUyxDQUFDO1lBQ1QsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDM0IsQ0FBQztJQUNILENBQUMsQ0FBQztJQUVGLE1BQU0sbUJBQW1CLEdBQUcsQ0FBQyxLQUF1QyxFQUFFLEVBQUU7UUFDdEUsUUFBUSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDN0IsY0FBYyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztJQUMvQixDQUFDLENBQUM7SUFFRixNQUFNLHFCQUFxQixHQUFHLENBQUMsS0FBeUMsRUFBRSxFQUFFO1FBQzFFLElBQUksS0FBSyxDQUFDLFFBQVEsSUFBSSxLQUFLLENBQUMsR0FBRyxLQUFLLE9BQU87WUFBRSxPQUFPO1FBRXBELEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN2QixLQUFLLGFBQWEsRUFBRSxDQUFDO0lBQ3ZCLENBQUMsQ0FBQztJQUVGLE1BQU0saUJBQWlCLEdBQUcsS0FBSyxFQUFFLEtBQXFCLEVBQUUsRUFBRTtRQUN4RCxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDeEYsSUFBSSxxQkFBcUIsR0FBRyxjQUFjLElBQUksd0JBQXdCLENBQUMsT0FBTyxDQUFDO1FBRS9FLElBQUksQ0FBQyxxQkFBcUIsSUFBSSxPQUFPLEVBQUUsQ0FBQztZQUN0QyxxQkFBcUIsR0FBRyxNQUFNLDZCQUFjLENBQUMsYUFBYSxFQUFFLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDekYsd0JBQXdCLENBQUMsT0FBTyxHQUFHLHFCQUFxQixDQUFDO1FBQzNELENBQUM7UUFFRCxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztZQUMzQixNQUFNLElBQUksS0FBSyxDQUFDLDhDQUE4QyxDQUFDLENBQUM7UUFDbEUsQ0FBQztRQUNELE1BQU0sY0FBYyxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLElBQUksRUFBRSxFQUFFO1lBQzlDLElBQUksQ0FBQztnQkFDSCxNQUFNLE1BQU0sR0FBRyxNQUFNLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLHFCQUFxQixDQUFDLENBQUM7Z0JBRWxFLGdCQUFnQixDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FDeEIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FDNUUsQ0FBQztnQkFFRixNQUFNLE1BQU0sR0FBRyxNQUFNLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUU5QyxnQkFBZ0IsQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFLENBQ3hCLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUNiLENBQUMsQ0FBQyxFQUFFLEtBQUssSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FDMUUsQ0FDRixDQUFDO1lBQ0osQ0FBQztZQUFDLE1BQU0sQ0FBQztnQkFDUCxnQkFBZ0IsQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFLENBQ3hCLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUNiLENBQUMsQ0FBQyxFQUFFLEtBQUssSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxlQUFlLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUNoRixDQUNGLENBQUM7WUFDSixDQUFDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7UUFFSCxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDcEMsQ0FBQyxDQUFDO0lBRUYsTUFBTSxnQkFBZ0IsR0FBcUIsQ0FBQyxNQUFNLEVBQUUsRUFBRTtRQUNwRCxnQkFBZ0IsQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFO1lBQ3hCLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssTUFBTSxDQUFDLENBQUM7WUFDckQsSUFBSSxRQUFRLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUMxQixpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMzQixDQUFDO1lBQ0QsT0FBTyxRQUFRLENBQUM7UUFDbEIsQ0FBQyxDQUFDLENBQUM7UUFDSCxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDdkIsQ0FBQyxDQUFDO0lBRUYsSUFBQSxpQkFBUyxFQUFDLEdBQUcsRUFBRTtRQUNiLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUNmLFFBQVEsQ0FBQyxPQUFPLEVBQUUsS0FBSyxFQUFFLENBQUM7UUFDNUIsQ0FBQztJQUNILENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7SUFFaEIsT0FBTyxDQUNMLGlDQUFLLFNBQVMsRUFBQyxXQUFXLGFBQ3ZCLFdBQVcsSUFBSSxDQUNkLGdDQUFLLFNBQVMsRUFBQyxnREFBZ0QsWUFDN0QsZ0NBQUssU0FBUyxFQUFDLHNCQUFzQixZQUFFLFdBQVcsR0FBTyxHQUNyRCxDQUNQLEVBRUQsdUJBQUMsb0JBQVEsSUFDUCxhQUFhLEVBQUUsYUFBYSxFQUM1QixnQkFBZ0IsRUFBRSxnQkFBZ0IsRUFDbEMsUUFBUSxFQUFFLFNBQVMsSUFBSSxjQUFjLElBQUksa0JBQWtCLEdBQzNELEVBRUYsaUNBQ0UsUUFBUSxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUU7b0JBQ2xCLEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQztvQkFDdkIsS0FBSyxhQUFhLEVBQUUsQ0FBQztnQkFDdkIsQ0FBQyxFQUNELFNBQVMsRUFBQyw2Q0FBNkMsWUFFdkQsaUNBQ0UsU0FBUyxFQUFFLElBQUEsVUFBRSxFQUNYLGlEQUFpRCxFQUNqRCxjQUFjLElBQUksZUFBZSxDQUNsQyxhQUVBLGlCQUFpQixJQUFJLENBQ3BCLHVCQUFDLHdCQUFVLElBQ1QsYUFBYSxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUU7Z0NBQ3ZCLEtBQUssaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUM7NEJBQ2hDLENBQUMsRUFDRCxhQUFhLEVBQUUsYUFBYSxFQUM1QixRQUFRLEVBQUUsU0FBUyxJQUFJLGNBQWMsSUFBSSxrQkFBa0IsRUFDM0QsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxFQUN2QyxjQUFjLEVBQUUsY0FBYyxFQUM5QixhQUFhLEVBQUUsY0FBYyxHQUM3QixDQUNILEVBQ0QsdUJBQUMsbUJBQVEsSUFDUCxFQUFFLEVBQUMsU0FBUyxFQUNaLEdBQUcsRUFBRSxRQUFRLEVBQ2IsV0FBVyxFQUNULGtCQUFrQixDQUFDLENBQUMsQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDLENBQUMsc0JBQXNCLEVBRXBGLFNBQVMsRUFBQyw4RkFBOEYsRUFDeEcsWUFBWSxFQUFDLEtBQUssRUFDbEIsS0FBSyxFQUFFLEtBQUssRUFDWixRQUFRLEVBQUUsbUJBQW1CLEVBQzdCLFNBQVMsRUFBRSxxQkFBcUIsRUFDaEMsUUFBUSxFQUFFLFNBQVMsSUFBSSxjQUFjLElBQUksa0JBQWtCLEdBQzNELEVBQ0YsZ0NBQUssU0FBUyxFQUFDLE1BQU0sWUFDbkIsd0JBQUMsZUFBTSxJQUNMLElBQUksRUFBQyxRQUFRLEVBQ2IsSUFBSSxFQUFDLE1BQU0sRUFDWCxTQUFTLEVBQUMsbUJBQW1CLEVBQzdCLFFBQVEsRUFDTixTQUFTO29DQUNULGNBQWM7b0NBQ2QsV0FBVyxLQUFLLENBQUM7b0NBQ2pCLGtCQUFrQjtvQ0FDbEIsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsSUFBSSxDQUFDLENBQUMsV0FBVyxDQUFDLGFBR3hELFNBQVMsSUFBSSxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQzdCLHVCQUFDLGNBQU0sSUFBQyxTQUFTLEVBQUMsNENBQTRDLEdBQUcsQ0FDbEUsQ0FBQyxDQUFDLENBQUMsQ0FDRix1QkFBQyxtQkFBSSxJQUFDLFNBQVMsRUFBQyxTQUFTLEdBQUcsQ0FDN0IsRUFDRCxpQ0FBTSxTQUFTLEVBQUMsU0FBUyxxQkFBWSxJQUM5QixHQUNMLElBQ0YsR0FDRCxJQUNILENBQ1AsQ0FBQztBQUNKLENBQUMifQ==