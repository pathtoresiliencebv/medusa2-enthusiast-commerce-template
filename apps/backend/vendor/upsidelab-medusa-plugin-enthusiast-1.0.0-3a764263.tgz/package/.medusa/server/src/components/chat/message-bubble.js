"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageBubble = MessageBubble;
const jsx_runtime_1 = require("react/jsx-runtime");
const react_1 = require("react");
const dompurify_1 = __importDefault(require("dompurify"));
const base_bubble_1 = require("../../components/chat/base-bubble");
const feedback_button_1 = require("../../components/chat/feedback-button");
const copy_to_clipboard_button_1 = require("../../components/chat/copy-to-clipboard-button");
const message_feedback_form_1 = require("../../components/message-feedback/message-feedback-form");
function MessageBubble({ text, variant, questionId, inMessageGroup }) {
    const [sanitizedHtml, setSanitizedHtml] = (0, react_1.useState)("");
    const [isFeedbackOpen, setIsFeedbackOpen] = (0, react_1.useState)(false);
    (0, react_1.useEffect)(() => {
        const processText = async () => {
            const { marked } = await import("marked");
            const rawHtml = await marked(text);
            const cleanHtml = dompurify_1.default.sanitize(rawHtml);
            setSanitizedHtml(cleanHtml);
        };
        void processText();
    }, [text]);
    const shouldShowActionButtons = variant === "secondary" && questionId !== null && text;
    const handleFeedbackClick = () => {
        setIsFeedbackOpen((prev) => !prev);
    };
    return ((0, jsx_runtime_1.jsxs)(base_bubble_1.BaseBubble, { variant: variant, hasBackground: true, inMessageGroup: inMessageGroup, children: [text && (0, jsx_runtime_1.jsx)("div", { className: variant, dangerouslySetInnerHTML: { __html: sanitizedHtml } }), shouldShowActionButtons && ((0, jsx_runtime_1.jsxs)("div", { className: "mt-4 flex items-center", children: [(0, jsx_runtime_1.jsx)(feedback_button_1.FeedbackButton, { isOpen: isFeedbackOpen, onClick: handleFeedbackClick }), (0, jsx_runtime_1.jsx)(copy_to_clipboard_button_1.CopyToClipboardButton, { message: text, variant: "ghost" })] })), isFeedbackOpen && ((0, jsx_runtime_1.jsx)("div", { className: "feedback-form-modal mx-4", children: (0, jsx_runtime_1.jsx)(message_feedback_form_1.MessageFeedbackForm, { messageId: questionId }) }))] }));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVzc2FnZS1idWJibGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvY29tcG9uZW50cy9jaGF0L21lc3NhZ2UtYnViYmxlLnRzeCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQWNBLHNDQXVDQzs7QUFyREQsaUNBQTRDO0FBQzVDLDBEQUFrQztBQUNsQyxtRUFBK0Q7QUFDL0QsMkVBQXVFO0FBQ3ZFLDZGQUF1RjtBQUN2RixtR0FBOEY7QUFTOUYsU0FBZ0IsYUFBYSxDQUFDLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUUsY0FBYyxFQUFzQjtJQUM3RixNQUFNLENBQUMsYUFBYSxFQUFFLGdCQUFnQixDQUFDLEdBQUcsSUFBQSxnQkFBUSxFQUFTLEVBQUUsQ0FBQyxDQUFDO0lBQy9ELE1BQU0sQ0FBQyxjQUFjLEVBQUUsaUJBQWlCLENBQUMsR0FBRyxJQUFBLGdCQUFRLEVBQUMsS0FBSyxDQUFDLENBQUM7SUFFNUQsSUFBQSxpQkFBUyxFQUFDLEdBQUcsRUFBRTtRQUNiLE1BQU0sV0FBVyxHQUFHLEtBQUssSUFBSSxFQUFFO1lBQzdCLE1BQU0sRUFBRSxNQUFNLEVBQUUsR0FBRyxNQUFNLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUMxQyxNQUFNLE9BQU8sR0FBRyxNQUFNLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNuQyxNQUFNLFNBQVMsR0FBRyxtQkFBUyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUM5QyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM5QixDQUFDLENBQUM7UUFFRixLQUFLLFdBQVcsRUFBRSxDQUFDO0lBQ3JCLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFFWCxNQUFNLHVCQUF1QixHQUFHLE9BQU8sS0FBSyxXQUFXLElBQUksVUFBVSxLQUFLLElBQUksSUFBSSxJQUFJLENBQUM7SUFFdkYsTUFBTSxtQkFBbUIsR0FBRyxHQUFHLEVBQUU7UUFDL0IsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDckMsQ0FBQyxDQUFDO0lBRUYsT0FBTyxDQUNMLHdCQUFDLHdCQUFVLElBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxhQUFhLEVBQUUsSUFBSSxFQUFFLGNBQWMsRUFBRSxjQUFjLGFBQzlFLElBQUksSUFBSSxnQ0FBSyxTQUFTLEVBQUUsT0FBTyxFQUFFLHVCQUF1QixFQUFFLEVBQUUsTUFBTSxFQUFFLGFBQWEsRUFBRSxHQUFJLEVBRXZGLHVCQUF1QixJQUFJLENBQzFCLGlDQUFLLFNBQVMsRUFBQyx3QkFBd0IsYUFDckMsdUJBQUMsZ0NBQWMsSUFBQyxNQUFNLEVBQUUsY0FBYyxFQUFFLE9BQU8sRUFBRSxtQkFBbUIsR0FBSSxFQUN4RSx1QkFBQyxnREFBcUIsSUFBQyxPQUFPLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBQyxPQUFPLEdBQUcsSUFDcEQsQ0FDUCxFQUVBLGNBQWMsSUFBSSxDQUNqQixnQ0FBSyxTQUFTLEVBQUMsMEJBQTBCLFlBQ3ZDLHVCQUFDLDJDQUFtQixJQUFDLFNBQVMsRUFBRSxVQUFVLEdBQUksR0FDMUMsQ0FDUCxJQUNVLENBQ2QsQ0FBQztBQUNKLENBQUMifQ==