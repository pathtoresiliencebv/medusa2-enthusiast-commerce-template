"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageError = MessageError;
const jsx_runtime_1 = require("react/jsx-runtime");
function MessageError({ text }) {
    return (0, jsx_runtime_1.jsx)("div", { className: "text-red-600 text-center", children: text });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVzc2FnZS1lcnJvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9jb21wb25lbnRzL2NoYXQvbWVzc2FnZS1lcnJvci50c3giXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFJQSxvQ0FFQzs7QUFGRCxTQUFnQixZQUFZLENBQUMsRUFBRSxJQUFJLEVBQXFCO0lBQ3RELE9BQU8sZ0NBQUssU0FBUyxFQUFDLDBCQUEwQixZQUFFLElBQUksR0FBTyxDQUFDO0FBQ2hFLENBQUMifQ==