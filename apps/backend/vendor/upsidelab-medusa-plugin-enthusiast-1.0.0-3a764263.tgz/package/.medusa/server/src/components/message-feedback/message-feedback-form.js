"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageFeedbackForm = MessageFeedbackForm;
const jsx_runtime_1 = require("react/jsx-runtime");
const button_1 = require("../../components/ui/button");
const label_1 = require("../../components/ui/label");
const textarea_1 = require("../../components/ui/textarea");
const react_1 = require("react");
const alert_1 = require("../../components/ui/alert");
const message_feedback_rating_1 = require("../../components/message-feedback/message-feedback-rating");
const admin_client_1 = require("../../admin/lib/admin-client");
const utils_1 = require("../../admin/lib/utils");
const spinner_1 = require("../../components/utils/spinner");
function MessageFeedbackForm({ messageId }, { className, ...props }) {
    const [isLoading, setIsLoading] = (0, react_1.useState)(false);
    const [isError, setIsError] = (0, react_1.useState)(false);
    const [rating, setRating] = (0, react_1.useState)(null);
    const [feedback, setFeedback] = (0, react_1.useState)("");
    const [isSubmitted, setIsSubmitted] = (0, react_1.useState)(false);
    async function onSubmit(event) {
        event.preventDefault();
        setIsLoading(true);
        const feedbackData = {
            rating: rating,
            feedback: feedback,
        };
        try {
            await admin_client_1.adminApiClient.conversations().updateMessageFeedback(messageId, feedbackData);
            setIsSubmitted(true);
        }
        catch {
            setIsError(true);
        }
        finally {
            setIsLoading(false);
        }
    }
    return ((0, jsx_runtime_1.jsx)("div", { className: (0, utils_1.cn)("grid gap-6", className), ...props, children: (0, jsx_runtime_1.jsx)("form", { onSubmit: (e) => {
                void onSubmit(e);
            }, children: (0, jsx_runtime_1.jsxs)("div", { className: "grid gap-4", children: [(0, jsx_runtime_1.jsxs)("div", { className: "grid gap-1", children: [isError && ((0, jsx_runtime_1.jsxs)(alert_1.Alert, { variant: "destructive", children: [(0, jsx_runtime_1.jsx)(alert_1.AlertTitle, { children: "There was an error submitting your feedback." }), (0, jsx_runtime_1.jsx)(alert_1.AlertDescription, { children: "Please contact user support." })] })), (0, jsx_runtime_1.jsx)(label_1.Label, { className: "sr-only", htmlFor: "rating", children: "Rating" }), (0, jsx_runtime_1.jsx)(message_feedback_rating_1.MessageFeedbackRating, { disabled: isSubmitted, rating: rating, onRatingChange: setRating })] }), (0, jsx_runtime_1.jsxs)("div", { className: "grid gap-2", children: [(0, jsx_runtime_1.jsx)(label_1.Label, { htmlFor: "feedback", children: "Your Feedback" }), (0, jsx_runtime_1.jsx)(textarea_1.Textarea, { disabled: isSubmitted, onChange: (event) => setFeedback(event.target.value), className: "bg-white", placeholder: "Type your feedback here." })] }), (0, jsx_runtime_1.jsx)(button_1.Button, { disabled: isLoading || isSubmitted, type: "submit", children: isSubmitted ? ((0, jsx_runtime_1.jsx)(jsx_runtime_1.Fragment, { children: "Thank you for your feedback!" })) : ((0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [isLoading && (0, jsx_runtime_1.jsx)(spinner_1.LoadingSpinner, {}), "Submit Feedback"] })) })] }) }) }));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVzc2FnZS1mZWVkYmFjay1mb3JtLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL2NvbXBvbmVudHMvbWVzc2FnZS1mZWVkYmFjay9tZXNzYWdlLWZlZWRiYWNrLWZvcm0udHN4Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBY0Esa0RBK0VDOztBQTdGRCx1REFBb0Q7QUFDcEQscURBQWtEO0FBQ2xELDJEQUF3RDtBQUN4RCxpQ0FBaUU7QUFDakUscURBQWdGO0FBQ2hGLHVHQUFrRztBQUNsRywrREFBOEQ7QUFDOUQsaURBQTJDO0FBQzNDLDREQUFnRTtBQU1oRSxTQUFnQixtQkFBbUIsQ0FDakMsRUFBRSxTQUFTLEVBQTRCLEVBQ3ZDLEVBQUUsU0FBUyxFQUFFLEdBQUcsS0FBSyxFQUFrQztJQUV2RCxNQUFNLENBQUMsU0FBUyxFQUFFLFlBQVksQ0FBQyxHQUFHLElBQUEsZ0JBQVEsRUFBQyxLQUFLLENBQUMsQ0FBQztJQUNsRCxNQUFNLENBQUMsT0FBTyxFQUFFLFVBQVUsQ0FBQyxHQUFHLElBQUEsZ0JBQVEsRUFBQyxLQUFLLENBQUMsQ0FBQztJQUM5QyxNQUFNLENBQUMsTUFBTSxFQUFFLFNBQVMsQ0FBQyxHQUFHLElBQUEsZ0JBQVEsRUFBZ0IsSUFBSSxDQUFDLENBQUM7SUFDMUQsTUFBTSxDQUFDLFFBQVEsRUFBRSxXQUFXLENBQUMsR0FBRyxJQUFBLGdCQUFRLEVBQVMsRUFBRSxDQUFDLENBQUM7SUFDckQsTUFBTSxDQUFDLFdBQVcsRUFBRSxjQUFjLENBQUMsR0FBRyxJQUFBLGdCQUFRLEVBQUMsS0FBSyxDQUFDLENBQUM7SUFFdEQsS0FBSyxVQUFVLFFBQVEsQ0FBQyxLQUFxQjtRQUMzQyxLQUFLLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDdkIsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRW5CLE1BQU0sWUFBWSxHQUFHO1lBQ25CLE1BQU0sRUFBRSxNQUFNO1lBQ2QsUUFBUSxFQUFFLFFBQVE7U0FDbkIsQ0FBQztRQUVGLElBQUksQ0FBQztZQUNILE1BQU0sNkJBQWMsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxxQkFBcUIsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUM7WUFDcEYsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3ZCLENBQUM7UUFBQyxNQUFNLENBQUM7WUFDUCxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDbkIsQ0FBQztnQkFBUyxDQUFDO1lBQ1QsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3RCLENBQUM7SUFDSCxDQUFDO0lBRUQsT0FBTyxDQUNMLGdDQUFLLFNBQVMsRUFBRSxJQUFBLFVBQUUsRUFBQyxZQUFZLEVBQUUsU0FBUyxDQUFDLEtBQU0sS0FBSyxZQUNwRCxpQ0FDRSxRQUFRLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRTtnQkFDZCxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNuQixDQUFDLFlBRUQsaUNBQUssU0FBUyxFQUFDLFlBQVksYUFDekIsaUNBQUssU0FBUyxFQUFDLFlBQVksYUFDeEIsT0FBTyxJQUFJLENBQ1Ysd0JBQUMsYUFBSyxJQUFDLE9BQU8sRUFBQyxhQUFhLGFBQzFCLHVCQUFDLGtCQUFVLCtEQUEwRCxFQUNyRSx1QkFBQyx3QkFBZ0IsK0NBQWdELElBQzNELENBQ1QsRUFFRCx1QkFBQyxhQUFLLElBQUMsU0FBUyxFQUFDLFNBQVMsRUFBQyxPQUFPLEVBQUMsUUFBUSx1QkFFbkMsRUFDUix1QkFBQywrQ0FBcUIsSUFDcEIsUUFBUSxFQUFFLFdBQVcsRUFDckIsTUFBTSxFQUFFLE1BQU0sRUFDZCxjQUFjLEVBQUUsU0FBUyxHQUN6QixJQUNFLEVBRU4saUNBQUssU0FBUyxFQUFDLFlBQVksYUFDekIsdUJBQUMsYUFBSyxJQUFDLE9BQU8sRUFBQyxVQUFVLDhCQUFzQixFQUMvQyx1QkFBQyxtQkFBUSxJQUNQLFFBQVEsRUFBRSxXQUFXLEVBQ3JCLFFBQVEsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQ3BELFNBQVMsRUFBQyxVQUFVLEVBQ3BCLFdBQVcsRUFBQywwQkFBMEIsR0FDdEMsSUFDRSxFQUVOLHVCQUFDLGVBQU0sSUFBQyxRQUFRLEVBQUUsU0FBUyxJQUFJLFdBQVcsRUFBRSxJQUFJLEVBQUMsUUFBUSxZQUN0RCxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQ2IsNEZBQWlDLENBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQ0YsNkRBQ0csU0FBUyxJQUFJLHVCQUFDLHdCQUFjLEtBQUcsdUJBRS9CLENBQ0osR0FDTSxJQUNMLEdBQ0QsR0FDSCxDQUNQLENBQUM7QUFDSixDQUFDIn0=