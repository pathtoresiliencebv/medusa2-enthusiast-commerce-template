"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SyncStatus = void 0;
var SyncStatus;
(function (SyncStatus) {
    SyncStatus["PROCESSING"] = "processing";
    SyncStatus["SUCCESS"] = "success";
    SyncStatus["FAILED"] = "failed";
})(SyncStatus || (exports.SyncStatus = SyncStatus = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidHlwZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvbW9kdWxlcy9lbnRodXNpYXN0L3R5cGVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLElBQVksVUFJWDtBQUpELFdBQVksVUFBVTtJQUNwQix1Q0FBeUIsQ0FBQTtJQUN6QixpQ0FBbUIsQ0FBQTtJQUNuQiwrQkFBaUIsQ0FBQTtBQUNuQixDQUFDLEVBSlcsVUFBVSwwQkFBVixVQUFVLFFBSXJCIn0=