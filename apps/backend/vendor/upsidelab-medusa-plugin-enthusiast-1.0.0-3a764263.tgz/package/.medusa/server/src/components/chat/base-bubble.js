"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseBubble = BaseBubble;
const jsx_runtime_1 = require("react/jsx-runtime");
const utils_1 = require("../../admin/lib/utils");
function BaseBubble({ variant, children, className, hasBackground = false, inMessageGroup, }) {
    return ((0, jsx_runtime_1.jsx)("div", { className: (0, utils_1.cn)("flex", inMessageGroup && "mt-2"), children: (0, jsx_runtime_1.jsx)("div", { className: (0, utils_1.cn)("flex flex-col max-w-[75%] gap-2 rounded-lg px-3 py-2 text-sm", variant === "primary" && "ml-auto", hasBackground &&
                variant === "primary" &&
                "bg-[#F4F4F5] dark:bg-[#2A2D31] text-foreground", hasBackground && variant === "secondary" && "bg-muted", className), children: children }) }));
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFzZS1idWJibGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvY29tcG9uZW50cy9jaGF0L2Jhc2UtYnViYmxlLnRzeCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQVVBLGdDQXdCQzs7QUFsQ0QsaURBQTJDO0FBVTNDLFNBQWdCLFVBQVUsQ0FBQyxFQUN6QixPQUFPLEVBQ1AsUUFBUSxFQUNSLFNBQVMsRUFDVCxhQUFhLEdBQUcsS0FBSyxFQUNyQixjQUFjLEdBQ0U7SUFDaEIsT0FBTyxDQUNMLGdDQUFLLFNBQVMsRUFBRSxJQUFBLFVBQUUsRUFBQyxNQUFNLEVBQUUsY0FBYyxJQUFJLE1BQU0sQ0FBQyxZQUNsRCxnQ0FDRSxTQUFTLEVBQUUsSUFBQSxVQUFFLEVBQ1gsOERBQThELEVBQzlELE9BQU8sS0FBSyxTQUFTLElBQUksU0FBUyxFQUNsQyxhQUFhO2dCQUNYLE9BQU8sS0FBSyxTQUFTO2dCQUNyQixnREFBZ0QsRUFDbEQsYUFBYSxJQUFJLE9BQU8sS0FBSyxXQUFXLElBQUksVUFBVSxFQUN0RCxTQUFTLENBQ1YsWUFFQSxRQUFRLEdBQ0wsR0FDRixDQUNQLENBQUM7QUFDSixDQUFDIn0=