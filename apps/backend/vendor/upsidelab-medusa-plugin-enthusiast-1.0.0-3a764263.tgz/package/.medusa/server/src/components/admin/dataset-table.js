"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatasetTable = void 0;
const jsx_runtime_1 = require("react/jsx-runtime");
const ui_1 = require("@medusajs/ui");
const react_1 = require("react");
const admin_client_1 = require("../../admin/lib/admin-client");
const column_with_tooltip_1 = require("../../components/admin/column-with-tooltip");
const icons_1 = require("@medusajs/icons");
const dataset_create_form_1 = require("../../components/admin/dataset-create-form");
const utils_1 = require("../../admin/lib/utils");
const DatasetTable = ({ forceOpenCreate = false, onCreateSuccess }) => {
    const [datasets, setDatasets] = (0, react_1.useState)([]);
    const [hasLoaded, setHasLoaded] = (0, react_1.useState)(false);
    const fetchDatasets = (0, react_1.useCallback)(async () => {
        const res = await admin_client_1.adminApiClient.dataSets().getInternalDataSets();
        setDatasets(res);
        setHasLoaded(true);
    }, []);
    (0, react_1.useEffect)(() => {
        void fetchDatasets();
    }, [fetchDatasets]);
    const columnHelper = (0, ui_1.createDataTableColumnHelper)();
    const columns = [
        columnHelper.accessor("name", {
            header: "Name",
        }),
        columnHelper.accessor("is_active", {
            header: () => {
                return ((0, jsx_runtime_1.jsx)(column_with_tooltip_1.ColumnHeaderWithTooltip, { name: "Active", tooltip: "Active dataset will be used in all chats." }));
            },
            cell: ({ getValue, row }) => {
                const isChecked = getValue();
                return ((0, jsx_runtime_1.jsx)(ui_1.RadioGroup, { value: isChecked ? row.original.id : "", onValueChange: () => {
                        void (async () => {
                            try {
                                await admin_client_1.adminApiClient.dataSets().setAsActive(row.original.id);
                                setDatasets((prev) => prev.map((dataset) => ({
                                    ...dataset,
                                    is_active: dataset.id === row.original.id,
                                })));
                            }
                            finally {
                                void fetchDatasets();
                            }
                        })();
                    }, children: (0, jsx_runtime_1.jsxs)("div", { className: "flex items-center gap-x-3", children: [(0, jsx_runtime_1.jsx)(ui_1.RadioGroup.Item, { value: row.original.id, id: `radio_${row.original.id}`, checked: isChecked }), (0, jsx_runtime_1.jsx)(ui_1.Label, { htmlFor: `radio_${row.original.id}`, weight: "plus", children: "Active" })] }) }));
            },
        }),
        columnHelper.accessor("sync_status", {
            header: "Synchronization Status",
            cell: ({ row }) => {
                return ((0, jsx_runtime_1.jsxs)("div", { className: "flex items-center gap-x-3", children: [(0, jsx_runtime_1.jsx)(ui_1.Label, { htmlFor: `${row.original.id}`, weight: "plus", children: row.original.sync_status }), row.original.sync_status && ((0, jsx_runtime_1.jsx)(ui_1.IconButton, { variant: "transparent", onClick: () => {
                                void (async () => {
                                    await admin_client_1.adminApiClient.dataSets().synchronizeDatasets(row.original.id);
                                    void fetchDatasets();
                                })();
                            }, children: (0, jsx_runtime_1.jsx)(icons_1.ArrowPath, {}) }))] }));
            },
        }),
        columnHelper.accessor("last_synced", {
            header: "Last Synchronized",
            cell: ({ getValue }) => {
                const date = getValue();
                if (date) {
                    return ((0, jsx_runtime_1.jsx)(ui_1.Tooltip, { content: (0, utils_1.getFullDate)({ date, includeTime: true }), children: (0, jsx_runtime_1.jsx)("span", { children: (0, utils_1.getFullDate)({ date }) }) }));
                }
                return null;
            },
        }),
    ];
    const table = (0, ui_1.useDataTable)({
        columns,
        data: datasets,
        getRowId: (row) => row.id,
        rowCount: datasets.length,
    });
    return ((0, jsx_runtime_1.jsx)(ui_1.Container, { children: (0, jsx_runtime_1.jsx)("div", { className: "flex flex-col min-h-0", children: (0, jsx_runtime_1.jsxs)(ui_1.DataTable, { instance: table, children: [(0, jsx_runtime_1.jsxs)(ui_1.DataTable.Toolbar, { className: "flex flex-col items-start justify-between gap-2 md:flex-row md:items-center flex-shrink-0", children: [(0, jsx_runtime_1.jsxs)("div", { className: "flex flex-col", children: [(0, jsx_runtime_1.jsx)(ui_1.Heading, { children: "Data Sets" }), (0, jsx_runtime_1.jsx)(ui_1.Text, { className: "text-ui-fg-subtle", size: "small", children: "A data set represents a configuration of agents, products and documents sources" })] }), (0, jsx_runtime_1.jsx)(dataset_create_form_1.DatasetCreateForm, { setRefetch: fetchDatasets, anyActive: datasets.some((dataset) => dataset.is_active), isFirst: !datasets.length, defaultOpen: forceOpenCreate || (hasLoaded && datasets.length === 0), onSuccess: onCreateSuccess })] }), (0, jsx_runtime_1.jsx)("div", { className: "flex-1 overflow-auto min-h-0 max-h-[calc(100vh-16rem)]", onWheel: (e) => {
                            const container = e.currentTarget;
                            container.scrollTop += e.deltaY;
                        }, children: (0, jsx_runtime_1.jsx)(ui_1.DataTable.Table, { emptyState: {
                                empty: {
                                    heading: "No Datasets",
                                    description: "There is no datasets available.",
                                },
                            } }) })] }) }) }));
};
exports.DatasetTable = DatasetTable;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0YXNldC10YWJsZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9jb21wb25lbnRzL2FkbWluL2RhdGFzZXQtdGFibGUudHN4Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7QUFBQSxxQ0FXc0I7QUFDdEIsaUNBQXlEO0FBQ3pELCtEQUE4RDtBQUU5RCxvRkFBcUY7QUFDckYsMkNBQTRDO0FBQzVDLG9GQUErRTtBQUMvRSxpREFBb0Q7QUFPN0MsTUFBTSxZQUFZLEdBQUcsQ0FBQyxFQUFFLGVBQWUsR0FBRyxLQUFLLEVBQUUsZUFBZSxFQUFxQixFQUFFLEVBQUU7SUFDOUYsTUFBTSxDQUFDLFFBQVEsRUFBRSxXQUFXLENBQUMsR0FBRyxJQUFBLGdCQUFRLEVBQTBCLEVBQUUsQ0FBQyxDQUFDO0lBQ3RFLE1BQU0sQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLEdBQUcsSUFBQSxnQkFBUSxFQUFDLEtBQUssQ0FBQyxDQUFDO0lBRWxELE1BQU0sYUFBYSxHQUFHLElBQUEsbUJBQVcsRUFBQyxLQUFLLElBQUksRUFBRTtRQUMzQyxNQUFNLEdBQUcsR0FBRyxNQUFNLDZCQUFjLENBQUMsUUFBUSxFQUFFLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztRQUNsRSxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDakIsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3JCLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUVQLElBQUEsaUJBQVMsRUFBQyxHQUFHLEVBQUU7UUFDYixLQUFLLGFBQWEsRUFBRSxDQUFDO0lBQ3ZCLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM7SUFFcEIsTUFBTSxZQUFZLEdBQUcsSUFBQSxnQ0FBMkIsR0FBeUIsQ0FBQztJQUUxRSxNQUFNLE9BQU8sR0FBRztRQUNkLFlBQVksQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFO1lBQzVCLE1BQU0sRUFBRSxNQUFNO1NBQ2YsQ0FBQztRQUNGLFlBQVksQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFO1lBQ2pDLE1BQU0sRUFBRSxHQUFHLEVBQUU7Z0JBQ1gsT0FBTyxDQUNMLHVCQUFDLDZDQUF1QixJQUN0QixJQUFJLEVBQUMsUUFBUSxFQUNiLE9BQU8sRUFBQywyQ0FBMkMsR0FDbkQsQ0FDSCxDQUFDO1lBQ0osQ0FBQztZQUNELElBQUksRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUU7Z0JBQzFCLE1BQU0sU0FBUyxHQUFHLFFBQVEsRUFBRSxDQUFDO2dCQUM3QixPQUFPLENBQ0wsdUJBQUMsZUFBVSxJQUNULEtBQUssRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQ3ZDLGFBQWEsRUFBRSxHQUFHLEVBQUU7d0JBQ2xCLEtBQUssQ0FBQyxLQUFLLElBQUksRUFBRTs0QkFDZixJQUFJLENBQUM7Z0NBQ0gsTUFBTSw2QkFBYyxDQUFDLFFBQVEsRUFBRSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dDQUM3RCxXQUFXLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUNuQixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDO29DQUNyQixHQUFHLE9BQU87b0NBQ1YsU0FBUyxFQUFFLE9BQU8sQ0FBQyxFQUFFLEtBQUssR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFO2lDQUMxQyxDQUFDLENBQUMsQ0FDSixDQUFDOzRCQUNKLENBQUM7b0NBQVMsQ0FBQztnQ0FDVCxLQUFLLGFBQWEsRUFBRSxDQUFDOzRCQUN2QixDQUFDO3dCQUNILENBQUMsQ0FBQyxFQUFFLENBQUM7b0JBQ1AsQ0FBQyxZQUVELGlDQUFLLFNBQVMsRUFBQywyQkFBMkIsYUFDeEMsdUJBQUMsZUFBVSxDQUFDLElBQUksSUFDZCxLQUFLLEVBQUUsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQ3RCLEVBQUUsRUFBRSxTQUFTLEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLEVBQzlCLE9BQU8sRUFBRSxTQUFTLEdBQ2xCLEVBQ0YsdUJBQUMsVUFBSyxJQUFDLE9BQU8sRUFBRSxTQUFTLEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLEVBQUUsTUFBTSxFQUFDLE1BQU0sdUJBRWpELElBQ0osR0FDSyxDQUNkLENBQUM7WUFDSixDQUFDO1NBQ0YsQ0FBQztRQUNGLFlBQVksQ0FBQyxRQUFRLENBQUMsYUFBYSxFQUFFO1lBQ25DLE1BQU0sRUFBRSx3QkFBd0I7WUFDaEMsSUFBSSxFQUFFLENBQUMsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFO2dCQUNoQixPQUFPLENBQ0wsaUNBQUssU0FBUyxFQUFDLDJCQUEyQixhQUN4Qyx1QkFBQyxVQUFLLElBQUMsT0FBTyxFQUFFLEdBQUcsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLEVBQUUsRUFBRSxNQUFNLEVBQUMsTUFBTSxZQUNoRCxHQUFHLENBQUMsUUFBUSxDQUFDLFdBQVcsR0FDbkIsRUFDUCxHQUFHLENBQUMsUUFBUSxDQUFDLFdBQVcsSUFBSSxDQUMzQix1QkFBQyxlQUFVLElBQ1QsT0FBTyxFQUFDLGFBQWEsRUFDckIsT0FBTyxFQUFFLEdBQUcsRUFBRTtnQ0FDWixLQUFLLENBQUMsS0FBSyxJQUFJLEVBQUU7b0NBQ2YsTUFBTSw2QkFBYyxDQUFDLFFBQVEsRUFBRSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7b0NBQ3JFLEtBQUssYUFBYSxFQUFFLENBQUM7Z0NBQ3ZCLENBQUMsQ0FBQyxFQUFFLENBQUM7NEJBQ1AsQ0FBQyxZQUVELHVCQUFDLGlCQUFTLEtBQUcsR0FDRixDQUNkLElBQ0csQ0FDUCxDQUFDO1lBQ0osQ0FBQztTQUNGLENBQUM7UUFDRixZQUFZLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRTtZQUNuQyxNQUFNLEVBQUUsbUJBQW1CO1lBQzNCLElBQUksRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRTtnQkFDckIsTUFBTSxJQUFJLEdBQUcsUUFBUSxFQUFFLENBQUM7Z0JBQ3hCLElBQUksSUFBSSxFQUFFLENBQUM7b0JBQ1QsT0FBTyxDQUNMLHVCQUFDLFlBQU8sSUFBQyxPQUFPLEVBQUUsSUFBQSxtQkFBVyxFQUFDLEVBQUUsSUFBSSxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUUsQ0FBQyxZQUN4RCwyQ0FBTyxJQUFBLG1CQUFXLEVBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxHQUFRLEdBQzVCLENBQ1gsQ0FBQztnQkFDSixDQUFDO2dCQUNELE9BQU8sSUFBSSxDQUFDO1lBQ2QsQ0FBQztTQUNGLENBQUM7S0FDSCxDQUFDO0lBQ0YsTUFBTSxLQUFLLEdBQUcsSUFBQSxpQkFBWSxFQUFDO1FBQ3pCLE9BQU87UUFDUCxJQUFJLEVBQUUsUUFBUTtRQUNkLFFBQVEsRUFBRSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUU7UUFDekIsUUFBUSxFQUFFLFFBQVEsQ0FBQyxNQUFNO0tBQzFCLENBQUMsQ0FBQztJQUVILE9BQU8sQ0FDTCx1QkFBQyxjQUFTLGNBQ1IsZ0NBQUssU0FBUyxFQUFDLHVCQUF1QixZQUNwQyx3QkFBQyxjQUFTLElBQUMsUUFBUSxFQUFFLEtBQUssYUFDeEIsd0JBQUMsY0FBUyxDQUFDLE9BQU8sSUFBQyxTQUFTLEVBQUMsMkZBQTJGLGFBQ3RILGlDQUFLLFNBQVMsRUFBQyxlQUFlLGFBQzVCLHVCQUFDLFlBQU8sNEJBQW9CLEVBQzVCLHVCQUFDLFNBQUksSUFBQyxTQUFTLEVBQUMsbUJBQW1CLEVBQUMsSUFBSSxFQUFDLE9BQU8sZ0dBRXpDLElBQ0gsRUFDTix1QkFBQyx1Q0FBaUIsSUFDaEIsVUFBVSxFQUFFLGFBQWEsRUFDekIsU0FBUyxFQUFFLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFDeEQsT0FBTyxFQUFFLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFDekIsV0FBVyxFQUFFLGVBQWUsSUFBSSxDQUFDLFNBQVMsSUFBSSxRQUFRLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQyxFQUNwRSxTQUFTLEVBQUUsZUFBZSxHQUMxQixJQUNnQixFQUNwQixnQ0FDRSxTQUFTLEVBQUMsd0RBQXdELEVBQ2xFLE9BQU8sRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFOzRCQUNiLE1BQU0sU0FBUyxHQUFHLENBQUMsQ0FBQyxhQUFhLENBQUM7NEJBQ2xDLFNBQVMsQ0FBQyxTQUFTLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQzt3QkFDbEMsQ0FBQyxZQUVELHVCQUFDLGNBQVMsQ0FBQyxLQUFLLElBQ2QsVUFBVSxFQUFFO2dDQUNWLEtBQUssRUFBRTtvQ0FDTCxPQUFPLEVBQUUsYUFBYTtvQ0FDdEIsV0FBVyxFQUFFLGlDQUFpQztpQ0FDL0M7NkJBQ0YsR0FDRCxHQUNFLElBQ0ksR0FDUixHQUNJLENBQ2IsQ0FBQztBQUNKLENBQUMsQ0FBQztBQXRKVyxRQUFBLFlBQVksZ0JBc0p2QiJ9